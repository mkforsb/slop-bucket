// Dev-only harness: renders a lineup of cats in various patterns/poses for visual checks.
import * as THREE from 'three';
import { Cat } from '../src/cat.js';

const params = new URLSearchParams(location.search);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.background = new THREE.Color('#f3e6d8');
const cam = new THREE.PerspectiveCamera(35, innerWidth / innerHeight, 0.01, 50);
scene.add(new THREE.HemisphereLight(0xfff6ee, 0xb89c8a, 1.6));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(2, 4, 3); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -3, right: 3, top: 3, bottom: -3 });
scene.add(sun);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ color: '#e8d2b8' }));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

const mode = params.get('mode') || 'lineup';
const cats = [];
const pats = ['tabby', 'tuxedo', 'calico', 'siamese', 'spotted', 'van', 'tortie', 'solid'];
const colors = { tabby: ['#e8913a', '#8a3f14'], tuxedo: ['#2a2a30', '#111'], calico: ['#e8913a', '#2a2a30'], siamese: ['#f2e6d0', '#4a3328'], spotted: ['#c8a27a', '#3b2616'], van: ['#d9772e', '#000'], tortie: ['#d9772e', '#2a2124'], solid: ['#8a8f99', '#000'] };
const poses = (params.get('poses') || 'stand,sit,loaf,crouch,eat,squat,belly,sleep').split(',');
if (mode === 'lineup') {
  pats.forEach((p, i) => {
    const c = new Cat({ pattern: p, main: colors[p][0], accent: colors[p][1], white: p === 'solid' ? 0.5 : 0.3 });
    c.place((i % 4 - 1.5) * 0.55, Math.floor(i / 4) * -0.7, 0.3);
    c.setPose(poses[i % poses.length] || 'stand');
    scene.add(c.root); cats.push(c);
  });
  cam.position.set(0, 1.1, 2.2); cam.lookAt(0, 0.1, -0.3);
} else if (mode === 'face') {
  const c = new Cat({ pattern: params.get('p') || 'tabby' });
  c.setPose(params.get('pose') || 'stand');
  scene.add(c.root); cats.push(c);
  const a = parseFloat(params.get('a') || '0.5');
  const d = parseFloat(params.get('d') || '0.9');
  cam.position.set(Math.sin(a) * d, 0.45, Math.cos(a) * d); cam.lookAt(0, 0.3, 0);
}
window.__cats = cats;
let last = performance.now();
renderer.setAnimationLoop(() => {
  const now = performance.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
  for (const c of cats) c.update(dt);
  renderer.render(scene, cam);
});
