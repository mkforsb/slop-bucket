import sys
from PIL import Image
out=sys.argv[1]; files=sys.argv[2:]
ims=[Image.open(f) for f in files]
w=ims[0].width//2; h=ims[0].height//2
cols=3; rows=(len(ims)+cols-1)//cols
M=Image.new('RGB',(w*cols,h*rows),'white')
for i,im in enumerate(ims): M.paste(im.resize((w,h)),((i%cols)*w,(i//cols)*h))
M.save(out)
