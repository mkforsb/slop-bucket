#!/usr/bin/env python3
"""Headless screenshot helper. usage: shot.py <html> <out.png> [query] [wait_ms] [js_steps_file]"""
import sys, asyncio, pathlib
from playwright.async_api import async_playwright


async def main():
    html = pathlib.Path(sys.argv[1]).resolve()
    out = sys.argv[2]
    query = sys.argv[3] if len(sys.argv) > 3 else ''
    wait = int(sys.argv[4]) if len(sys.argv) > 4 else 1500
    steps = pathlib.Path(sys.argv[5]).read_text() if len(sys.argv) > 5 else None
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        import os
        vw, vh = map(int, os.environ.get('VIEWPORT', '1280x800').split('x'))
        pg = await b.new_page(viewport={'width': vw, 'height': vh}, has_touch=bool(os.environ.get('TOUCH')))
        logs = []
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
        pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
        await pg.goto(f'file://{html}{query}')
        await pg.wait_for_timeout(wait)
        if steps:
            # steps: python-ish lines: "js <code>", "click x y", "wait ms", "shot file", "move x y", "down", "up", "drag x1 y1 x2 y2"
            for line in steps.splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                cmd, _, rest = line.partition(' ')
                if cmd == 'js':
                    r = await pg.evaluate(rest)
                    if r is not None:
                        logs.append(f'[js] {r}')
                elif cmd == 'click':
                    x, y = map(float, rest.split()); await pg.mouse.click(x, y)
                elif cmd == 'sel':
                    await pg.click(rest)
                elif cmd == 'move':
                    x, y = map(float, rest.split()); await pg.mouse.move(x, y, steps=8)
                elif cmd == 'mw':
                    x, y, z = map(float, rest.split())
                    sx, sy = await pg.evaluate(f'''(() => {{ const g = window.__game; const v = new g.camera.position.constructor({x},{y},{z}); v.project(g.camera); return [(v.x*0.5+0.5)*innerWidth, (-v.y*0.5+0.5)*innerHeight]; }})()''')
                    await pg.mouse.move(sx, sy, steps=6)
                elif cmd == 'down':
                    await pg.mouse.down()
                elif cmd == 'up':
                    await pg.mouse.up()
                elif cmd == 'wait':
                    await pg.wait_for_timeout(int(rest))
                elif cmd == 'shot':
                    await pg.screenshot(path=rest)
        await pg.screenshot(path=out)
        for l in logs:
            print(l)
        await b.close()

asyncio.run(main())
