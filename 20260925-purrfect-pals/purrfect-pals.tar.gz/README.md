# Purrfect Pals — Caring for your pet cat

A cozy 3D cat-care game (Three.js / WebGL) that compiles to a single self-contained HTML file:
**`dist/purrfect-pals.html`**. Open it in any modern browser. It needs no server or network, and the game saves to localStorage.

## Scenes
- **Adopt**: character creator with 8 coat patterns, colours, white markings, eyes (including odd eyes), nose, head, ears, build, legs, tail, fluffiness, collar/bell, and a synthesised meow (7 styles plus pitch, length and raspiness).
- **Home**: the cat roams on its own. It naps, window-watches, eats, uses the litter box, gets the zoomies, and asks for attention when a need is low.
- **Feed**: pour kibble (with physics), spoon wet food, toss treats, refill water.
- **Pet**: stroke with a hand or brush. Each region gets a different reaction, and you get purring, kneading, slow blinks… and the belly trap.
- **Play**: feather wand (stalk → butt wiggle → pounce), laser pointer, yarn ball.
- **Litter**: scoop clumps into the bin, top up or change the litter, or watch kitty go (followed by zoomies).

## Building
```
python3 build.py          # -> dist/purrfect-pals.html
```
`build.py` bundles `src/` with the esbuild binary in `tools/` and three.js from `vendor/` (linked via
`node_modules/three`), then inlines the JS and CSS into `src/index.html`.

## Layout
- `src/cat.js`: procedural cat model, coat-pattern shader, pose blending, leg IK, tail and face
- `src/audio.js`: WebAudio synthesis for meows, purring and sound effects
- `src/world.js`: the room and props (textures are painted on canvases at startup)
- `src/behaviors.js`: shared cat routines (eating, litter, napping, zoomies)
- `src/scenes/*.js`: one file per scene
- `dev/`: screenshot/test helpers (Playwright) and a cat pose lineup (`python3 build.py test`)
