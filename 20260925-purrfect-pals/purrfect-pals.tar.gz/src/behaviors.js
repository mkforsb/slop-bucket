// Reusable cat routines (async scripts on the scene Task) shared between the home view and
// the activity scenes: eating, drinking, using the litter box, napping, zoomies.

import * as THREE from 'three';
import { SPOTS, OPEN } from './world.js';
import { state, add, recomputeClean } from './state.js';
import { audio } from './audio.js';
import { ui } from './ui.js';
import { rand, clamp, pick, wrapAngle } from './util.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

export function randomOpenPoint() {
  return V(rand(OPEN.minX, OPEN.maxX), 0, rand(OPEN.minZ, OPEN.maxZ));
}

export async function walk(G, tk, x, z, speed = 0.45) {
  await tk.guard(G.cat.walkTo(x, z, speed));
}

// Make sure the cat is standing on the floor somewhere sensible (e.g. after a scene switch
// left it in the litter box or the studio).
export function ensureOnFloor(G) {
  const p = G.cat.root.position;
  const lb = SPOTS.litter;
  const inBox = Math.abs(p.x - lb.x) < 0.6 && Math.abs(p.z - lb.z) < 0.45;
  const inBed = Math.hypot(p.x - SPOTS.bed.x, p.z - SPOTS.bed.z) < 0.5;
  if (p.x > 20 || inBox || inBed) G.cat.place(rand(-1, 1), rand(0, 1.5), rand(-0.5, 0.5));
  G.cat.root.position.y = 0;
}

// Food bowl -------------------------------------------------------------------------
export const BOWL_FRONT = V(SPOTS.bowl.x, 0, SPOTS.bowl.z + 0.36);

export async function eatFromBowl(G, tk, { onBite } = {}) {
  const cat = G.cat;
  await walk(G, tk, BOWL_FRONT.x, BOWL_FRONT.z, 0.55);
  cat.turnTo(Math.PI);
  await tk.sleep(0.4);
  if (state.needs.hunger > 92) {
    // sniff and walk away
    cat.setPose('eat');
    await tk.sleep(0.9);
    cat.setPose('stand');
    G.fx.emote(cat, 'question');
    ui.toast(`${state.name} isn't hungry right now`, 'info');
    await tk.sleep(0.6);
    await walk(G, tk, BOWL_FRONT.x + 0.6, BOWL_FRONT.z + 0.5, 0.4);
    return false;
  }
  cat.setPose('eat');
  cat.setTail('happy');
  let t = 0;
  const kind = state.bowl.kind;
  while (state.bowl.food > 0.01 && state.needs.hunger < 100) {
    await tk.sleep(0.45);
    t += 0.45;
    kind === 'wet' ? audio.slurp() : audio.crunch();
    const bite = Math.min(state.bowl.food, 0.045);
    state.bowl.food -= bite;
    add('hunger', bite * (kind === 'wet' ? 150 : 120));
    onBite?.();
    if (Math.random() < 0.3) cat.setMood({ eyes: 'squint' });
    else cat.setMood({ eyes: 'open' });
  }
  state.bladder += 0.25;
  state.stats.meals++;
  cat.setPose('sit');
  cat.setMood({ eyes: 'happy', blush: 0.6 });
  cat.face.mouth = 0.4; // lick lips
  G.fx.emote(cat, 'heart', 2);
  if (state.needs.hunger >= 99) ui.toast(`${state.name} is full and happy! 😋`, 'good');
  await tk.sleep(1.4);
  cat.setMood({ eyes: 'open', blush: 0 });
  return true;
}

export async function drink(G, tk) {
  const cat = G.cat;
  await walk(G, tk, SPOTS.water.x, SPOTS.water.z + 0.34, 0.45);
  cat.turnTo(Math.PI);
  await tk.sleep(0.4);
  cat.setPose('eat');
  for (let i = 0; i < 10 && state.water > 0.02; i++) {
    await tk.sleep(0.28);
    audio.lap();
    state.water = Math.max(0, state.water - 0.012);
  }
  cat.setPose('sit');
  await tk.sleep(0.6);
}

// Litter box ------------------------------------------------------------------------
export const LITTER_ENTRY = V(SPOTS.litter.x, 0, SPOTS.litter.z + 0.78);

export async function useLitter(G, tk) {
  const cat = G.cat, w = G.world;
  const box = SPOTS.litter;
  await walk(G, tk, LITTER_ENTRY.x, LITTER_ENTRY.z, 0.5);
  cat.turnTo(Math.PI);
  await tk.sleep(0.6);
  cat.lookAt(V(box.x, 0.1, box.z));
  await tk.sleep(0.5);
  if (state.needs.clean < 35) {
    cat.setMood({ ears: 1, eyes: 'squint' });
    cat.setTail('flick');
    G.fx.emote(cat, 'anger');
    cat.meow({ style: 'grumpy' });
    ui.toast(`Ew! ${state.name} refuses to use a dirty box 😾`, 'bad', 3);
    await tk.sleep(1.5);
    cat.resetMood();
    cat.lookAt(null);
    cat.setTail('low');
    add('love', -3);
    state.bladder = 0.7; // will try again later
    await walk(G, tk, LITTER_ENTRY.x - 1.1, LITTER_ENTRY.z + 0.1, 0.45);
    return false;
  }
  cat.lookAt(null);
  const sandY = w.sandTop;
  await tk.guard(cat.jumpTo(box.x, box.z + 0.05, 0.22, 0.5, sandY));
  // dig a hole
  cat.setPose('crouch');
  cat.knead = 1;
  const forward = () => V(Math.sin(cat.heading), 0, Math.cos(cat.heading));
  for (let i = 0; i < 6; i++) {
    await tk.sleep(0.25);
    audio.sandDig();
    const p = cat.root.position.clone().addScaledVector(forward(), 0.2);
    p.y = sandY + 0.02;
    G.fx.burst('dot', p, 5, { speed: 0.4, up: 0.8, size: 0.02, life: 0.6, colors: [0xe9dcc0, 0xd9c7a0], floor: sandY });
  }
  cat.knead = 0;
  // turn around and squat
  cat.turnTo(cat.heading + Math.PI);
  await tk.sleep(0.9);
  cat.setPose('squat');
  cat.setTail('up');
  cat.setMood({ eyes: 'squint' });
  await tk.sleep(2.2);
  // leave a clump behind the cat, in box-local coordinates
  const behind = cat.root.position.clone().addScaledVector(forward(), -0.16);
  const lx = clamp(behind.x - box.x, -0.38, 0.38), lz = clamp(behind.z - box.z, -0.24, 0.24);
  state.clumps.push({ id: Math.random().toString(36).slice(2), type: Math.random() < 0.55 ? 'poop' : 'pee', x: lx, z: lz, rot: rand(0, 6) });
  w.syncClumps(state.clumps);
  state.litter = Math.max(0, state.litter - 0.03);
  w.setLitterLevel(state.litter);
  recomputeClean();
  state.bladder = 0;
  cat.resetMood();
  // turn to cover it up
  cat.setPose('crouch');
  cat.turnTo(cat.heading + Math.PI);
  await tk.sleep(0.8);
  cat.knead = 1;
  for (let i = 0; i < 5; i++) {
    await tk.sleep(0.22);
    audio.sandDig();
    const p = V(box.x + lx, sandY + 0.02, box.z + lz);
    G.fx.burst('dot', p, 4, { speed: 0.3, up: 0.6, size: 0.02, life: 0.5, colors: [0xe9dcc0, 0xd9c7a0], floor: sandY });
  }
  cat.knead = 0;
  cat.setPose('stand');
  cat.setTail('happy');
  await tk.sleep(0.3);
  await tk.guard(cat.jumpTo(LITTER_ENTRY.x - 0.1, LITTER_ENTRY.z + 0.1, 0.22, 0.5, 0));
  if (Math.random() < 0.6) await zoomies(G, tk);
  return true;
}

// Post-litter (or just-because) zoomies!
export async function zoomies(G, tk, n = 4) {
  const cat = G.cat;
  G.fx.emote(cat, 'exclaim');
  cat.setMood({ pupil: 1.3, ears: 0.3 });
  cat.setTail('puff');
  audio.boing();
  for (let i = 0; i < n; i++) {
    const p = randomOpenPoint();
    await walk(G, tk, p.x, p.z, 1.7);
  }
  cat.resetMood();
  cat.setTail('happy');
  cat.setPose('sit');
  await tk.sleep(0.8);
}

// Nap in the bed ---------------------------------------------------------------------
export async function nap(G, tk, dur = 10) {
  const cat = G.cat, w = G.world;
  const bed = SPOTS.bed;
  await walk(G, tk, bed.x + 0.75, bed.z + 0.1, 0.45);
  await tk.guard(cat.jumpTo(bed.x, bed.z, 0.18, 0.45, w.bedTop));
  cat.turnTo(rand(0.5, 1.5));
  cat.setPose('loaf');
  cat.setTail('wrap');
  cat.setMood({ eyes: 'sleepy' });
  await tk.sleep(1.2);
  cat.setPose('sleep');
  cat.setMood({ eyes: 'closed' });
  G.napping = true;
  const t0 = G.clock.time;
  try {
    while (G.clock.time - t0 < dur) {
      await tk.sleep(1.3);
      G.fx.emote(cat, 'zzz', 1, { size: 0.07, life: 1.8 });
    }
  } finally { G.napping = false; }
  cat.setMood({ eyes: 'sleepy' });
  cat.setPose('loaf');
  await tk.sleep(0.8);
  cat.resetMood();
  cat.setPose('stand');
  await tk.guard(cat.jumpTo(bed.x + 0.75, bed.z + 0.1, 0.18, 0.45, 0));
}

export function faceAngle(from, to) { return Math.atan2(to.x - from.x, to.z - from.z); }
export { wrapAngle, pick };
