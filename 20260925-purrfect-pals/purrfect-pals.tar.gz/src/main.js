// Purrfect Pals — a cozy 3D cat care game. Entry point: renderer, camera, scene switching, input.

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Cat } from './cat.js';
import { World, SPOTS } from './world.js';
import { FX } from './fx.js';
import { audio } from './audio.js';
import { ui } from './ui.js';
import { state, load, save, reset, tick, mood, urgentNeed } from './state.js';
import { Clock, Task, damp, clamp, easeInOut, lerp } from './util.js';
import { AdoptScene } from './scenes/adopt.js';
import { HubScene } from './scenes/hub.js';
import { FeedScene } from './scenes/feed.js';
import { PetScene } from './scenes/pet.js';
import { PlayScene } from './scenes/play.js';
import { LitterScene } from './scenes/litter.js';

// ---------------------------------------------------------------------------- camera rig
class CamRig {
  constructor(camera) {
    this.cam = camera;
    this.pos = new THREE.Vector3(0, 3, 6);
    this.target = new THREE.Vector3();
    this.from = null;
    this.mode = 'fixed';
    this.orbit = { center: new THREE.Vector3(), yaw: 0, pitch: 0.5, dist: 6, yawT: 0, pitchT: 0.5, distT: 6, minYaw: -1, maxYaw: 1 };
    this.parallax = 0.08;
    this.pointer = new THREE.Vector2();
    this.ptr = new THREE.Vector2();
  }
  // Scenes are framed for landscape; on tall screens widen the vertical FOV so the
  // horizontal view stays roughly the same.
  applyFov(fov = this.baseFov || 40) {
    this.baseFov = fov;
    const minAspect = this.mode === 'orbit' ? 0.85 : 1.35;
    const a = this.cam.aspect;
    if (a < minAspect) {
      const h = 2 * Math.atan(Math.tan((fov * Math.PI) / 360) * minAspect);
      fov = Math.min(95, (2 * Math.atan(Math.tan(h / 2) / a) * 180) / Math.PI);
    }
    this.cam.fov = fov;
    this.cam.updateProjectionMatrix();
  }
  set(pos, target, fov = 40) {
    this.mode = 'fixed';
    this.pos.copy(pos); this.target.copy(target);
    this.applyFov(fov);
    this.from = null;
  }
  fly(pos, target, dur = 1.2) {
    this.mode = 'fixed';
    this.from = { pos: this.cam.position.clone(), target: this.curTarget ? this.curTarget.clone() : target.clone(), t: 0, dur };
    this.pos.copy(pos); this.target.copy(target);
  }
  setOrbit(center, yaw, pitch, dist, fov = 40) {
    this.mode = 'orbit';
    const o = this.orbit;
    o.center.copy(center);
    o.yaw = o.yawT = yaw; o.pitch = o.pitchT = pitch; o.dist = o.distT = dist;
    this.applyFov(fov);
  }
  update(dt) {
    this.ptr.x = damp(this.ptr.x, this.pointer.x, 3, dt);
    this.ptr.y = damp(this.ptr.y, this.pointer.y, 3, dt);
    if (this.mode === 'orbit') {
      const o = this.orbit;
      o.yaw = damp(o.yaw, o.yawT, 8, dt); o.pitch = damp(o.pitch, o.pitchT, 8, dt); o.dist = damp(o.dist, o.distT, 8, dt);
      this.cam.position.set(
        o.center.x + Math.sin(o.yaw) * Math.cos(o.pitch) * o.dist,
        o.center.y + Math.sin(o.pitch) * o.dist,
        o.center.z + Math.cos(o.yaw) * Math.cos(o.pitch) * o.dist);
      this.cam.lookAt(o.center);
      this.curTarget = o.center.clone();
      return;
    }
    let p = this.pos, t = this.target;
    if (this.from) {
      this.from.t += dt / this.from.dur;
      const k = easeInOut(clamp(this.from.t));
      p = this.from.pos.clone().lerp(this.pos, k);
      t = this.from.target.clone().lerp(this.target, k);
      if (this.from.t >= 1) this.from = null;
    }
    // gentle parallax toward the pointer
    const right = new THREE.Vector3().subVectors(t, p).cross(new THREE.Vector3(0, 1, 0)).normalize();
    const d = p.distanceTo(t);
    this.cam.position.copy(p).addScaledVector(right, this.ptr.x * this.parallax * d * 0.3).add(new THREE.Vector3(0, this.ptr.y * this.parallax * d * 0.15, 0));
    this.cam.lookAt(t);
    this.curTarget = t.clone();
  }
}

// ---------------------------------------------------------------------------- game
class Game {
  constructor() {
    const renderer = (this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' }));
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.getElementById('app').prepend(renderer.domElement);
    this.canvas = renderer.domElement;

    const scene = (this.scene = new THREE.Scene());
    scene.background = new THREE.Color('#f7e3d3');
    scene.fog = new THREE.Fog('#f7e3d3', 14, 30);
    this.camera = new THREE.PerspectiveCamera(40, window.innerWidth / window.innerHeight, 0.02, 60);
    this.cam = new CamRig(this.camera);

    // soft image-based lighting so glossy/metal props (bowls, bell, bin) have something to reflect
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 0.12;
    scene.add(new THREE.HemisphereLight('#fff6ee', '#caa58f', 1.25));
    const sun = (this.sun = new THREE.DirectionalLight('#fff0dc', 2.3));
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.02;
    scene.add(sun, sun.target);
    const fill = new THREE.DirectionalLight('#e8f0ff', 0.55);
    fill.position.set(-4, 3, 6);
    scene.add(fill);
    this.setShadowFocus(new THREE.Vector3(0, 0, -0.3), 5.5);

    this.world = new World(scene);
    this.fx = new FX(scene);
    this.cat = new Cat(state.look, state.voice);
    scene.add(this.cat.root);

    this.clock = new Clock();
    this.task = new Task(this.clock);
    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
    this.pointerDown = false;

    this.scenes = {
      adopt: new AdoptScene(this), hub: new HubScene(this), feed: new FeedScene(this),
      pet: new PetScene(this), play: new PlayScene(this), litter: new LitterScene(this),
    };
    this.current = null;
    this.hudTimer = 0; this.saveTimer = 0;

    this.bindInput();
    ui.init();
    window.addEventListener('resize', () => this.resize());
    let last = performance.now();
    renderer.setAnimationLoop(() => {
      const now = performance.now();
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      this.frame(dt);
    });
  }

  setShadowFocus(center, size) {
    const s = this.sun.shadow.camera;
    s.left = -size; s.right = size; s.top = size; s.bottom = -size;
    s.near = 0.5; s.far = 30;
    s.updateProjectionMatrix();
    this.sun.target.position.copy(center);
    this.sun.position.copy(center).add(new THREE.Vector3(2.5, 7, 4));
  }

  resize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.cam.applyFov();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // Reset the shared cat between scenes so no behaviour leaks across.
  resetCat() {
    const c = this.cat;
    c.stop(); c.jump = null; c.pawSwipe = null;
    c.knead = 0; c.wiggle = 0; c.purr = 0;
    c.resetMood(); c.lookAt(null);
    c.root.position.y = 0;
    c.setPose('stand');
    c.setTail(mood().score > 50 ? 'happy' : 'neutral');
    audio.setPurr(0);
  }

  async goto(name, opts = {}) {
    if (this.switching) return;
    this.switching = true;
    audio.pop();
    const instant = !this.current;
    try {
      if (!instant) { ui.wipe(true); await new Promise((r) => setTimeout(r, 400)); }
      if (this.current) this.current.exit();
      this.task.cancel();
      this.task = new Task(this.clock);
      this.resetCat();
      ui.setTools([]);
      ui.hint('');
      ui.bubble(null);
      this.canvas.style.cursor = '';
      this.current = this.scenes[name];
      this.currentName = name;
      this.current.enter(opts);
      ui.setActiveNav(name);
      ui.showHUD(name !== 'adopt');
      this.cam.update(0);
    } finally {
      if (!instant) setTimeout(() => ui.wipe(false), 60);
      this.switching = false;
    }
  }

  frame(dt) {
    this.clock.tick(dt);
    if (state.adopted && this.currentName !== 'adopt') {
      tick(dt);
      this.hudTimer -= dt;
      if (this.hudTimer < 0) { this.hudTimer = 0.25; ui.updateHUD(); }
      this.saveTimer -= dt;
      if (this.saveTimer < 0) { this.saveTimer = 5; save(); }
    }
    if (this.current) this.current.update(dt);
    this.cat.update(dt);
    this.world.update(dt);
    this.world.updateBowls(state.bowl, state.water);
    this.fx.update(dt);
    audio.update(dt);
    this.cam.update(dt);
    this.renderer.render(this.scene, this.camera);
    this.updateBubble();
  }

  updateBubble() {
    if (!state.adopted || this.currentName !== 'hub' || this.current.busyBubble) { ui.bubble(null); return; }
    const need = urgentNeed(30);
    if (!need) { ui.bubble(null); return; }
    const p = this.cat.headWorldPos().add(new THREE.Vector3(0, 0.25, 0)).project(this.camera);
    ui.bubble(need.icon, { x: (p.x * 0.5 + 0.5) * window.innerWidth, y: (-p.y * 0.5 + 0.5) * window.innerHeight });
  }

  // ---------------------------------------------------------------- picking helpers
  setRay(e) {
    const r = this.canvas.getBoundingClientRect();
    this.ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.ndc, this.camera);
    this.cam.pointer.copy(this.ndc);
  }
  rayPlane(y = 0, out = new THREE.Vector3()) {
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -y);
    return this.raycaster.ray.intersectPlane(plane, out);
  }
  pickCat() {
    const hits = this.raycaster.intersectObjects(this.cat.pickables, false);
    if (!hits.length) return null;
    const h = hits[0];
    const n = h.face ? h.face.normal.clone().transformDirection(h.object.matrixWorld) : new THREE.Vector3(0, 1, 0);
    return { point: h.point, normal: n, object: h.object, region: this.cat.regionAt(h), distance: h.distance };
  }
  pick(objects) {
    const hits = this.raycaster.intersectObjects(objects, true);
    return hits[0] || null;
  }

  bindInput() {
    const c = this.canvas;
    c.addEventListener('pointerdown', (e) => {
      audio.unlock();
      c.setPointerCapture(e.pointerId);
      this.pointerDown = true;
      this.setRay(e);
      this.current?.pointerDown?.(e);
    });
    c.addEventListener('pointermove', (e) => {
      this.setRay(e);
      this.current?.pointerMove?.(e);
    });
    const up = (e) => {
      if (!this.pointerDown) return;
      this.pointerDown = false;
      this.setRay(e);
      this.current?.pointerUp?.(e);
    };
    c.addEventListener('pointerup', up);
    c.addEventListener('pointercancel', up);
    c.addEventListener('wheel', (e) => { this.current?.wheel?.(e); e.preventDefault(); }, { passive: false });
    c.addEventListener('contextmenu', (e) => e.preventDefault());

    document.querySelectorAll('#nav button').forEach((b) => b.addEventListener('click', () => {
      if (this.currentName !== b.dataset.scene) this.goto(b.dataset.scene);
    }));
    const mute = document.getElementById('btn-mute');
    mute.addEventListener('click', () => {
      audio.unlock();
      audio.setMuted(!audio.muted);
      mute.textContent = audio.muted ? '🔇' : '🔊';
    });
    document.getElementById('btn-edit').addEventListener('click', () => this.goto('adopt', { edit: true }));
    document.getElementById('btn-menu').addEventListener('click', () => {
      audio.click();
      const s = state.stats;
      document.getElementById('stats').innerHTML = `
        <b>${state.name}</b> — ${mood().face} ${mood().label}<br>
        🍽️ Meals served: ${s.meals}<br>✋ Petting sessions: ${s.pets}<br>🧶 Play sessions: ${s.plays}<br>🧹 Clumps scooped: ${s.scoops}`;
      document.getElementById('menu').classList.remove('hidden');
    });
    document.getElementById('menu-close').addEventListener('click', () => document.getElementById('menu').classList.add('hidden'));
    document.getElementById('menu-reset').addEventListener('click', () => {
      if (!confirm(`Say goodbye to ${state.name} and adopt a new cat?`)) return;
      reset();
      document.getElementById('menu').classList.add('hidden');
      this.cat.setLook(state.look);
      this.goto('adopt');
    });
  }

  start() {
    const hasSave = load();
    this.world.setLitterLevel(state.litter);
    this.world.syncClumps(state.clumps);
    this.cat.setLook(state.look);
    this.cat.voice = { ...state.voice };
    const btns = document.getElementById('title-buttons');
    if (hasSave) {
      btns.innerHTML = `<button class="big primary" id="btn-continue">Visit ${state.name.replace(/[<>&]/g, '')}</button><button class="big" id="btn-new">New cat</button>`;
      document.getElementById('btn-continue').onclick = () => this.begin('hub');
      document.getElementById('btn-new').onclick = () => { reset(); this.scenes.adopt.newCat(); this.begin('adopt'); };
    } else {
      document.getElementById('btn-start').onclick = () => this.begin('adopt');
    }
    // Title backdrop: the studio with a random cat.
    this.goto('adopt', { preview: true });
    document.getElementById('loading').remove();
  }

  begin(scene) {
    audio.unlock();
    audio.chime();
    document.getElementById('title').classList.add('hidden');
    if (scene === 'adopt') this.scenes.adopt.showPanel();
    else this.goto(scene);
  }
}

try {
  const game = new Game();
  game.state = state;
  game.audio = audio;
  window.__game = game;
  game.start();
  window.addEventListener('beforeunload', () => { if (state.adopted) save(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && state.adopted) save(); });
} catch (e) {
  console.error(e);
  document.getElementById('loading').textContent = 'Sorry — this game needs WebGL, which seems to be unavailable in this browser. 😿';
}
