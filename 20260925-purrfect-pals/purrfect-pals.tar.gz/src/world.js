// The cozy apartment: room shell, furniture and all interactive props (bowls, litter box,
// toys...). Textures are painted on canvases at startup.

import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { rand } from './util.js';

export const SPOTS = {
  bowl: new THREE.Vector3(-3.25, 0, -3.05),
  water: new THREE.Vector3(-2.62, 0, -3.18),
  litter: new THREE.Vector3(3.3, 0, -2.95),
  trash: new THREE.Vector3(4.12, 0, -3.42),
  bed: new THREE.Vector3(-3.35, 0, 0.55),
  play: new THREE.Vector3(0.3, 0, 0.6),
  studio: new THREE.Vector3(40, 0, 0),
};
export const ROOM = { minX: -4.1, maxX: 4.1, minZ: -3.6, maxZ: 3.6 };
// open floor where the cat can wander freely without walking through furniture
export const OPEN = { minX: -2.8, maxX: 2.9, minZ: -2.2, maxZ: 2.8 };

function tex(w, h, draw, repeat = null) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
}

const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.8, ...o });

function mesh(geo, mat, pos, parent, { cast = true, receive = true, rot = null, scale = null } = {}) {
  const m = new THREE.Mesh(geo, mat);
  if (pos) m.position.copy(pos);
  if (rot) m.rotation.set(...rot);
  if (scale) m.scale.set(...scale);
  m.castShadow = cast;
  m.receiveShadow = receive;
  if (parent) parent.add(m);
  return m;
}
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const rbox = (w, h, d, r = 0.03) => new RoundedBoxGeometry(w, h, d, 3, r);

// ---------------------------------------------------------------------------- textures
function woodFloorTex() {
  return tex(1024, 1024, (g, w, h) => {
    const rows = 8;
    const rh = h / rows;
    for (let r = 0; r < rows; r++) {
      let x = -rand(0, 300);
      while (x < w) {
        const len = rand(260, 520);
        const l = rand(62, 72);
        g.fillStyle = `hsl(${rand(26, 32)}, ${rand(42, 52)}%, ${l}%)`;
        g.fillRect(x, r * rh, len, rh);
        // grain
        g.globalAlpha = 0.12;
        for (let k = 0; k < 14; k++) {
          g.strokeStyle = `hsl(25, 45%, ${l - rand(8, 18)}%)`;
          g.lineWidth = rand(1, 3);
          g.beginPath();
          const y = r * rh + rand(4, rh - 4);
          g.moveTo(x, y);
          g.bezierCurveTo(x + len * 0.3, y + rand(-6, 6), x + len * 0.6, y + rand(-6, 6), x + len, y + rand(-4, 4));
          g.stroke();
        }
        g.globalAlpha = 1;
        g.fillStyle = 'rgba(90,55,30,0.45)';
        g.fillRect(x, r * rh, 3, rh);
        x += len;
      }
      g.fillStyle = 'rgba(90,55,30,0.5)';
      g.fillRect(0, r * rh, w, 3);
    }
  }, [5, 5]);
}

function wallpaperTex(base, dot) {
  return tex(256, 256, (g, w, h) => {
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    g.fillStyle = dot;
    // tiny paw prints + dots
    const paw = (x, y, s) => {
      g.beginPath(); g.ellipse(x, y + s * 0.2, s * 0.35, s * 0.28, 0, 0, 7); g.fill();
      for (const [dx, dy] of [[-0.38, -0.2], [-0.13, -0.42], [0.13, -0.42], [0.38, -0.2]]) { g.beginPath(); g.ellipse(x + dx * s, y + dy * s, s * 0.12, s * 0.15, 0, 0, 7); g.fill(); }
    };
    paw(64, 64, 26); paw(192, 192, 26);
    g.beginPath(); g.arc(192, 64, 5, 0, 7); g.arc(64, 192, 5, 0, 7); g.fill();
  }, [10, 3]);
}

function rugTex() {
  return tex(512, 512, (g, w) => {
    const cols = ['#f7a6b8', '#fde2e4', '#f9c6d0', '#fff1f3', '#f4a0b5', '#fde2e4', '#fbd1da'];
    for (let i = 0; i < cols.length; i++) {
      g.fillStyle = cols[i];
      g.beginPath(); g.arc(w / 2, w / 2, w / 2 - i * 34, 0, 7); g.fill();
    }
    g.fillStyle = 'rgba(255,255,255,0.35)';
    for (let i = 0; i < 40; i++) { const a = (i / 40) * Math.PI * 2; g.beginPath(); g.arc(w / 2 + Math.cos(a) * 200, w / 2 + Math.sin(a) * 200, 6, 0, 7); g.fill(); }
  });
}

function sandTex() {
  return tex(256, 256, (g, w, h) => {
    g.fillStyle = '#e9dcc0'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 5000; i++) {
      const l = rand(70, 95);
      g.fillStyle = `hsl(${rand(35, 45)}, ${rand(15, 35)}%, ${l}%)`;
      g.fillRect(rand(0, w), rand(0, h), rand(1, 3), rand(1, 3));
    }
  }, [2, 2]);
}

function skyTex() {
  return tex(256, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#7cc4ff'); gr.addColorStop(1, '#dff3ff');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(255,255,255,0.95)';
    const cloud = (x, y, s) => { for (const [dx, dy, r] of [[0, 0, 1], [0.9, 0.1, 0.8], [-0.9, 0.15, 0.7], [0.4, -0.45, 0.75]]) { g.beginPath(); g.arc(x + dx * s, y + dy * s, r * s, 0, 7); g.fill(); } };
    cloud(70, 80, 22); cloud(190, 140, 16);
    // distant rooftops
    g.fillStyle = '#b8d4e8';
    g.fillRect(0, 205, w, 60);
    for (let x = 0; x < w; x += 40) g.fillRect(x, 190 - (x % 80 ? 10 : 25), 32, 40);
  });
}

function fishArtTex() {
  return tex(256, 200, (g, w, h) => {
    g.fillStyle = '#fff8ee'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#ff9f68';
    g.beginPath(); g.ellipse(115, 100, 60, 35, 0, 0, 7); g.fill();
    g.beginPath(); g.moveTo(170, 100); g.lineTo(215, 65); g.lineTo(215, 135); g.fill();
    g.fillStyle = '#333'; g.beginPath(); g.arc(85, 92, 7, 0, 7); g.fill();
    g.strokeStyle = '#ffd2b5'; g.lineWidth = 5;
    for (const x of [110, 130, 150]) { g.beginPath(); g.arc(x, 100, 22, -0.8, 0.8); g.stroke(); }
  });
}

function catArtTex() {
  return tex(200, 256, (g, w, h) => {
    g.fillStyle = '#eef6ff'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#3a3a48';
    g.beginPath(); g.ellipse(100, 175, 55, 60, 0, 0, 7); g.fill();
    g.beginPath(); g.arc(100, 95, 42, 0, 7); g.fill();
    g.beginPath(); g.moveTo(66, 75); g.lineTo(62, 35); g.lineTo(92, 58); g.fill();
    g.beginPath(); g.moveTo(134, 75); g.lineTo(138, 35); g.lineTo(108, 58); g.fill();
    g.lineWidth = 12; g.strokeStyle = '#3a3a48'; g.lineCap = 'round';
    g.beginPath(); g.moveTo(150, 215); g.quadraticCurveTo(195, 190, 170, 140); g.stroke();
    g.fillStyle = '#ffe066'; g.beginPath(); g.arc(84, 95, 7, 0, 7); g.arc(116, 95, 7, 0, 7); g.fill();
  });
}

function labelTex(bg, fg, text, sub) {
  return tex(256, 128, (g, w, h) => {
    g.fillStyle = bg; g.fillRect(0, 0, w, h);
    g.fillStyle = fg; g.font = '900 44px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(text, w / 2, h * 0.42);
    g.font = '700 22px sans-serif'; g.fillText(sub, w / 2, h * 0.78);
  });
}

function yarnTex(color) {
  return tex(256, 128, (g, w, h) => {
    g.fillStyle = color; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 3;
    for (let i = 0; i < 40; i++) { g.beginPath(); const y = rand(0, h); g.moveTo(0, y); g.bezierCurveTo(w * 0.3, y + rand(-40, 40), w * 0.7, y + rand(-40, 40), w, y + rand(-20, 20)); g.stroke(); }
    g.strokeStyle = 'rgba(0,0,0,0.15)';
    for (let i = 0; i < 25; i++) { g.beginPath(); const y = rand(0, h); g.moveTo(0, y); g.bezierCurveTo(w * 0.3, y + rand(-40, 40), w * 0.7, y + rand(-40, 40), w, y + rand(-20, 20)); g.stroke(); }
  });
}

// ---------------------------------------------------------------------------- world
export class World {
  constructor(scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    scene.add(this.group);
    this.buildRoom();
    this.buildFurniture();
    this.buildKitchen();
    this.buildLitter();
    this.buildBed();
    this.buildToys();
    this.buildStudio();
    this.time = 0;
  }

  buildRoom() {
    const g = this.group;
    const floorMat = std(0xffffff, { map: woodFloorTex(), roughness: 0.6 });
    floorMat.map.repeat.set(5, 5 * 14 / 8);
    this.floor = mesh(new THREE.PlaneGeometry(9, 14), floorMat, V(0, 0, 3), g, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    this.floor.name = 'floor';

    const wallMat = std(0xffffff, { map: wallpaperTex('#fbe7d3', '#f6d6bb') });
    const wallMat2 = std(0xffffff, { map: wallpaperTex('#e3eefa', '#d3e2f3') });
    wallMat2.map.repeat.set(15, 3);
    const H = 3.2;
    const back = mesh(new THREE.PlaneGeometry(9, H), wallMat, V(0, H / 2, -4), g, { cast: false });
    const left = mesh(new THREE.PlaneGeometry(14, H), wallMat2, V(-4.5, H / 2, 3), g, { cast: false, rot: [0, Math.PI / 2, 0] });
    const right = mesh(new THREE.PlaneGeometry(14, H), wallMat2, V(4.5, H / 2, 3), g, { cast: false, rot: [0, -Math.PI / 2, 0] });
    this.walls = [back, left, right];
    // skirting boards
    const skirt = std('#fffaf2');
    mesh(new THREE.BoxGeometry(9, 0.12, 0.04), skirt, V(0, 0.06, -3.98), g);
    mesh(new THREE.BoxGeometry(0.04, 0.12, 14), skirt, V(-4.48, 0.06, 3), g);
    mesh(new THREE.BoxGeometry(0.04, 0.12, 14), skirt, V(4.48, 0.06, 3), g);

    // window on the back wall
    const win = new THREE.Group();
    win.position.set(-0.4, 1.65, -3.99);
    g.add(win);
    mesh(new THREE.PlaneGeometry(1.7, 1.25), new THREE.MeshBasicMaterial({ map: skyTex() }), V(0, 0, 0.005), win, { cast: false, receive: false });
    const frameMat = std('#ffffff', { roughness: 0.5 });
    for (const [w, h, x, y] of [[1.9, 0.1, 0, 0.67], [1.9, 0.1, 0, -0.67], [0.1, 1.35, -0.9, 0], [0.1, 1.35, 0.9, 0], [0.05, 1.3, 0, 0], [1.8, 0.05, 0, 0.05]]) {
      mesh(new THREE.BoxGeometry(w, h, 0.08), frameMat, V(x, y, 0.04), win);
    }
    mesh(rbox(2.1, 0.07, 0.3, 0.02), frameMat, V(0, -0.72, 0.13), win);
    // curtains
    const curtMat = std('#f7a6b8', { side: THREE.DoubleSide });
    for (const sx of [-1, 1]) {
      const cg = new THREE.CylinderGeometry(0.14, 0.2, 1.7, 12, 1, true, 0, Math.PI);
      mesh(cg, curtMat, V(sx * 1.12, -0.05, 0.12), win, { rot: [0, Math.PI / 2 * sx + Math.PI / 2, 0], scale: [1, 1, 0.5] });
    }
    mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.6, 8), std('#c9a27a'), V(0, 0.82, 0.14), win, { rot: [0, 0, Math.PI / 2] });

    // framed pictures
    const pic = (t, w, h, pos, rotY) => {
      const fg = new THREE.Group(); fg.position.copy(pos); fg.rotation.y = rotY; g.add(fg);
      mesh(rbox(w + 0.1, h + 0.1, 0.04, 0.015), std('#c9a27a'), V(0, 0, 0.02), fg);
      mesh(new THREE.PlaneGeometry(w, h), std(0xffffff, { map: t }), V(0, 0, 0.045), fg, { cast: false });
    };
    pic(fishArtTex(), 0.6, 0.47, V(-4.47, 1.7, -1.5), Math.PI / 2);
    pic(catArtTex(), 0.45, 0.58, V(1.6, 1.8, -3.98), 0);
    pic(catArtTex(), 0.45, 0.58, V(4.47, 1.7, 1.6), -Math.PI / 2);
  }

  buildFurniture() {
    const g = this.group;
    // central rug (play area)
    const rug = mesh(new THREE.CircleGeometry(1.7, 64), std(0xffffff, { map: rugTex(), roughness: 1 }), V(SPOTS.play.x, 0.004, SPOTS.play.z), g, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    rug.name = 'rug';

    // sofa against the back wall
    const sofa = new THREE.Group();
    sofa.position.set(1.4, 0, -3.45);
    g.add(sofa);
    const sm = std('#8fb8de', { roughness: 0.95 });
    mesh(rbox(2.2, 0.35, 0.8, 0.08), sm, V(0, 0.3, 0), sofa);
    mesh(rbox(2.2, 0.6, 0.22, 0.08), sm, V(0, 0.7, -0.3), sofa);
    for (const sx of [-1, 1]) mesh(rbox(0.22, 0.5, 0.8, 0.08), sm, V(sx * 1.1, 0.5, 0), sofa);
    for (const sx of [-0.5, 0.5]) mesh(rbox(1.0, 0.14, 0.62, 0.06), std('#a7c8e8', { roughness: 1 }), V(sx, 0.52, 0.06), sofa);
    mesh(rbox(0.36, 0.3, 0.12, 0.06), std('#ffd6a5'), V(-0.62, 0.72, -0.12), sofa, { rot: [0.2, 0, 0.2] });
    for (const [x, z] of [[-1, -0.3], [1, -0.3], [-1, 0.3], [1, 0.3]]) mesh(new THREE.CylinderGeometry(0.03, 0.025, 0.12, 8), std('#8a6040'), V(x, 0.06, z), sofa);

    // plant
    const plant = new THREE.Group();
    plant.position.set(-1.75, 0, -3.55);
    g.add(plant);
    const pts = []; for (let i = 0; i <= 8; i++) pts.push(new THREE.Vector2(0.16 + i * 0.012, i * 0.05));
    mesh(new THREE.LatheGeometry(pts, 20), std('#e07a5f'), V(0, 0, 0), plant);
    const leafMat = std('#5cae6a', { side: THREE.DoubleSide });
    for (let i = 0; i < 11; i++) {
      const lg = new THREE.SphereGeometry(0.12, 10, 8);
      const a = (i / 11) * Math.PI * 2;
      const leaf = mesh(lg, leafMat, V(Math.cos(a) * 0.12, 0.55 + rand(0, 0.35), Math.sin(a) * 0.12), plant, { scale: [0.55, 1.6, 0.18] });
      leaf.rotation.set(Math.sin(a) * 0.5, -a, Math.cos(a) * 0.5);
    }
    mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.6, 6), std('#4d7c3a'), V(0, 0.4, 0), plant);

    // cat tree (right side)
    const tree = new THREE.Group();
    tree.position.set(3.75, 0, 1.1);
    g.add(tree);
    const carpet = std('#d8c3a5', { roughness: 1 });
    const rope = std('#c2a878', { roughness: 1 });
    mesh(rbox(0.9, 0.08, 0.9, 0.03), carpet, V(0, 0.04, 0), tree);
    mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.1, 14), rope, V(-0.2, 0.6, -0.2), tree);
    mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.6, 14), rope, V(0.2, 0.85, 0.2), tree);
    mesh(rbox(0.7, 0.07, 0.6, 0.03), carpet, V(-0.15, 1.15, -0.15), tree);
    mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.08, 24), carpet, V(0.2, 1.68, 0.2), tree);
    mesh(new THREE.TorusGeometry(0.26, 0.06, 10, 24), carpet, V(0.2, 1.74, 0.2), tree, { rot: [Math.PI / 2, 0, 0] });
    // dangling pompom
    mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.3, 4), std('#555'), V(-0.4, 0.98, -0.15), tree);
    mesh(new THREE.SphereGeometry(0.05, 12, 10), std('#ff6b9a'), V(-0.4, 0.82, -0.15), tree);

    // floor lamp
    const lamp = new THREE.Group();
    lamp.position.set(-3.9, 0, -2.0);
    g.add(lamp);
    mesh(new THREE.CylinderGeometry(0.18, 0.2, 0.04, 20), std('#555'), V(0, 0.02, 0), lamp);
    mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.6, 8), std('#555'), V(0, 0.8, 0), lamp);
    mesh(new THREE.CylinderGeometry(0.18, 0.28, 0.3, 20, 1, true), std('#fff4d6', { side: THREE.DoubleSide, emissive: '#ffe8b0', emissiveIntensity: 0.6 }), V(0, 1.65, 0), lamp);
    const pl = new THREE.PointLight('#ffd8a0', 3, 5, 1.5);
    pl.position.set(0, 1.55, 0);
    lamp.add(pl);
  }

  buildKitchen() {
    const g = this.group;
    // placemat
    mesh(rbox(1.35, 0.012, 0.62, 0.005), std('#9ad0b8', { roughness: 1 }), V(-2.95, 0.006, -3.12), g, { cast: false });
    // bowl profile (lathe)
    const bowlProfile = (r, h) => {
      const p = [];
      p.push(new THREE.Vector2(0.0, 0.0));
      p.push(new THREE.Vector2(r * 0.8, 0.0));
      p.push(new THREE.Vector2(r * 0.95, h * 0.3));
      p.push(new THREE.Vector2(r, h * 0.85));
      p.push(new THREE.Vector2(r * 0.98, h));
      p.push(new THREE.Vector2(r * 0.9, h));
      p.push(new THREE.Vector2(r * 0.82, h * 0.35));
      p.push(new THREE.Vector2(r * 0.6, h * 0.18));
      p.push(new THREE.Vector2(0, h * 0.18));
      return p;
    };
    const makeBowl = (pos, color, label) => {
      const bg = new THREE.Group();
      bg.position.copy(pos);
      g.add(bg);
      mesh(new THREE.LatheGeometry(bowlProfile(0.17, 0.09), 40), std(color, { roughness: 0.35, side: THREE.DoubleSide }), V(0, 0.012, 0), bg);
      return bg;
    };
    this.bowl = makeBowl(SPOTS.bowl, '#ff8fab');
    this.waterBowl = makeBowl(SPOTS.water, '#74c0fc');
    // fish decoration on bowl rim
    const fishMat = std('#ffffff');
    mesh(new THREE.SphereGeometry(0.02, 10, 8), fishMat, V(0, 0.07, 0.165), this.bowl, { scale: [1.6, 1, 0.5] });

    // food mound: a flattened sphere cap scaled with fill level
    this.foodMats = {
      kibble: std('#b5733a', { roughness: 0.9 }),
      wet: std('#a8584e', { roughness: 0.45 }),
    };
    const moundGeo = new THREE.SphereGeometry(0.13, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2);
    this.foodMound = mesh(moundGeo, this.foodMats.kibble, V(0, 0.028, 0), this.bowl, { cast: false });
    this.foodMound.visible = false;
    // lumpy kibble texture via small instanced bits on top
    this.kibbleTop = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(0.012, 0), this.foodMats.kibble, 60);
    this.kibbleTop.castShadow = false;
    const m = new THREE.Matrix4();
    for (let i = 0; i < 60; i++) {
      const a = rand(0, Math.PI * 2), r = Math.sqrt(Math.random()) * 0.12;
      const y = Math.sqrt(Math.max(0, 0.13 * 0.13 - r * r));
      m.compose(V(Math.cos(a) * r, y, Math.sin(a) * r), new THREE.Quaternion().setFromEuler(new THREE.Euler(rand(0, 6), rand(0, 6), 0)), V(1, 0.7, 1));
      this.kibbleTop.setMatrixAt(i, m);
    }
    this.foodMound.add(this.kibbleTop);

    this.water = mesh(new THREE.CircleGeometry(0.142, 32), std('#8fd3ff', { transparent: true, opacity: 0.75, roughness: 0.05, metalness: 0.1 }), V(0, 0.05, 0), this.waterBowl, { cast: false, rot: [-Math.PI / 2, 0, 0] });

    // food storage: kibble bag + cans on a little shelf
    this.kibbleBag = this.makeKibbleBag();
    this.kibbleBag.position.set(-3.95, 0, -3.55);
    this.kibbleBag.rotation.y = 0.5;
    g.add(this.kibbleBag);
  }

  makeKibbleBag() {
    const bag = new THREE.Group();
    const t = labelTex('#ffb703', '#7a3e00', 'CRUNCHY', '♥ kibble ♥');
    const mat = [std('#ffb703'), std('#ffb703'), std('#e09a00'), std('#ffb703'), std(0xffffff, { map: t }), std('#ffb703')];
    mesh(new THREE.BoxGeometry(0.3, 0.42, 0.16), mat, V(0, 0.21, 0), bag);
    mesh(new THREE.BoxGeometry(0.3, 0.04, 0.05), std('#e09a00'), V(0, 0.44, 0), bag);
    return bag;
  }

  makeCan() {
    const can = new THREE.Group();
    const t = labelTex('#8ecae6', '#023047', 'TUNA', 'pâté for kitties');
    t.wrapS = THREE.RepeatWrapping;
    mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.07, 24, 1, true), std(0xffffff, { map: t, side: THREE.DoubleSide }), V(0, 0, 0), can);
    mesh(new THREE.CylinderGeometry(0.071, 0.071, 0.008, 24), std('#cfd4da', { metalness: 0.8, roughness: 0.3 }), V(0, -0.036, 0), can);
    mesh(new THREE.CylinderGeometry(0.066, 0.066, 0.004, 24), std('#a8584e', { roughness: 0.5 }), V(0, 0.03, 0), can);
    return can;
  }

  makeTreat() {
    const t = new THREE.Group();
    const mat = std('#ff9f43', { roughness: 0.6 });
    mesh(new THREE.SphereGeometry(0.03, 14, 10), mat, V(0, 0, 0), t, { scale: [1.6, 0.9, 0.7] });
    mesh(new THREE.ConeGeometry(0.025, 0.035, 3), mat, V(-0.055, 0, 0), t, { rot: [0, 0, Math.PI / 2], scale: [1, 1, 0.4] });
    mesh(new THREE.SphereGeometry(0.005, 6, 6), std('#222'), V(0.03, 0.007, 0.018), t);
    return t;
  }

  makePitcher() {
    const p = new THREE.Group();
    const pts = []; for (let i = 0; i <= 10; i++) pts.push(new THREE.Vector2(0.07 + Math.sin(i / 10 * Math.PI) * 0.015, i * 0.018));
    mesh(new THREE.LatheGeometry(pts, 24), std('#bde0fe', { transparent: true, opacity: 0.7, roughness: 0.1, side: THREE.DoubleSide }), V(0, -0.09, 0), p);
    mesh(new THREE.TorusGeometry(0.045, 0.01, 8, 16, Math.PI), std('#bde0fe'), V(-0.085, 0, 0), p, { rot: [0, 0, Math.PI / 2] });
    return p;
  }

  buildLitter() {
    const g = this.group;
    const box = (this.litterBox = new THREE.Group());
    box.position.copy(SPOTS.litter);
    g.add(box);
    const W = 1.0, D = 0.72, H = 0.26, T = 0.035;
    this.litterDims = { W, D, H };
    const plastic = std('#b8e0d2', { roughness: 0.45 });
    mesh(rbox(W, 0.04, D, 0.015), plastic, V(0, 0.02, 0), box);
    mesh(rbox(W, H, T, 0.015), plastic, V(0, H / 2, D / 2 - T / 2), box);
    mesh(rbox(W, H, T, 0.015), plastic, V(0, H / 2, -D / 2 + T / 2), box);
    mesh(rbox(T, H, D, 0.015), plastic, V(W / 2 - T / 2, H / 2, 0), box);
    mesh(rbox(T, H, D, 0.015), plastic, V(-W / 2 + T / 2, H / 2, 0), box);
    // lower entry lip at the front
    this.sand = mesh(new THREE.BoxGeometry(W - T * 2, 1, D - T * 2, 24, 1, 16), std(0xffffff, { map: sandTex(), roughness: 1 }), V(0, 0, 0), box, { cast: false });
    // bumpy top surface
    const pos = this.sand.geometry.attributes.position;
    for (let i = 0; i < pos.count; i++) if (pos.getY(i) > 0.4) pos.setY(i, 0.5 + rand(-0.01, 0.01) * 1.5);
    this.sand.geometry.computeVertexNormals();
    this.setLitterLevel(1);
    // mat in front
    mesh(rbox(1.2, 0.01, 0.4, 0.004), std('#cdb4db', { roughness: 1 }), V(0, 0.005, D / 2 + 0.24), box, { cast: false });

    // trash can with a flip lid
    const trash = (this.trash = new THREE.Group());
    trash.position.copy(SPOTS.trash);
    g.add(trash);
    mesh(new THREE.CylinderGeometry(0.2, 0.17, 0.5, 24), std('#adb5bd', { metalness: 0.6, roughness: 0.35 }), V(0, 0.25, 0), trash);
    mesh(new THREE.BoxGeometry(0.12, 0.02, 0.06), std('#495057'), V(0, 0.01, 0.2), trash);
    this.trashLid = new THREE.Group();
    this.trashLid.position.set(0, 0.5, -0.2);
    trash.add(this.trashLid);
    mesh(new THREE.CylinderGeometry(0.205, 0.205, 0.03, 24), std('#ced4da', { metalness: 0.6, roughness: 0.3 }), V(0, 0.015, 0.2), this.trashLid);
    this.trashLidOpen = 0;

    // litter bag
    const bag = new THREE.Group();
    bag.position.set(4.22, 0, -1.25);
    bag.rotation.y = -1.2;
    g.add(bag);
    const lt = labelTex('#cdb4db', '#4a2c6f', 'LITTER', 'clumping · fresh');
    const mat = [std('#cdb4db'), std('#cdb4db'), std('#b79cc9'), std('#cdb4db'), std(0xffffff, { map: lt }), std('#cdb4db')];
    mesh(new THREE.BoxGeometry(0.34, 0.5, 0.2), mat, V(0, 0.25, 0), bag);
    this.litterBag = bag;

    // scoop tool
    this.scoop = this.makeScoop();
    this.scoop.visible = false;
    g.add(this.scoop);
    this.scoopRest = new THREE.Vector3(3.95, 0.02, -3.5);
  }

  makeScoop() {
    const s = new THREE.Group();
    const mat = std('#ff8fab', { roughness: 0.4 });
    const slot = tex(128, 128, (g2) => {
      g2.fillStyle = '#ff8fab'; g2.fillRect(0, 0, 128, 128);
      g2.fillStyle = '#9c4058';
      for (let i = 0; i < 6; i++) g2.fillRect(14 + i * 19, 16, 8, 96);
    });
    const slotMat = std(0xffffff, { map: slot, roughness: 0.4 });
    mesh(new THREE.BoxGeometry(0.16, 0.008, 0.14), [mat, mat, slotMat, mat, mat, mat], V(0, 0, 0), s);
    for (const sx of [-1, 1]) mesh(rbox(0.012, 0.035, 0.14, 0.004), mat, V(sx * 0.074, 0.016, 0), s);
    mesh(rbox(0.16, 0.035, 0.012, 0.004), mat, V(0, 0.016, -0.068), s);
    // handle rises toward the viewer
    mesh(new THREE.CylinderGeometry(0.013, 0.015, 0.26, 10), mat, V(0, 0.07, 0.19), s, { rot: [1.1, 0, 0] });
    return s;
  }

  setLitterLevel(k) {
    // k in [0,1]: sand depth
    const depth = 0.05 + 0.12 * k;
    this.sand.scale.y = depth;
    this.sand.position.y = depth / 2 + 0.035;
    this.sandTop = depth + 0.035;
    if (this.clumpMeshes) for (const m of this.clumpMeshes.values()) if (!m.userData.held) m.position.y = this.sandTop - 0.004;
  }

  // Keep litter-box clump meshes in sync with the saved list (box-local coordinates).
  syncClumps(list) {
    this.clumpMeshes = this.clumpMeshes || new Map();
    const ids = new Set(list.map((c) => c.id));
    for (const [id, m] of this.clumpMeshes) {
      if (!ids.has(id)) { m.parent?.remove(m); this.clumpMeshes.delete(id); }
    }
    for (const c of list) {
      if (this.clumpMeshes.has(c.id)) continue;
      const m = this.makeClump(c.type);
      m.position.set(c.x, this.sandTop - 0.004, c.z);
      m.rotation.y = c.rot;
      m.userData.clump = c;
      this.litterBox.add(m);
      this.clumpMeshes.set(c.id, m);
    }
  }

  // Reflect bowl contents (0..1) in the meshes.
  updateBowls(bowl, water) {
    const f = bowl.food;
    this.foodMound.visible = f > 0.005;
    if (this.foodMound.visible) {
      const r = 0.45 + 0.55 * Math.sqrt(Math.min(1, f));
      this.foodMound.scale.set(r, 0.15 + 0.55 * Math.min(1, f), r);
      this.foodMound.material = this.foodMats[bowl.kind] || this.foodMats.kibble;
      this.kibbleTop.visible = bowl.kind !== 'wet';
    }
    this.water.visible = water > 0.01;
    this.water.position.y = 0.03 + 0.055 * Math.min(1, water);
    this.water.scale.setScalar(0.8 + 0.2 * Math.min(1, water));
  }

  // Poop "logs" and pee clumps sitting in the litter.
  makeClump(type) {
    const c = new THREE.Group();
    if (type === 'poop') {
      const mat = std('#6b4226', { roughness: 0.7 });
      const n = 2 + Math.floor(rand(0, 2));
      for (let i = 0; i < n; i++) {
        const cg = new THREE.CapsuleGeometry(0.018, 0.04, 4, 8);
        const m = mesh(cg, mat, V(i * 0.03 - 0.03, 0.012, rand(-0.015, 0.015)), c, { rot: [Math.PI / 2 + rand(-0.3, 0.3), rand(-0.6, 0.6), rand(-0.3, 0.3)] });
        m.scale.setScalar(rand(0.85, 1.1));
      }
    } else {
      const mat = std('#cbb892', { roughness: 1 });
      const geo = new THREE.IcosahedronGeometry(0.04, 2);
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) { const k = 1 + rand(-0.18, 0.18); p.setXYZ(i, p.getX(i) * k, p.getY(i) * k * 0.6, p.getZ(i) * k); }
      geo.computeVertexNormals();
      mesh(geo, mat, V(0, 0.008, 0), c);
    }
    c.userData.type = type;
    return c;
  }

  buildBed() {
    const g = this.group;
    const bed = (this.bed = new THREE.Group());
    bed.position.copy(SPOTS.bed);
    g.add(bed);
    mesh(new THREE.TorusGeometry(0.47, 0.095, 16, 48), std('#c3a6e8', { roughness: 1 }), V(0, 0.07, 0), bed, { rot: [Math.PI / 2, 0, 0], scale: [1, 1, 1.1] });
    mesh(new THREE.CylinderGeometry(0.48, 0.5, 0.06, 40), std('#f5ecff', { roughness: 1 }), V(0, 0.03, 0), bed);
    this.bedTop = 0.06;
    // blanket
    mesh(rbox(0.5, 0.02, 0.35, 0.01), std('#ffd6a5', { roughness: 1 }), V(0.55, 0.01, 0.35), bed, { rot: [0, 0.4, 0] });
  }

  buildToys() {
    const g = this.group;
    // yarn ball
    this.yarn = new THREE.Group();
    mesh(new THREE.SphereGeometry(0.06, 24, 18), std(0xffffff, { map: yarnTex('#ff6b9a'), roughness: 1 }), V(0, 0, 0), this.yarn);
    const tailCurve = new THREE.CatmullRomCurve3([V(0.05, -0.03, 0), V(0.12, -0.055, 0.03), V(0.2, -0.058, -0.02), V(0.28, -0.058, 0.02)]);
    mesh(new THREE.TubeGeometry(tailCurve, 20, 0.004, 5), std('#ff6b9a'), null, this.yarn);
    this.yarn.visible = false;
    g.add(this.yarn);

    // feather wand
    this.wand = new THREE.Group();
    this.wandStick = mesh(new THREE.CylinderGeometry(0.008, 0.01, 1.2, 8), std('#e9c46a'), V(0, 0, 0), g, { cast: true });
    this.wandStick.visible = false;
    this.feather = new THREE.Group();
    const fcols = ['#4cc9f0', '#f72585', '#ffd60a'];
    fcols.forEach((c, i) => {
      const fg = new THREE.SphereGeometry(0.04, 12, 8);
      const f = mesh(fg, std(c, { roughness: 1 }), V(0, -0.05, 0), this.feather, { scale: [0.35, 1.6, 0.1] });
      f.rotation.set(0, i * 1.1, (i - 1) * 0.5);
      f.position.set((i - 1) * 0.015, -0.05, 0);
    });
    mesh(new THREE.SphereGeometry(0.014, 10, 8), std('#9d4edd'), V(0, 0, 0), this.feather);
    this.feather.scale.setScalar(1.8);
    this.feather.visible = false;
    g.add(this.feather);
    this.wandString = new THREE.Line(new THREE.BufferGeometry().setFromPoints(Array.from({ length: 11 }, (_, i) => V(0, i / 10, 0))), new THREE.LineBasicMaterial({ color: '#555' }));
    this.wandString.visible = false;
    this.wandString.frustumCulled = false;
    g.add(this.wandString);

    // laser dot
    this.laser = new THREE.Group();
    mesh(new THREE.CircleGeometry(0.014, 16), new THREE.MeshBasicMaterial({ color: '#ff2020' }), V(0, 0.006, 0), this.laser, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    const glowT = tex(64, 64, (g2) => { const gr = g2.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,60,60,0.9)'); gr.addColorStop(1, 'rgba(255,0,0,0)'); g2.fillStyle = gr; g2.fillRect(0, 0, 64, 64); });
    mesh(new THREE.PlaneGeometry(0.12, 0.12), new THREE.MeshBasicMaterial({ map: glowT, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }), V(0, 0.007, 0), this.laser, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    this.laser.visible = false;
    g.add(this.laser);
  }

  buildStudio() {
    // Adoption "photo studio": a curved backdrop and a round pedestal, away from the room.
    const st = (this.studio = new THREE.Group());
    st.position.copy(SPOTS.studio);
    this.scene.add(st);
    const bgT = tex(16, 256, (g2, w, h) => {
      const gr = g2.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#ffd1e3'); gr.addColorStop(0.55, '#ffe9d6'); gr.addColorStop(1, '#fff5ea');
      g2.fillStyle = gr; g2.fillRect(0, 0, w, h);
    });
    mesh(new THREE.CylinderGeometry(6, 6, 6, 48, 1, true, Math.PI * 0.5, Math.PI), new THREE.MeshBasicMaterial({ map: bgT, side: THREE.BackSide }), V(0, 3, 1), st, { cast: false, receive: false, rot: [0, Math.PI, 0] });
    mesh(new THREE.CircleGeometry(6, 48), std('#fff1e6', { roughness: 1 }), V(0, 0, 1), st, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    this.pedestal = new THREE.Group();
    st.add(this.pedestal);
    mesh(new THREE.CylinderGeometry(0.62, 0.66, 0.14, 48), std('#ffffff', { roughness: 0.5 }), V(0, 0.07, 0), this.pedestal);
    mesh(new THREE.TorusGeometry(0.64, 0.025, 8, 48), std('#ff8fab', { roughness: 0.4 }), V(0, 0.12, 0), this.pedestal, { rot: [Math.PI / 2, 0, 0] });
    // paw prints on the pedestal top
    const pawT = tex(256, 256, (g2) => {
      g2.fillStyle = '#ffffff'; g2.fillRect(0, 0, 256, 256);
      g2.fillStyle = '#ffe0ea';
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * Math.PI * 2, x = 128 + Math.cos(a) * 95, y = 128 + Math.sin(a) * 95;
        g2.beginPath(); g2.ellipse(x, y, 14, 11, 0, 0, 7); g2.fill();
        for (const [dx, dy] of [[-13, -12], [-5, -19], [5, -19], [13, -12]]) { g2.beginPath(); g2.arc(x + dx, y + dy, 5, 0, 7); g2.fill(); }
      }
    });
    mesh(new THREE.CircleGeometry(0.62, 48), std(0xffffff, { map: pawT, roughness: 0.6 }), V(0, 0.141, 0), this.pedestal, { cast: false, rot: [-Math.PI / 2, 0, 0] });
    this.pedestalTop = 0.141;
    // floating decorations
    this.studioDeco = [];
    const cols = ['#ffadc6', '#bde0fe', '#ffe066', '#caffbf', '#d0bfff'];
    for (let i = 0; i < 14; i++) {
      const a = rand(-1.2, 1.2) + Math.PI;
      const r = rand(2.5, 4.5);
      const d = mesh(new THREE.SphereGeometry(rand(0.08, 0.2), 16, 12), std(cols[i % cols.length], { roughness: 0.4 }), V(Math.sin(a) * r * -1, rand(0.6, 3), Math.cos(a) * r + 1), st, { cast: false });
      d.userData.base = d.position.y;
      d.userData.phase = rand(0, 6);
      this.studioDeco.push(d);
    }
  }

  update(dt) {
    this.time += dt;
    for (const d of this.studioDeco) d.position.y = d.userData.base + Math.sin(this.time * 0.8 + d.userData.phase) * 0.1;
    this.trashLidOpen = Math.max(0, this.trashLidOpen - dt * 1.5);
    this.trashLid.rotation.x = -Math.min(1, this.trashLidOpen * 2) * 1.2;
  }
}
