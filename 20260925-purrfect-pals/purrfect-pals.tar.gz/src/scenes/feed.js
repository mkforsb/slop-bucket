// Feed the cat: pour kibble (with physics!), spoon out wet food, toss treats, refill water.

import * as THREE from 'three';
import { SPOTS } from '../world.js';
import { state, add } from '../state.js';
import { audio } from '../audio.js';
import { ui } from '../ui.js';
import { rand, clamp, damp, lerp } from '../util.js';
import { walk, eatFromBowl, drink, BOWL_FRONT } from '../behaviors.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const MAX_KIBBLE = 400;
const WAIT = V(-2.05, 0, -2.5);
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3(1, 1, 1);

export class FeedScene {
  constructor(G) {
    this.G = G;
    const w = G.world;
    this.items = {
      kibble: this.wrap(w.makeKibbleBag(), V(0, -0.21, 0)),
      wet: this.wrap(w.makeCan(), V(0, 0, 0)),
      treat: this.wrap(w.makeTreat(), V(0, 0, 0)),
      water: this.wrap(w.makePitcher(), V(0, 0, 0)),
    };
    for (const k in this.items) { this.items[k].visible = false; G.scene.add(this.items[k]); }
    this.items.treat.scale.setScalar(1.5);
    this.items.kibble.scale.setScalar(0.7);
    // kibble particles
    this.kib = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(0.011, 0), w.foodMats.kibble, MAX_KIBBLE);
    this.kib.castShadow = true;
    this.kib.count = 0;
    this.kib.frustumCulled = false;
    G.scene.add(this.kib);
    this.parts = [];
    // wet food dollops and tossed treats
    this.blobs = [];
    this.treats = [];
    this.aim = V(SPOTS.bowl.x, 0, SPOTS.bowl.z);
    this.tilt = 0;
  }

  wrap(obj, offset) {
    const g = new THREE.Group();
    obj.position.copy(offset);
    g.add(obj);
    return g;
  }

  enter() {
    const G = this.G;
    G.cam.set(V(-1.95, 1.4, -1.05), V(-2.85, 0.08, -2.95), 44);
    G.setShadowFocus(V(-2.9, 0, -2.8), 2.2);
    const p = G.cat.root.position;
    if (p.x > 20 || Math.hypot(p.x - BOWL_FRONT.x, p.z - BOWL_FRONT.z) > 1.4) G.cat.place(WAIT.x, WAIT.z, -2.3);
    this.tool = 'kibble';
    this.pouring = false;
    this.lastServe = -10;
    this.fullWarned = false;
    ui.setTools([
      { id: 'kibble', emoji: '🥣', label: 'Kibble', onClick: () => this.setTool('kibble') },
      { id: 'wet', emoji: '🥫', label: 'Wet food', onClick: () => this.setTool('wet') },
      { id: 'treat', emoji: '🐟', label: 'Treat', onClick: () => this.setTool('treat') },
      { id: 'water', emoji: '💧', label: 'Water', onClick: () => this.setTool('water') },
    ], 'kibble');
    this.setTool('kibble');
    G.canvas.style.cursor = 'none';
    G.task.run((tk) => this.brain(tk));
  }

  exit() {
    for (const k in this.items) this.items[k].visible = false;
    for (const b of this.blobs) this.G.scene.remove(b.mesh);
    for (const t of this.treats) this.G.scene.remove(t.mesh);
    this.blobs = []; this.treats = []; this.parts = [];
    this.kib.count = 0;
    this.pouring = false;
  }

  setTool(t) {
    this.tool = t;
    for (const k in this.items) this.items[k].visible = k === t;
    const hints = {
      kibble: 'Press and hold over the pink bowl to pour kibble',
      wet: 'Tap over the bowl to spoon out some tasty wet food',
      treat: 'Tap the floor to toss a treat — in moderation!',
      water: 'Press and hold over the blue bowl to pour fresh water',
    };
    ui.hint(hints[t]);
  }

  // ------------------------------------------------------------------ cat brain
  async brain(tk) {
    const G = this.G, cat = G.cat;
    while (true) {
      const treat = this.treats.find((t) => t.landed && !t.claimed);
      if (treat) { await this.eatTreat(tk, treat); continue; }
      const idle = G.clock.time - this.lastServe > 0.8 && !this.pouring;
      if (idle && state.bowl.food > 0.04 && !this.blobs.length && G.clock.time > (this.refuseUntil || 0)) {
        cat.lookAt(null);
        const ate = await eatFromBowl(G, tk);
        if (!ate) this.refuseUntil = G.clock.time + 12;
        if (ate && state.water > 0.2 && Math.random() < 0.5) await drink(G, tk);
        await walk(G, tk, WAIT.x, WAIT.z, 0.4);
        continue;
      }
      if (idle && this.freshWater && state.water > 0.3) {
        this.freshWater = false;
        await drink(G, tk);
        await walk(G, tk, WAIT.x, WAIT.z, 0.4);
        continue;
      }
      // waiting: watch the food with big eyes
      cat.setPose(this.pouring ? 'stand' : 'sit');
      cat.faceToward(this.aim.x, this.aim.z);
      cat.lookAt(this.itemPos());
      cat.setMood({ pupil: this.pouring ? 1.35 : 1.1 });
      cat.setTail(this.pouring ? 'happy' : 'neutral');
      if (this.pouring && Math.random() < 0.08) cat.meow({ style: 'chirp' });
      await tk.sleep(0.3);
    }
  }

  async eatTreat(tk, treat) {
    const G = this.G, cat = G.cat;
    treat.claimed = true;
    cat.lookAt(treat.mesh.position);
    if (state.treatsRecent > 5) {
      cat.faceToward(treat.mesh.position.x, treat.mesh.position.z);
      cat.setPose('sit');
      G.fx.emote(cat, 'question');
      ui.toast(`${state.name} has had enough treats for now`, 'info');
      await tk.sleep(1.5);
      this.removeTreat(treat);
      return;
    }
    const d = cat.root.position.distanceTo(treat.mesh.position);
    const dir = new THREE.Vector3().subVectors(treat.mesh.position, cat.root.position).setY(0).normalize();
    const stop = treat.mesh.position.clone().addScaledVector(dir, -0.2);
    if (d > 0.5 && d < 1.3) {
      cat.setPose('crouch');
      cat.wiggle = 1;
      await tk.sleep(0.5);
      cat.wiggle = 0;
      await tk.guard(cat.jumpTo(stop.x, stop.z, 0.18, 0.45));
    } else {
      await walk(G, tk, stop.x, stop.z, 0.8);
    }
    cat.faceToward(treat.mesh.position.x, treat.mesh.position.z);
    cat.setPose('eat');
    await tk.sleep(0.4);
    audio.crunch();
    this.removeTreat(treat);
    await tk.sleep(0.35);
    audio.crunch();
    state.treatsRecent += 1;
    add('love', 5); add('hunger', 3);
    cat.setPose('sit');
    cat.setMood({ eyes: 'happy', blush: 1 });
    G.fx.emote(cat, 'heart', 2);
    if (state.treatsRecent > 3.5) ui.toast('Tip: treats should be under 10% of a cat\'s diet 🐟', 'info', 3);
    await tk.sleep(1);
    cat.resetMood();
  }

  removeTreat(t) {
    this.G.scene.remove(t.mesh);
    this.treats = this.treats.filter((x) => x !== t);
  }

  // ------------------------------------------------------------------ input
  itemPos() { return this.items[this.tool].position; }

  pointerMove() {
    const p = this.G.rayPlane(0.0);
    if (p) this.aim.set(clamp(p.x, -4.2, -1.5), 0, clamp(p.z, -3.8, -1.4));
  }

  pointerDown(e) {
    this.pointerMove(e);
    const bowlD = Math.hypot(this.aim.x - SPOTS.bowl.x, this.aim.z - SPOTS.bowl.z);
    if (this.tool === 'kibble' || this.tool === 'water') { this.pouring = true; if (this.tool === 'kibble') audio.pour(); }
    if (this.tool === 'wet') {
      this.tilt = 1;
      if (bowlD < 0.32) this.dropWet();
      else ui.toast('Aim for the bowl!', 'info', 1.2);
    }
    if (this.tool === 'treat') this.throwTreat();
  }

  pointerUp() {
    if (this.pouring) this.lastServe = this.G.clock.time;
    this.pouring = false;
  }

  dropWet() {
    if (state.bowl.food >= 0.98) { ui.toast('The bowl is already full!', 'info', 1.5); return; }
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.035, 12, 10), this.G.world.foodMats.wet);
    mesh.position.copy(this.items.wet.position).add(V(0.05, -0.05, 0));
    mesh.scale.set(1, 0.8, 1);
    mesh.castShadow = true;
    this.G.scene.add(mesh);
    this.blobs.push({ mesh, vel: V(0, 0, 0) });
    this.lastServe = this.G.clock.time;
  }

  throwTreat() {
    const G = this.G;
    const from = this.items.treat.position.clone();
    const to = this.aim.clone();
    const mesh = G.world.makeTreat();
    mesh.scale.setScalar(1.5);
    mesh.position.copy(from);
    G.scene.add(mesh);
    const T = 0.6;
    const vel = V((to.x - from.x) / T, 0, (to.z - from.z) / T);
    vel.y = (to.y + 0.02 - from.y + 4.9 * T * T) / T;
    this.treats.push({ mesh, vel, landed: false, claimed: false });
    audio.swish();
    this.items.treat.visible = false;
    setTimeout(() => { if (this.tool === 'treat') this.items.treat.visible = true; }, 500);
  }

  // ------------------------------------------------------------------ per-frame
  update(dt) {
    const G = this.G;
    const t = G.clock.time;
    const bowl = SPOTS.bowl, water = SPOTS.water;
    const pouringNow = this.pouring && (this.tool === 'kibble' || this.tool === 'water');
    this.tilt = damp(this.tilt, pouringNow ? 1 : 0, this.tool === 'wet' ? 5 : 8, dt);

    // held item placement
    const it = this.items[this.tool];
    const a = this.aim;
    if (this.tool === 'kibble') {
      it.position.set(a.x - 0.2 * this.tilt, 0.46 + 0.04 * this.tilt, a.z);
      it.rotation.set(0, 0, -0.2 - 1.75 * this.tilt);
    } else if (this.tool === 'wet') {
      it.position.set(a.x - 0.05 * this.tilt, 0.32, a.z);
      it.rotation.set(0, 0, -2.0 * this.tilt);
    } else if (this.tool === 'water') {
      it.position.set(a.x - 0.12 * this.tilt, 0.36, a.z);
      it.rotation.set(0, 0, -1.3 * this.tilt);
    } else {
      it.position.set(a.x, 0.28 + Math.sin(t * 3) * 0.015, a.z);
      it.rotation.set(0, t, 0);
    }

    // pour kibble
    if (this.tool === 'kibble' && this.pouring && this.tilt > 0.7) {
      this.spawnAcc = (this.spawnAcc || 0) + dt * 45;
      const spout = V(0, 0.44, 0);
      this.items.kibble.children[0].localToWorld(spout);
      while (this.spawnAcc > 1) {
        this.spawnAcc -= 1;
        if (this.parts.length < MAX_KIBBLE) {
          this.parts.push({ p: spout.clone().add(V(rand(-0.02, 0.02), 0, rand(-0.03, 0.03))), v: V(rand(0.1, 0.35), rand(-0.1, 0.1), rand(-0.12, 0.12)), rot: V(rand(0, 6), rand(0, 6), rand(0, 6)), state: 'fall', age: 0 });
        }
      }
      this.pourSnd = (this.pourSnd || 0) - dt;
      if (this.pourSnd < 0) { this.pourSnd = 0.3; audio.pour(); }
      this.lastServe = t;
    }

    // pour water
    if (this.tool === 'water' && this.pouring && this.tilt > 0.6) {
      const spout = V(0.08, 0.06, 0);
      this.items.water.children[0].localToWorld(spout);
      if (Math.random() < 0.7) G.fx.spawn('drop', spout, { vel: V(rand(0.1, 0.25), 0, rand(-0.05, 0.05)), gravity: -6, size: 0.022, life: 0.5, pop: false, grow: 0, wobble: 0, drag: 0, floor: 0.04 });
      if (Math.hypot(a.x - 0.12 - water.x, a.z - water.z) < 0.25) {
        state.water = Math.min(1, state.water + dt * 0.35);
        this.freshWater = true;
        if (state.water >= 1 && !this.waterWarned) { ui.toast('Fresh water, all topped up! 💧', 'good', 1.6); this.waterWarned = true; }
      }
      this.splashT = (this.splashT || 0) - dt;
      if (this.splashT < 0) { this.splashT = 0.35; audio.splash(); }
      this.lastServe = t;
    } else if (!this.pouring) this.waterWarned = false;

    // kibble physics
    const surface = () => 0.03 + 0.09 * Math.min(1, state.bowl.food) * 0.7;
    let tickSnd = 0;
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const k = this.parts[i];
      k.age += dt;
      if (k.state === 'fall') {
        k.v.y -= 9.8 * dt;
        k.p.addScaledVector(k.v, dt);
        k.rot.x += dt * 8;
        const dx = k.p.x - bowl.x, dz = k.p.z - bowl.z;
        const r = Math.hypot(dx, dz);
        if (r < 0.145 && k.p.y < surface()) {
          if (state.bowl.food < 1) {
            if (state.bowl.kind !== 'kibble' && state.bowl.food < 0.05) state.bowl.kind = 'kibble';
            state.bowl.food = Math.min(1, state.bowl.food + 0.011);
            this.parts.splice(i, 1);
            if (tickSnd++ < 1) audio.kibble();
            continue;
          }
          // overflow: bounce off the heap and spill
          k.p.y = surface();
          k.v.set(dx / (r || 1) * 0.6, 0.6, dz / (r || 1) * 0.6);
          if (!this.fullWarned) { ui.toast('Whoa — the bowl is full!', 'bad', 1.6); this.fullWarned = true; }
        } else if (r < 0.19 && r > 0.13 && k.p.y < 0.1 && k.v.y < 0) {
          k.v.set(dx / r * 0.5, Math.abs(k.v.y) * 0.3, dz / r * 0.5); // bounce off rim
        } else if (k.p.y < 0.01) {
          k.p.y = 0.01;
          if (Math.abs(k.v.y) > 0.6) { k.v.y *= -0.3; k.v.x *= 0.5; k.v.z *= 0.5; if (tickSnd++ < 1) audio.kibble(); }
          else { k.state = 'floor'; k.age = 0; }
        }
      } else if (k.age > 5) {
        this.parts.splice(i, 1); // spilled bits get tidied away
      }
    }
    if (state.bowl.food < 0.9) this.fullWarned = false;
    this.kib.count = this.parts.length;
    for (let i = 0; i < this.parts.length; i++) {
      const k = this.parts[i];
      const s = k.state === 'floor' ? clamp(1 - (k.age - 4)) : 1;
      _q.setFromEuler(new THREE.Euler(k.rot.x, k.rot.y, k.rot.z));
      _m.compose(k.p, _q, _s.set(s, s * 0.7, s));
      this.kib.setMatrixAt(i, _m);
    }
    this.kib.instanceMatrix.needsUpdate = true;

    // wet food dollops
    for (let i = this.blobs.length - 1; i >= 0; i--) {
      const b = this.blobs[i];
      b.vel.y -= 9.8 * dt;
      b.mesh.position.addScaledVector(b.vel, dt);
      if (b.mesh.position.y < surface() + 0.01) {
        G.scene.remove(b.mesh);
        this.blobs.splice(i, 1);
        state.bowl.kind = 'wet';
        state.bowl.food = Math.min(1, state.bowl.food + 0.34);
        audio.plop();
        G.fx.burst('dot', V(bowl.x, surface() + 0.02, bowl.z), 6, { speed: 0.3, up: 0.5, size: 0.015, colors: [0xa8584e], life: 0.4 });
      }
    }

    // tossed treats
    for (const tr of this.treats) {
      if (tr.landed) continue;
      tr.vel.y -= 9.8 * dt;
      tr.mesh.position.addScaledVector(tr.vel, dt);
      tr.mesh.rotation.y += dt * 10;
      if (tr.mesh.position.y < 0.025) { tr.mesh.position.y = 0.025; tr.landed = true; audio.kibble(); }
    }
  }
}
