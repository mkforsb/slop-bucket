// Play with the cat: feather wand (stalk → butt wiggle → pounce!), laser pointer (endless chase,
// no catch — cats find that frustrating) and a jingly yarn ball to bat around.

import * as THREE from 'three';
import { SPOTS } from '../world.js';
import { state, add } from '../state.js';
import { audio } from '../audio.js';
import { ui } from '../ui.js';
import { rand, clamp, damp, lerp, wrapAngle } from '../util.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const B = { minX: -3.2, maxX: 3.6, minZ: -2.5, maxZ: 3.2 };
const BALL_R = 0.06;

export class PlayScene {
  constructor(G) {
    this.G = G;
    this.toy = V();
    this.toyPrev = V();
    this.toyVel = V();
    this.target = V();
    this.featherVel = V();
    this.ball = { pos: V(0.8, BALL_R, 1.2), vel: V(), rolling: false };
  }

  enter() {
    const G = this.G, cat = G.cat;
    const c = SPOTS.play;
    G.cam.set(V(c.x, 1.85, c.z + 2.75), V(c.x, 0.05, c.z - 0.15), 42);
    G.setShadowFocus(V(c.x, 0, c.z), 3.2);
    const p = cat.root.position;
    if (p.x > 20 || p.x < B.minX || p.x > B.maxX || p.z < B.minZ || p.z > B.maxZ) cat.place(c.x, c.z - 0.3, 0);
    cat.root.position.y = 0;
    this.mode = 'watch'; this.modeT = 0; this.lastActive = -10; this.funGained = 0;
    this.caught = 0; this.laserMisses = 0; this.tipShown = false; this.tiredT = 0; this.busy = false;
    this.target.set(c.x + 0.6, 0.12, c.z + 0.6);
    this.toy.copy(this.target);
    this.toyPrev.copy(this.toy);
    this.feather = this.toy.clone();
    this.featherVel.set(0, 0, 0);
    this.down = false;
    ui.setTools([
      { id: 'wand', emoji: '🪶', label: 'Feather wand', onClick: () => this.setTool('wand') },
      { id: 'laser', emoji: '🔴', label: 'Laser', onClick: () => this.setTool('laser') },
      { id: 'ball', emoji: '🧶', label: 'Yarn ball', onClick: () => this.setTool('ball') },
    ], 'wand');
    this.setTool('wand');
  }

  exit() {
    const w = this.G.world;
    w.feather.visible = w.wandStick.visible = w.wandString.visible = w.laser.visible = w.yarn.visible = false;
    if (this.funGained > 5) state.stats.plays++;
  }

  setTool(t) {
    const G = this.G, w = G.world;
    this.tool = t;
    w.feather.visible = w.wandStick.visible = w.wandString.visible = t === 'wand';
    w.laser.visible = t === 'laser';
    w.yarn.visible = t === 'ball';
    G.canvas.style.cursor = t === 'ball' ? 'crosshair' : 'none';
    const hints = {
      wand: 'Wiggle the feather to lure the cat… let it rest, and watch for the pounce! Press and hold to lift it high.',
      laser: 'Zip the red dot around the floor. (They can never catch it…)',
      ball: 'Tap anywhere on the floor to throw the yarn ball',
    };
    ui.hint(hints[t]);
    if (t === 'ball') { this.ball.pos.set(clamp(this.ball.pos.x, B.minX, B.maxX), BALL_R, clamp(this.ball.pos.z, B.minZ, B.maxZ)); }
    this.setMode('watch');
  }

  // ------------------------------------------------------------------ input
  pointerMove() {
    const G = this.G;
    const h = this.tool === 'wand' ? (this.down ? 0.5 : 0.12) : 0;
    const p = G.rayPlane(h);
    if (!p) return;
    this.target.set(clamp(p.x, B.minX, B.maxX), h, clamp(p.z, B.minZ, B.maxZ));
  }
  pointerDown(e) {
    this.down = true;
    this.pointerMove(e);
    if (this.tool === 'ball') this.throwBall();
  }
  pointerUp(e) { this.down = false; this.pointerMove(e); }

  throwBall() {
    const G = this.G;
    const from = G.camera.position.clone().add(V(0.3, -0.6, -0.4));
    const to = this.target.clone().setY(BALL_R);
    const T = 0.75;
    const v = to.clone().sub(from).divideScalar(T);
    v.y = (to.y - from.y + 4.9 * T * T) / T;
    this.ball.pos.copy(from);
    this.ball.vel.copy(v);
    audio.swish();
    this.lastActive = G.clock.time;
    this.setMode('watch');
  }

  // ------------------------------------------------------------------ toys
  updateToys(dt) {
    const G = this.G, w = G.world, t = G.clock.time;
    if (this.tool === 'wand') {
      if (this.caught > 0) {
        this.feather.copy(G.cat.headWorldPos()).add(V(0, -0.08, 0)).addScaledVector(V(Math.sin(G.cat.heading), 0, Math.cos(G.cat.heading)), 0.12);
      } else {
        // dangling feather: spring toward the pointer with a little lag
        const acc = this.target.clone().sub(this.feather).multiplyScalar(60);
        this.featherVel.addScaledVector(acc, dt).multiplyScalar(Math.exp(-8 * dt));
        this.feather.addScaledVector(this.featherVel, dt);
        this.feather.y = Math.max(0.04, this.feather.y);
      }
      w.feather.position.copy(this.feather);
      w.feather.rotation.set(Math.sin(t * 7) * 0.3 + this.featherVel.z * 0.4, t * 1.5, Math.sin(t * 5) * 0.3 - this.featherVel.x * 0.4);
      // wand stick + string from above/behind the feather
      const tip = this.target.clone().add(V(0.1, 0.42, 0.25));
      const base = tip.clone().add(V(0.3, 0.45, 0.55));
      w.wandStick.position.copy(tip).lerp(base, 0.5);
      w.wandStick.lookAt(base);
      w.wandStick.rotateX(Math.PI / 2);
      w.wandStick.scale.y = tip.distanceTo(base) / 1.2;
      const pts = [];
      for (let i = 0; i <= 10; i++) {
        const k = i / 10;
        const p = tip.clone().lerp(this.feather, k);
        p.y -= Math.sin(k * Math.PI) * 0.06;
        pts.push(p);
      }
      const attr = w.wandString.geometry.attributes.position;
      pts.forEach((p, i) => attr.setXYZ(i, p.x, p.y, p.z));
      attr.needsUpdate = true;
      this.toy.copy(this.feather);
    } else if (this.tool === 'laser') {
      const jit = V(rand(-0.004, 0.004), 0, rand(-0.004, 0.004));
      this.toy.copy(this.target).setY(0).add(jit);
      w.laser.position.copy(this.toy);
    } else if (this.tool === 'ball') {
      const b = this.ball;
      b.vel.y -= 9.8 * dt;
      b.pos.addScaledVector(b.vel, dt);
      if (b.pos.y < BALL_R) {
        b.pos.y = BALL_R;
        if (b.vel.y < -0.8) { b.vel.y *= -0.45; audio.jingle(); } else b.vel.y = 0;
        b.vel.x *= Math.exp(-1.1 * dt); b.vel.z *= Math.exp(-1.1 * dt);
      }
      for (const [axis, lo, hi] of [['x', B.minX, B.maxX], ['z', B.minZ, B.maxZ]]) {
        if (b.pos[axis] < lo) { b.pos[axis] = lo; b.vel[axis] = Math.abs(b.vel[axis]) * 0.6; audio.thud(); }
        if (b.pos[axis] > hi && b.pos.y < 0.5) { b.pos[axis] = hi; b.vel[axis] = -Math.abs(b.vel[axis]) * 0.6; audio.thud(); }
      }
      const hs = Math.hypot(b.vel.x, b.vel.z);
      if (hs > 0.01) {
        const axis = V(b.vel.z, 0, -b.vel.x).normalize();
        w.yarn.rotateOnWorldAxis(axis, (hs * dt) / BALL_R);
        w.yarn.children[1].visible = false;
      }
      w.yarn.position.copy(b.pos);
      this.toy.copy(b.pos);
    }
    this.toyVel.copy(this.toy).sub(this.toyPrev).divideScalar(Math.max(dt, 1e-3));
    this.toyPrev.copy(this.toy);
    this.toySpeed = damp(this.toySpeed || 0, this.toyVel.length(), 6, dt);
    if (this.toySpeed > 0.08) this.lastActive = t;
  }

  // ------------------------------------------------------------------ cat brain
  setMode(m) { this.mode = m; this.modeT = 0; }

  update(dt) {
    const G = this.G, cat = G.cat, t = G.clock.time;
    this.updateToys(dt);
    this.modeT += dt;
    if (this.caught > 0) this.caught -= dt;

    const cp = cat.root.position;
    const toFlat = V(this.toy.x - cp.x, 0, this.toy.z - cp.z);
    const dist = toFlat.length();
    const active = t - this.lastActive < 2.5;
    const tired = state.needs.fun >= 99.5;

    if (this.busy) return; // mid-pounce
    cat.lookAt(this.toy);
    cat.wiggle = this.mode === 'wiggle' ? 1 : damp(cat.wiggle, 0, 8, dt);

    if (tired && this.mode !== 'tired') {
      this.setMode('tired');
      cat.stop();
      cat.setPose('loaf');
      cat.setMood({ eyes: 'sleepy' });
      cat.setTail('wrap');
      ui.toast(`${state.name} is all played out! 😴`, 'good', 2.5);
      audio.setPurr(0.4);
      return;
    }

    const gainFun = (amt) => { add('fun', amt); this.funGained += amt; };

    switch (this.mode) {
      case 'tired':
        cat.lookAt(null);
        if (state.needs.fun < 92) { audio.setPurr(0); cat.resetMood(); this.setMode('watch'); }
        break;
      case 'watch': {
        cat.setMood({ pupil: active ? 1.3 : 1, eyes: 'open' });
        cat.setPose(active ? 'crouch' : 'sit');
        cat.setTail(active ? 'flick' : 'neutral');
        cat.faceToward(this.toy.x, this.toy.z);
        if (!active) { if (this.modeT > 6) this.setMode('bored'); break; }
        if (this.modeT < 0.35) break;
        if (this.tool === 'wand' && this.feather.y > 0.3 && dist < 0.5) this.setMode('reach');
        else if (dist > 0.85) this.setMode('approach');
        else if (dist < 0.3) this.swat(toFlat);
        else if (this.toySpeed < 0.9) this.setMode('wiggle');
        break;
      }
      case 'bored':
        cat.setPose('loaf');
        cat.setMood({ eyes: 'sleepy' });
        cat.lookAt(null);
        if (active) { cat.setMood({ eyes: 'open' }); this.setMode('watch'); }
        break;
      case 'approach': {
        const run = this.tool !== 'wand' || dist > 2.2;
        cat.setPose(run ? 'stand' : 'crouch');
        cat.setMood({ pupil: 1.35 });
        cat.setTail(run ? 'happy' : 'flick');
        const stop = this.toy.clone().addScaledVector(toFlat.clone().normalize(), -0.5);
        if (!cat.move || this.modeT % 0.25 < dt) cat.walkTo(stop.x, stop.z, run ? 1.35 : 0.32);
        gainFun(dt * 1.2);
        if (dist < 0.8) { cat.stop(); this.setMode(this.tool === 'ball' && dist < 0.3 ? 'watch' : 'wiggle'); }
        if (!active && this.modeT > 3) { cat.stop(); this.setMode('watch'); }
        break;
      }
      case 'wiggle':
        cat.setPose('crouch');
        cat.faceToward(this.toy.x, this.toy.z);
        cat.setMood({ pupil: 1.45, ears: 0.15 });
        if (dist > 1.15) { this.setMode('approach'); break; }
        if (this.modeT > (this.wiggleFor ||= rand(0.5, 1.1))) { this.wiggleFor = 0; this.pounce(toFlat, dist); }
        break;
      case 'reach':
        cat.setPose('reach');
        cat.setMood({ pupil: 1.4 });
        if (this.feather.y < 0.3 || dist > 0.7) { this.setMode('watch'); break; }
        if (this.modeT > 0.45) {
          this.modeT = 0;
          cat.swipe(Math.random() < 0.5 ? -1 : 1);
          gainFun(1.5);
          if (Math.random() < 0.22) this.gotcha();
        }
        break;
    }
  }

  swat(toFlat) {
    const G = this.G, cat = G.cat;
    const side = (wrapAngle(Math.atan2(toFlat.x, toFlat.z) - cat.heading) > 0) ? 1 : -1;
    cat.swipe(side);
    add('fun', 1.5); this.funGained += 1.5;
    if (this.tool === 'ball') {
      const dir = toFlat.clone().normalize();
      dir.applyAxisAngle(V(0, 1, 0), rand(-0.7, 0.7));
      this.ball.vel.add(dir.multiplyScalar(rand(1.2, 2.2))).add(V(0, 0.8, 0));
      audio.jingle();
      G.fx.burst('star', this.toy.clone(), 3, { speed: 0.4, up: 0.6, size: 0.04, gravity: -1, life: 0.6 });
    }
    this.setMode('watch');
  }

  pounce(toFlat, dist) {
    const G = this.G, cat = G.cat;
    const dir = toFlat.clone().normalize();
    // lead the target a little
    const aim = this.toy.clone().addScaledVector(this.toyVel, 0.25).setY(0);
    const reach = Math.min(cat.root.position.distanceTo(aim), 1.1);
    const aimDir = aim.clone().sub(cat.root.position).setY(0).normalize();
    if (!isFinite(aimDir.x)) aimDir.copy(dir);
    const land = cat.root.position.clone().addScaledVector(aimDir, Math.max(0.1, reach - 0.14));
    land.x = clamp(land.x, B.minX, B.maxX); land.z = clamp(land.z, B.minZ, B.maxZ);
    this.busy = true;
    cat.wiggle = 0;
    cat.setPose('stand');
    cat.setMood({ pupil: 1.5, ears: 0 });
    G.task.guard(cat.jumpTo(land.x, land.z, 0.16 + reach * 0.12, 0.35 + reach * 0.2)).then(() => this.land()).catch(() => {});
    add('fun', 3); this.funGained += 3;
    void dist;
  }

  land() {
    const G = this.G, cat = G.cat;
    this.busy = false;
    cat.setPose('crouch');
    const mouth = cat.root.position.clone().addScaledVector(V(Math.sin(cat.heading), 0, Math.cos(cat.heading)), 0.2);
    const d = Math.hypot(this.toy.x - mouth.x, this.toy.z - mouth.z);
    if (this.tool === 'laser') {
      this.laserMisses++;
      G.fx.emote(cat, 'question');
      cat.tgt.headPitch = 0.6; // peeks under its paws
      if (this.laserMisses >= 4 && !this.tipShown) {
        this.tipShown = true;
        ui.toast('Tip: end laser play with a toy they can actually catch! 🪶', 'info', 3.5);
      }
      this.setMode('watch');
      return;
    }
    if (this.tool === 'wand' && d < 0.2 && this.feather.y < 0.3) { this.gotcha(); return; }
    if (this.tool === 'ball' && d < 0.3) { this.swat(V(this.toy.x - cat.root.position.x, 0, this.toy.z - cat.root.position.z)); return; }
    this.setMode('watch');
  }

  gotcha() {
    const G = this.G, cat = G.cat;
    this.caught = 1.3;
    add('fun', 10); this.funGained += 10;
    if (this.laserMisses >= 3) { add('fun', 5); ui.toast('A satisfying catch after all that laser chasing! 😸', 'good', 2.5); this.laserMisses = 0; }
    else ui.toast('Gotcha! 🪶', 'good', 1.5);
    audio.sparkle();
    cat.meow({ style: 'chirp' });
    cat.setPose('crouch');
    cat.setMood({ eyes: 'happy' });
    G.fx.burst('sparkle', this.feather.clone(), 8, { speed: 0.6, up: 0.9, size: 0.05, gravity: -1.2, life: 0.8 });
    this.busy = true;
    G.task.sleep(1.3).then(() => { this.busy = false; cat.resetMood(); this.setMode('watch'); }).catch(() => {});
  }
}
