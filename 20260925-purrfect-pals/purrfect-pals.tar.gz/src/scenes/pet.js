// Pet the cat: stroke with a 3D hand (or brush). Cats have opinions about *where* you pet them:
// cheeks/chin/head are heavenly, the back is nice, tails and faces are not, and the belly... is a trap.

import * as THREE from 'three';
import { SPOTS } from '../world.js';
import { state, add } from '../state.js';
import { audio } from '../audio.js';
import { ui } from '../ui.js';
import { rand, clamp, damp, lerp } from '../util.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const std = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.7, ...o });

const LIKES = {
  hand: { head: 1.0, cheek: 1.35, chin: 1.3, ear: 0.5, back: 0.85, rump: 0.75, body: 0.7, tail: -0.9, paw: -0.35, face: -1.0, belly: 0.4 },
  brush: { head: 0.8, cheek: 1.2, chin: 0.7, ear: -0.2, back: 1.3, rump: 1.1, body: 1.0, tail: -0.4, paw: -0.4, face: -1.0, belly: 0.2 },
};

const REACTIONS = {
  cheek: 'Cheek scritches are the best! 😽',
  chin: 'Chin scratches! Pure bliss.',
  head: 'Head pats!',
  tail: 'Hey! Not the tail 😾',
  face: 'Not in the face! 🙀',
  paw: 'Toe beans! …but they\'d rather you didn\'t 🐾',
  ear: 'Ear rubs — gently does it',
  back: 'Long strokes along the back ✨',
};

export class PetScene {
  constructor(G) {
    this.G = G;
    this.hand = this.makeHand();
    this.brush = this.makeBrush();
    this.hand.visible = this.brush.visible = false;
    G.scene.add(this.hand, this.brush);
  }

  makeHand() {
    const g = new THREE.Group();
    const skin = std('#ffd7c2', { roughness: 0.6 });
    const sleeve = std('#ff9fb8', { roughness: 0.9 });
    const add = (geo, mat, pos, rot, scale) => { const m = new THREE.Mesh(geo, mat); m.position.copy(pos); if (rot) m.rotation.set(...rot); if (scale) m.scale.set(...scale); m.castShadow = true; g.add(m); return m; };
    add(new THREE.SphereGeometry(0.05, 20, 14), skin, V(0, 0, 0), null, [1, 0.42, 1.1]);
    this.fingers = [];
    for (let i = 0; i < 4; i++) {
      const pivot = new THREE.Group();
      pivot.position.set((i - 1.5) * 0.022, -0.002, 0.04 + (i === 1 || i === 2 ? 0.006 : 0));
      g.add(pivot);
      const f = new THREE.Mesh(new THREE.CapsuleGeometry(0.0115, 0.036 + (i === 1 || i === 2 ? 0.006 : 0), 4, 8), skin);
      f.rotation.x = Math.PI / 2;
      f.position.z = 0.024;
      f.castShadow = true;
      pivot.add(f);
      this.fingers.push(pivot);
    }
    add(new THREE.CapsuleGeometry(0.012, 0.03, 4, 8), skin, V(0.052, -0.004, 0.012), [Math.PI / 2, 0, -0.9]);
    // forearm rises up and back so it doesn't block the view
    const arm = new THREE.Group();
    arm.position.set(0, 0.01, -0.035);
    arm.rotation.x = -0.95;
    g.add(arm);
    const armPart = (geo, mat, z) => { const m = new THREE.Mesh(geo, mat); m.rotation.x = Math.PI / 2; m.position.z = z; m.castShadow = true; arm.add(m); };
    armPart(new THREE.CylinderGeometry(0.031, 0.034, 0.1, 14), skin, -0.05);
    armPart(new THREE.TorusGeometry(0.043, 0.009, 8, 18), std('#ffffff'), -0.1);
    armPart(new THREE.CylinderGeometry(0.043, 0.047, 0.22, 16), sleeve, -0.21);
    arm.children[1].rotation.x = 0;
    g.scale.setScalar(0.85);
    return g;
  }

  makeBrush() {
    const g = new THREE.Group();
    const wood = std('#d4a373', { roughness: 0.5 });
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.025, 0.07), wood);
    head.position.y = 0.02;
    g.add(head);
    const handle = new THREE.Mesh(new THREE.CapsuleGeometry(0.014, 0.16, 4, 8), wood);
    handle.rotation.x = Math.PI / 2 - 0.25;
    handle.position.set(0, 0.045, -0.12);
    g.add(handle);
    const bristles = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.0022, 0.0022, 0.022, 4), std('#6b4f3a'), 48);
    const m = new THREE.Matrix4();
    let k = 0;
    for (let i = 0; i < 8; i++) for (let j = 0; j < 6; j++) { m.makeTranslation((i - 3.5) * 0.011, 0.0, (j - 2.5) * 0.011); bristles.setMatrixAt(k++, m); }
    g.add(bristles);
    g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    return g;
  }

  enter() {
    const G = this.G, cat = G.cat;
    const bed = SPOTS.bed;
    this.camPos = V(-2.45, 0.74, 1.48);
    G.cam.set(this.camPos, V(-3.33, 0.17, 0.52), 38);
    G.setShadowFocus(V(-3.3, 0, 0.6), 1.6);
    cat.place(bed.x, bed.z, 0);
    cat.root.position.y = G.world.bedTop;
    this.faceCam = Math.atan2(this.camPos.x - bed.x, this.camPos.z - bed.z);
    cat.heading = this.faceCam;
    cat.setPose('loaf');
    cat.setTail('wrap');
    this.tool = 'hand';
    this.content = 0.1; this.annoy = 0; this.bellyMode = 0; this.bellyStroke = 0;
    this.trap = null; this.lastRoll = G.clock.time; this.sulk = 0;
    this.stroke = 0; this.region = null; this.hover = null; this.lastPt = null; this.down = false;
    this.spd = 0; this.idleT = 0; this.reactT = {}; this.gained = 0; this.kneadToast = false;
    this.downAt = null;
    ui.setTools([
      { id: 'hand', emoji: '✋', label: 'Hand', onClick: () => { this.tool = 'hand'; } },
      { id: 'brush', emoji: '🪮', label: 'Brush', onClick: () => { this.tool = 'brush'; } },
    ], 'hand');
    ui.hint('Press and drag over your cat to stroke. Try cheeks, chin, head and back!');
    G.canvas.style.cursor = 'none';
  }

  exit() {
    this.hand.visible = this.brush.visible = false;
    if (this.gained > 5) state.stats.pets++;
    audio.setPurr(0);
  }

  // ------------------------------------------------------------------ input
  pointerMove() {
    const G = this.G;
    this.hover = G.pickCat();
    if (this.down && this.hover && this.lastPt) {
      const d = this.hover.point.distanceTo(this.lastPt);
      if (d < 0.12) { this.stroke += d; this.region = this.hover.region; }
    }
    this.lastPt = this.hover ? this.hover.point.clone() : null;
    if (!this.hover) {
      const p = G.rayPlane(G.world.bedTop + 0.28);
      if (p) this.freePt = p;
    }
  }

  pointerDown(e) {
    this.down = true;
    this.pointerMove();
    this.downAt = { x: e.clientX, y: e.clientY, t: this.G.clock.time, region: this.hover?.region };
  }

  pointerUp(e) {
    this.down = false;
    const d = this.downAt;
    if (d && d.region && Math.hypot(e.clientX - d.x, e.clientY - d.y) < 6 && this.G.clock.time - d.t < 0.35) this.tap(d.region);
    this.downAt = null;
  }

  tap(region) {
    const G = this.G, cat = G.cat;
    if (this.trap) return;
    if (region === 'face' || region === 'chin') {
      ui.toast('Boop! 👉👃', 'good', 1.4);
      audio.boing();
      cat.blink = 1;
      cat.setMood({ eyes: 'squint' });
      G.fx.burst('sparkle', cat.headWorldPos().add(V(0, 0, 0.1)), 5, { speed: 0.3, up: 0.4, size: 0.03, gravity: 0, life: 0.6 });
      setTimeout(() => cat.setMood({ eyes: 'open' }), 500);
      add('love', 1);
    } else if (Math.random() < 0.5) {
      cat.meow({ length: 0.6 });
    }
  }

  // ------------------------------------------------------------------ per-frame
  update(dt) {
    const G = this.G, cat = G.cat;
    const t = G.clock.time;
    this.updateTool(dt, t);

    const d = this.stroke; this.stroke = 0;
    this.spd = damp(this.spd, d / Math.max(dt, 1e-3), 8, dt);
    if (this.trap) this.updateTrap(dt);
    else if (this.sulk > 0) {
      this.sulk -= dt;
      if (this.sulk <= 0) { cat.setPose(this.bellyMode ? 'belly' : 'loaf'); cat.heading = this.faceCam; cat.resetMood(); cat.setTail('wrap'); }
    } else if (d > 0 && this.region) this.applyStroke(this.region, d, dt);

    if (d === 0) this.idleT += dt; else this.idleT = 0;
    this.content = clamp(this.content - dt * (this.idleT > 1.5 ? 0.05 : 0.015));
    this.annoy = clamp(this.annoy - dt * 0.15, 0, 2);

    // body language
    const c = this.content;
    if (!this.trap && this.sulk <= 0) {
      if (this.annoy > 0.45) { cat.setMood({ eyes: 'squint', ears: clamp(this.annoy), pupil: 1.2 }); cat.setTail('flick'); }
      else {
        cat.setMood({ eyes: c > 0.72 ? 'happy' : c > 0.4 ? 'squint' : 'open', ears: 0, pupil: 1, blush: clamp((c - 0.3) * 1.6) });
        if (!this.bellyMode) cat.setTail(c > 0.5 ? 'happy' : 'wrap');
      }
      // gaze follows the hand unless blissed out
      const tip = this.toolObj().position;
      cat.lookAt(c < 0.6 || this.annoy > 0.3 ? tip : null);
      // making biscuits
      cat.knead = !this.bellyMode && c > 0.8 ? damp(cat.knead, 1, 3, dt) : damp(cat.knead, 0, 5, dt);
      if (cat.knead > 0.5 && !this.kneadToast) { ui.toast(`${state.name} is making biscuits! 🍞`, 'good'); this.kneadToast = true; }
    }
    const purr = clamp((c - 0.25) * 1.5) * (this.annoy > 0.5 ? 0 : 1);
    audio.setPurr(purr);
    cat.purr = purr;
    if (purr > 0.3 && Math.random() < dt * 1.5 * purr) G.fx.emote(cat, 'note', 1, { size: 0.05 });

    // chin/cheek head tilts
    if (this.region === 'chin' && d > 0) { cat.tgt.headPitch = -0.35; }
    else if (this.region === 'cheek' && d > 0) { cat.tgt.headRoll = this.hover && this.hover.point.x > cat.root.position.x ? 0.3 : -0.3; }
    else if (!this.bellyMode && !this.trap && this.idleT > 0.4) { cat.tgt.headPitch = 0.12; cat.tgt.headRoll = 0; }

    // Roll over for belly rubs when blissful
    if (!this.bellyMode && !this.trap && this.sulk <= 0 && c > 0.85 && t - this.lastRoll > 10) this.rollOver();
    if (this.bellyMode && !this.trap && t - this.bellyStart > 9 && this.idleT > 2) this.rollBack();

    // gentle nudge if ignored
    if (this.idleT > 7 && !this.trap && !this.bellyMode) {
      this.idleT = 2;
      cat.meow({ length: 0.7 });
      cat.lookAt(G.camera.position);
      ui.toast(`${state.name} nudges your hand for more pets`, 'info', 1.8);
    }
  }

  toolObj() { return this.tool === 'brush' ? this.brush : this.hand; }

  updateTool(dt, t) {
    const G = this.G;
    const obj = this.toolObj();
    (this.tool === 'brush' ? this.hand : this.brush).visible = false;
    obj.visible = true;
    let pos, normal;
    if (this.trap) {
      // grabbed! hand gets pulled against the belly and wiggles
      pos = this.trap.pt.clone().add(V(Math.sin(t * 30) * 0.01, Math.sin(t * 23) * 0.008, 0));
      normal = this.trap.n;
    } else if (this.hover) {
      pos = this.hover.point.clone();
      // lean the hand toward horizontal so it strokes rather than slaps
      normal = this.hover.normal.clone().add(V(0, 0.9, 0)).normalize();
    } else {
      pos = (this.freePt || V(-3.3, 0.4, 0.8)).clone();
      normal = V(0, 1, 0);
    }
    const lift = this.hover ? (this.down ? 0.012 : 0.035) : 0;
    const target = pos.addScaledVector(normal, lift + (this.tool === 'brush' ? 0.01 : 0.02));
    if (!obj.userData.init) { obj.position.copy(target); obj.userData.init = true; }
    obj.position.lerp(target, 1 - Math.exp(-25 * dt));
    // orient: local -y into the surface, fingers pointing away from the camera
    const y = normal.clone().normalize();
    const fwd = obj.position.clone().sub(G.camera.position);
    const z = fwd.sub(y.clone().multiplyScalar(fwd.dot(y))).normalize();
    const x = new THREE.Vector3().crossVectors(y, z);
    const m = new THREE.Matrix4().makeBasis(x, y, z);
    const q = new THREE.Quaternion().setFromRotationMatrix(m);
    obj.quaternion.slerp(q, 1 - Math.exp(-15 * dt));
    // finger scritch animation
    const moving = this.spd > 0.05 && this.down;
    this.fingers.forEach((f, i) => { f.rotation.x = moving ? 0.25 + Math.sin(t * 16 + i) * 0.25 : this.down ? 0.2 : 0.05; });
  }

  applyStroke(region, d, dt) {
    const G = this.G, cat = G.cat;
    const t = G.clock.time;
    if (region === 'belly' && this.bellyMode) {
      this.bellyStroke += d;
      if (this.bellyStroke > this.trapAt) { this.springTrap(); return; }
    }
    const rough = this.spd > 2.4;
    let mult = LIKES[this.tool][region] ?? 0.5;
    if (rough) {
      mult = -0.8;
      this.react('rough', 'Gently! Slow strokes please 🐾', 'bad');
    }
    if (mult > 0) {
      this.content = clamp(this.content + d * 1.3 * mult);
      const love = d * 9 * mult;
      add('love', love);
      this.gained += love;
      if (Math.random() < d * 12 * mult) G.fx.emote(cat, 'heart', 1, { size: 0.06 });
      if (region !== 'body') this.react(region, REACTIONS[region], 'good');
      if (this.tool === 'brush') {
        this.brushT = (this.brushT || 0) - dt;
        if (this.brushT < 0) { this.brushT = 0.15; audio.brush(); }
        if (Math.random() < d * 30) G.fx.spawn('fur', this.brush.position.clone().add(V(0, 0.03, 0)), { color: new THREE.Color(state.look.main).lerp(new THREE.Color('#ffffff'), 0.3), size: 0.05, vel: V(rand(-0.1, 0.1), 0.15, rand(-0.1, 0.1)), gravity: -0.2, life: 1.6, pop: false, wobble: 2 });
      }
    } else {
      this.annoy += -mult * d * 3.2 + (rough ? d * 1.5 : 0);
      this.content = clamp(this.content - d * 1.5);
      if (!rough) this.react(region, REACTIONS[region] || 'Hmm, not there', 'bad');
      if (region === 'tail') cat.setTail('flick');
      if (region === 'face') cat.blink = 1;
      if (this.annoy > 1) this.swat();
    }
    void t;
  }

  react(key, text, kind) {
    const t = this.G.clock.time;
    if (!text || (this.reactT[key] && t - this.reactT[key] < 6)) return;
    this.reactT[key] = t;
    ui.toast(text, kind, 1.8);
  }

  swat() {
    const G = this.G, cat = G.cat;
    const side = this.hand.position.x > cat.root.position.x ? -1 : 1;
    cat.swipe(side);
    cat.setMood({ eyes: 'squint', ears: 1, pupil: 0.8 });
    cat.meow({ style: 'grumpy', length: 0.5 });
    if (this.annoy > 1.3) audio.hiss();
    G.fx.emote(cat, 'anger', 1, { size: 0.07 });
    ui.toast(`Swat! ${state.name} needs a little space 😾`, 'bad', 2.2);
    add('love', -4);
    this.content = 0;
    this.annoy = 0.6;
    this.sulk = 2.5;
    cat.heading = this.faceCam + (Math.random() < 0.5 ? 0.8 : -0.8); // turns away
    cat.setPose('loaf');
    cat.setTail('flick');
    if (this.bellyMode) this.bellyMode = 0;
  }

  rollOver() {
    const G = this.G, cat = G.cat;
    this.bellyMode = 1;
    this.bellyStart = G.clock.time;
    this.bellyStroke = 0;
    this.trapAt = rand(0.35, 0.9);
    this.lastRoll = G.clock.time;
    cat.heading = this.faceCam - Math.PI / 2;
    cat.setPose('belly');
    cat.setTail('belly');
    cat.knead = 0;
    audio.boing();
    ui.toast(`${state.name} rolls over and shows their belly… 🤔`, 'info', 2.6);
  }

  rollBack() {
    const cat = this.G.cat;
    this.bellyMode = 0;
    this.lastRoll = this.G.clock.time;
    cat.heading = this.faceCam;
    cat.setPose('loaf');
    cat.setTail('wrap');
  }

  springTrap() {
    const G = this.G, cat = G.cat;
    this.trap = { t: 0, pt: this.hover ? this.hover.point.clone() : this.hand.position.clone(), n: this.hover ? this.hover.normal.clone() : V(0, 1, 0) };
    cat.setMood({ eyes: 'open', pupil: 1.45, ears: 0.9 });
    cat.setTail('flick');
    cat.knead = 1;
    cat.face.mouth = 0.6;
    cat.meow({ style: 'chirp' });
    audio.swish();
    ui.toast('IT\'S A TRAP! 🙀 Bunny kicks!', 'bad', 2.4);
    G.fx.emote(cat, 'exclaim');
  }

  updateTrap(dt) {
    const G = this.G, cat = G.cat;
    const tr = this.trap;
    tr.t += dt;
    cat.face.mouth = 0.4 + Math.sin(tr.t * 20) * 0.2;
    if (Math.random() < dt * 8) audio.swish();
    if (tr.t > 1.8) {
      this.trap = null;
      cat.knead = 0;
      add('love', -2);
      this.content = 0.3;
      this.annoy = 0.2;
      this.rollBack();
      cat.resetMood();
      ui.toast('Lesson learned: belly = danger zone 😹', 'info', 2.4);
    }
  }
}
