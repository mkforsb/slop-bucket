// Home: an overview of the apartment. The cat lives its own little life here — wandering,
// napping, eating when food is out, visiting the litter box and asking for attention.

import * as THREE from 'three';
import { SPOTS } from '../world.js';
import { state, add, urgentNeed } from '../state.js';
import { audio } from '../audio.js';
import { ui } from '../ui.js';
import { rand, pick, clamp, damp, lerp } from '../util.js';
import { walk, eatFromBowl, drink, useLitter, nap, zoomies, randomOpenPoint, ensureOnFloor } from '../behaviors.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

export class HubScene {
  constructor(G) { this.G = G; this.greeted = 0; }

  enter() {
    const G = this.G;
    ensureOnFloor(G);
    const cp = G.cat.root.position;
    G.cam.setOrbit(V(lerp(0, cp.x, 0.6), 0.25, lerp(-0.5, cp.z, 0.6)), 0, 0.5, 5.8, 40);
    Object.assign(G.cam.orbit, { minYaw: -0.75, maxYaw: 0.75 });
    G.setShadowFocus(V(0, 0, -0.3), 5.5);
    ui.hint(`Tap ${state.name} to say hi · drag to look around · use the buttons below to care for them`);
    this.hintT = 6;
    this.drag = null;
    G.task.run((tk) => this.ai(tk));
  }

  exit() { this.G.napping = false; }

  update(dt) {
    if (this.hintT > 0) { this.hintT -= dt; if (this.hintT <= 0) ui.hint(''); }
    // camera drifts to keep the cat in view
    const o = this.G.cam.orbit, cp = this.G.cat.root.position;
    o.center.x = damp(o.center.x, lerp(0, cp.x, 0.6), 1.5, dt);
    o.center.z = damp(o.center.z, lerp(-0.5, cp.z, 0.6), 1.5, dt);
  }

  async ai(tk) {
    const G = this.G, cat = G.cat;
    await tk.sleep(0.6);
    // greet the player on arrival
    cat.lookAt(G.camera.position);
    cat.meow();
    G.fx.emote(cat, 'heart');
    await tk.sleep(1.2);
    cat.lookAt(null);
    while (true) {
      const n = state.needs;
      if (state.bowl.food > 0.05 && n.hunger < 80) { await eatFromBowl(G, tk); continue; }
      if (state.bladder >= 1) { await useLitter(G, tk); continue; }
      if (state.water > 0.1 && Math.random() < 0.06) { await drink(G, tk); continue; }
      const need = urgentNeed(30);
      if (need && Math.random() < 0.45) { await this.askForAttention(tk, need); continue; }
      const r = Math.random();
      if (r < 0.42) await this.wander(tk);
      else if (r < 0.56) await nap(G, tk, rand(8, 14));
      else if (r < 0.7) await this.sitAndWatch(tk);
      else if (r < 0.82) await this.windowWatch(tk);
      else if (n.fun > 45 && r < 0.9) await zoomies(G, tk, 3);
      else await this.wander(tk);
    }
  }

  async wander(tk) {
    const G = this.G, cat = G.cat;
    const p = randomOpenPoint();
    cat.lookAt(null);
    await walk(G, tk, p.x, p.z, rand(0.3, 0.5));
    cat.setPose(pick(['sit', 'stand', 'loaf', 'sit']));
    for (let i = 0; i < 3; i++) {
      if (Math.random() < 0.6) cat.lookAt(V(rand(-4, 4), rand(0, 1.5), rand(-4, 3)));
      else cat.lookAt(null);
      await tk.sleep(rand(1, 2.2));
    }
    cat.lookAt(null);
    cat.setPose('stand');
  }

  async sitAndWatch(tk) {
    const G = this.G, cat = G.cat;
    const p = V(rand(-1.2, 1.2), 0, rand(1, 2.2));
    await walk(G, tk, p.x, p.z, 0.4);
    cat.faceToward(G.camera.position.x, G.camera.position.z);
    cat.setPose('sit');
    cat.lookAt(G.camera.position);
    await tk.sleep(1.5);
    // slow blink: a cat's "I love you"
    cat.setMood({ eyes: 'closed' });
    await tk.sleep(0.8);
    cat.setMood({ eyes: 'open' });
    await tk.sleep(rand(2, 3));
    cat.lookAt(null);
    cat.setPose('stand');
  }

  async windowWatch(tk) {
    const G = this.G, cat = G.cat;
    await walk(G, tk, -0.6, -3.15, 0.45);
    cat.turnTo(Math.PI);
    cat.setPose('sit');
    cat.lookAt(V(-0.4, 1.8, -4));
    cat.setTail('neutral');
    for (let i = 0; i < 4; i++) {
      await tk.sleep(rand(1.2, 2));
      if (Math.random() < 0.4) { cat.setMood({ pupil: 1.3 }); cat.meow({ style: 'chirp' }); } // chattering at birds
    }
    cat.resetMood();
    cat.lookAt(null);
    cat.setPose('stand');
    cat.setTail('happy');
  }

  async askForAttention(tk, need) {
    const G = this.G, cat = G.cat;
    const p = V(clamp(G.camera.position.x * 0.3, -1.5, 1.5) + rand(-0.4, 0.4), 0, 2.0);
    await walk(G, tk, p.x, p.z, 0.5);
    cat.faceToward(G.camera.position.x, G.camera.position.z);
    cat.setPose('sit');
    cat.lookAt(G.camera.position);
    cat.setTail('low');
    for (let i = 0; i < 2; i++) {
      cat.meow({ style: need.id === 'hunger' ? 'yowl' : undefined });
      await tk.sleep(2.2);
    }
    const tips = { hunger: 'is hungry — head to Feed 🍽️', love: 'wants cuddles — try Pet ✋', fun: 'is bored — time to Play 🧶', clean: 'thinks the litter box is stinky — Litter 🧹' };
    ui.toast(`${state.name} ${tips[need.id]}`, 'info', 3);
    await tk.sleep(2);
    cat.setTail('neutral');
    cat.lookAt(null);
  }

  pointerDown(e) {
    const G = this.G;
    const hit = G.pickCat();
    if (hit) { this.poke(hit); return; }
    this.drag = { x: e.clientX, y: e.clientY };
  }
  pointerMove(e) {
    const G = this.G;
    if (this.drag) {
      const o = G.cam.orbit;
      o.yawT = clamp(o.yawT - (e.clientX - this.drag.x) * 0.005, o.minYaw, o.maxYaw);
      o.pitchT = clamp(o.pitchT + (e.clientY - this.drag.y) * 0.004, 0.2, 1.1);
      this.drag = { x: e.clientX, y: e.clientY };
      return;
    }
    G.canvas.style.cursor = G.pickCat() ? 'pointer' : 'grab';
  }
  pointerUp() { this.drag = null; }
  wheel(e) {
    const o = this.G.cam.orbit;
    o.distT = clamp(o.distT + Math.sign(e.deltaY) * 0.6, 2.5, 9);
  }

  poke(hit) {
    const G = this.G, cat = G.cat;
    if (G.napping) {
      cat.setMood({ eyes: 'sleepy', ears: 0.5 });
      G.fx.emote(cat, 'anger', 1, { size: 0.06 });
      cat.meow({ style: 'grumpy', length: 0.6 });
      ui.toast(`Shh… ${state.name} is napping 😴`, 'info');
      setTimeout(() => G.napping && cat.setMood({ eyes: 'closed', ears: 0 }), 1500);
      return;
    }
    cat.meow();
    cat.lookAt(G.camera.position);
    G.fx.emote(cat, 'heart', 2);
    cat.setMood({ eyes: 'happy', blush: 0.8 });
    setTimeout(() => cat.setMood({ eyes: 'open', blush: 0 }), 1000);
    const now = G.clock.time;
    if (now - this.greeted > 4) { add('love', 2); this.greeted = now; }
  }
}
