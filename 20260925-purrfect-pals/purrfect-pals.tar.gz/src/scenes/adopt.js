// Adopt a cat: the character creator. The cat sits on a turntable pedestal in a little photo
// studio while the side panel customises coat, face, body, voice and accessories.

import * as THREE from 'three';
import { PATTERNS, randomLook } from '../cat.js';
import { MEOW_STYLES } from '../audio.js';
import { audio } from '../audio.js';
import { state, save } from '../state.js';
import { ui } from '../ui.js';
import { SPOTS } from '../world.js';
import { pick, rand, damp } from '../util.js';

const NAMES = ['Mochi', 'Biscuit', 'Pudding', 'Miso', 'Tofu', 'Pumpkin', 'Luna', 'Oreo', 'Noodle', 'Pickles', 'Waffles', 'Nugget', 'Bean', 'Sushi', 'Mittens', 'Socks', 'Clover', 'Maple', 'Ginger', 'Pepper', 'Toast', 'Marshmallow', 'Dumpling', 'Boba', 'Cheddar', 'Olive', 'Kiki', 'Momo', 'Pixel', 'Muffin', 'Churro', 'Sprout', 'Beans', 'Taro', 'Sesame', 'Butter', 'Juniper', 'Pip', 'Ramen', 'Tiramisu'];

const COATS = ['#2a2a30', '#4a4a52', '#8a8f99', '#c9ccd3', '#f3ece0', '#f2dcb8', '#f7c888', '#e8913a', '#b0643a', '#6b4a36', '#c8a27a', '#a9a3b8'];
const ACCENTS = ['#111114', '#2c1d14', '#4a3328', '#8a3f14', '#c46a2c', '#5b3a22', '#3b2616', '#4c515c', '#6b6378', '#9a8f7a', '#d7c7b0', '#f3ece0'];
const EYES = ['#9ccc3c', '#f0b23a', '#5fb7ff', '#c8781e', '#7fc9a8', '#e2d04a', '#22d3ee', '#a78bfa'];
const NOSES = ['#f39aa8', '#e57f8f', '#d98a7a', '#6b4a4a', '#3a2a2a'];
const COLLARS = ['#e8457b', '#3d8bfd', '#35b56a', '#f2b632', '#8e5bd6', '#e5533d', '#ffffff'];

const ACCENT_LABEL = { solid: 'Accent colour', tabby: 'Stripe colour', tuxedo: 'Accent colour', calico: 'Patch colour', tortie: 'Mottle colour', siamese: 'Point colour', spotted: 'Spot colour', van: 'Accent colour' };

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export class AdoptScene {
  constructor(G) {
    this.G = G;
    this.tab = 'coat';
    this.spin = 0;
    this.spinT = 0;
    this.dragging = false;
  }

  enter(opts = {}) {
    const G = this.G;
    this.edit = !!opts.edit;
    this.preview = !!opts.preview;
    if (!state.adopted && !this.edit) this.newCat();
    const base = SPOTS.studio;
    G.cat.place(base.x, base.z, 0.35);
    G.cat.root.position.y = G.world.pedestalTop;
    this.baseHeading = 0.35;
    this.spin = this.spinT = 0;
    G.setShadowFocus(base, 2);
    this.frame();
    G.scene.fog.near = 30;
    if (!this.preview) this.showPanel();
    G.task.run((tk) => this.idle(tk));
  }

  // A new shelter kitty.
  newCat() {
    const G = this.G;
    Object.assign(state.look, randomLook());
    state.name = pick(NAMES);
    state.voice.style = pick(['classic', 'classic', 'kitten', 'chirp', 'trill']);
    state.voice.pitch = rand(0.85, 1.25);
    G.cat.setLook(state.look);
    G.cat.voice = { ...state.voice };
  }

  frame() {
    const base = SPOTS.studio;
    const panel = !document.getElementById('side').classList.contains('hidden');
    const narrow = window.innerWidth < 760;
    const off = this.preview ? -0.75 : panel && !narrow ? 0.34 : 0;
    const y = narrow && panel ? -0.25 : 0;
    this.G.cam.set(new THREE.Vector3(base.x + off * 0.6, 0.85, 2.5), new THREE.Vector3(base.x + off, 0.3 + y, 0), 36);
    this.G.cam.parallax = 0.05;
  }

  exit() {
    document.getElementById('side').classList.add('hidden');
    this.G.scene.fog.near = 14;
    this.G.cam.parallax = 0.08;
  }

  async idle(tk) {
    const cat = this.G.cat;
    const cam = this.G.camera;
    cat.setTail('happy');
    while (true) {
      cat.lookAt(cam.position);
      cat.setPose('sit');
      await tk.sleep(rand(3, 5));
      if (Math.random() < 0.3 && !this.preview) { cat.meow(); await tk.sleep(1); }
      const r = Math.random();
      if (r < 0.35) {
        cat.setPose('stand');
        cat.lookAt(new THREE.Vector3(SPOTS.studio.x + rand(-2, 2), rand(0, 1.5), rand(0, 2)));
        await tk.sleep(rand(1.5, 2.5));
      } else if (r < 0.6) {
        cat.setPose('loaf');
        cat.setMood({ eyes: 'sleepy' });
        await tk.sleep(rand(2.5, 4));
        cat.setMood({ eyes: 'open' });
      } else if (r < 0.75) {
        cat.setMood({ eyes: 'happy' });
        cat.setPose('sit');
        await tk.sleep(1.2);
        cat.setMood({ eyes: 'open' });
      }
    }
  }

  update(dt) {
    if (!this.dragging) this.spinT += dt * (this.preview ? 0.25 : 0);
    this.spin = damp(this.spin, this.spinT, 10, dt);
    this.G.world.pedestal.rotation.y = this.spin;
    this.G.cat.heading = this.baseHeading + this.spin;
  }

  pointerDown(e) {
    const hit = this.G.pickCat();
    if (hit) {
      const cat = this.G.cat;
      cat.meow();
      cat.setMood({ eyes: 'happy', blush: 1 });
      this.G.fx.emote(cat, 'heart', 3);
      clearTimeout(this.happyT);
      this.happyT = setTimeout(() => cat.setMood({ eyes: 'open', blush: 0 }), 1400);
      return;
    }
    this.dragging = true;
    this.lastX = e.clientX;
  }
  pointerMove(e) {
    if (!this.dragging) return;
    this.spinT += (e.clientX - this.lastX) * 0.012;
    this.lastX = e.clientX;
  }
  pointerUp() { this.dragging = false; }

  // ------------------------------------------------------------------ panel
  showPanel() {
    this.preview = false;
    const side = document.getElementById('side');
    side.classList.remove('hidden');
    side.classList.add('card');
    this.frame();
    this.render();
  }

  render() {
    const side = document.getElementById('side');
    const L = state.look, Vo = state.voice;
    const tabs = [['coat', '🎨 Coat'], ['face', '👀 Face'], ['body', '📏 Body'], ['voice', '🎵 Meow'], ['extras', '🎀 Extras']];
    const swatches = (key, list, extra = '') => `<div class="swatches">${list.map((c) => `<button class="sw${L[key] === c ? ' active' : ''}" style="background:${c}" data-sw="${key}" data-v="${c}"></button>`).join('')}
      <label class="sw custom" title="Custom colour"><input type="color" data-color="${key}" value="${L[key] && L[key].startsWith('#') ? L[key] : '#ffffff'}"></label>${extra}</div>`;
    const slider = (key, min, max, step, a, b, obj = 'look') => {
      const v = (obj === 'look' ? L : Vo)[key];
      return `<div class="slider-row"><span>${a}</span><input type="range" min="${min}" max="${max}" step="${step}" value="${v}" data-range="${key}" data-obj="${obj}"><span>${b}</span></div>`;
    };
    let body = '';
    if (this.tab === 'coat') {
      body = `
        <div class="row"><label>Pattern</label><div class="chips">${PATTERNS.map((p) => `<button class="chip${L.pattern === p.id ? ' active' : ''}" data-pattern="${p.id}">${p.label}</button>`).join('')}</div></div>
        <div class="row"><label>Main colour</label>${swatches('main', COATS)}</div>
        <div class="row"><label>${ACCENT_LABEL[L.pattern] || 'Accent colour'}</label>${swatches('accent', ACCENTS)}</div>
        <div class="row"><label>White markings <small>(socks, bib, belly)</small></label>${slider('white', 0, 1, 0.01, 'None', 'Lots')}</div>
        <div class="row"><button class="small-btn" data-act="seed">🎲 Shuffle markings</button></div>`;
    } else if (this.tab === 'face') {
      body = `
        <div class="row"><label>Eye colour</label>${swatches('eye', EYES)}</div>
        <div class="row"><label class="toggle"><input type="checkbox" data-check="oddEyes" ${L.oddEyes ? 'checked' : ''}> Odd eyes <small>(heterochromia)</small></label></div>
        ${L.oddEyes ? `<div class="row"><label>Second eye</label>${swatches('eye2', EYES)}</div>` : ''}
        <div class="row"><label>Eye size</label>${slider('eyeSize', 0.8, 1.3, 0.01, 'Small', 'Huge')}</div>
        <div class="row"><label>Nose</label>${swatches('nose', NOSES)}</div>
        <div class="row"><label>Head size</label>${slider('head', 0.85, 1.2, 0.01, 'Small', 'Big')}</div>
        <div class="row"><label>Ears</label>${slider('ears', 0.6, 1.5, 0.01, 'Folded', 'Lynx')}</div>`;
    } else if (this.tab === 'body') {
      body = `
        <div class="row"><label>Build</label>${slider('chonk', 0.8, 1.35, 0.01, 'Slim', 'Chonky')}</div>
        <div class="row"><label>Legs</label>${slider('legs', 0.6, 1.3, 0.01, 'Munchkin', 'Leggy')}</div>
        <div class="row"><label>Tail</label>${slider('tail', 0.45, 1.4, 0.01, 'Stubby', 'Long')}</div>
        <div class="row"><label>Fluffiness</label>${slider('fluff', 0, 1, 0.01, 'Sleek', 'Floof')}</div>`;
    } else if (this.tab === 'voice') {
      body = `
        <div class="row"><label>Meow style</label><div class="chips">${Object.entries(MEOW_STYLES).map(([k, s]) => `<button class="chip${Vo.style === k ? ' active' : ''}" data-style="${k}">${s.label}</button>`).join('')}</div></div>
        <div class="row"><label>Pitch</label>${slider('pitch', 0.6, 1.7, 0.01, 'Deep', 'Squeaky', 'voice')}</div>
        <div class="row"><label>Length</label>${slider('length', 0.5, 1.8, 0.01, 'Short', 'Long', 'voice')}</div>
        <div class="row"><label>Raspiness</label>${slider('rasp', 0, 0.8, 0.01, 'Clear', 'Raspy', 'voice')}</div>
        <div class="row"><button class="big" data-act="meow" style="width:100%">🔊 Say something!</button></div>`;
    } else if (this.tab === 'extras') {
      body = `
        <div class="row"><label>Collar</label><div class="swatches">${COLLARS.map((c) => `<button class="sw${L.collar === c ? ' active' : ''}" style="background:${c}" data-sw="collar" data-v="${c}"></button>`).join('')}
          <button class="chip${L.collar === 'none' ? ' active' : ''}" data-sw="collar" data-v="none">No collar</button></div></div>
        <div class="row"><label class="toggle"><input type="checkbox" data-check="bell" ${L.bell ? 'checked' : ''}> Jingle bell</label></div>`;
    }

    side.innerHTML = `
      <h2>${this.edit ? '✂️ Cat salon' : '🏠 Adopt a cat'}</h2>
      <p class="lead">${this.edit ? 'Give your kitty a makeover.' : 'This little one is looking for a home. Make them yours!'} Drag to spin, click to pet.</p>
      <div class="name-row"><input id="cat-name" maxlength="16" value="${esc(state.name)}" placeholder="Name your cat"><button data-act="name" title="Random name">🎲</button></div>
      <div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${this.tab === k ? 'active' : ''}">${l}</button>`).join('')}</div>
      <div class="tabbody">${body}</div>
      <div class="side-foot">
        <button class="big" data-act="random" title="Randomise everything">🎲 Surprise</button>
        <button class="big primary" data-act="adopt">${this.edit ? '💾 Save' : `💕 Adopt ${esc(state.name)}!`}</button>
      </div>`;
    this.bind(side);
  }

  bind(side) {
    const cat = this.G.cat;
    const setLook = (patch) => {
      Object.assign(state.look, patch);
      // throttle rebuilds to once per frame while dragging sliders
      this.pendingLook = { ...(this.pendingLook || {}), ...patch };
      if (!this.raf) this.raf = requestAnimationFrame(() => { this.raf = 0; cat.setLook(this.pendingLook); this.pendingLook = null; });
    };
    const previewMeow = () => {
      clearTimeout(this.meowT);
      this.meowT = setTimeout(() => cat.meow(), 250);
    };
    side.querySelectorAll('[data-tab]').forEach((b) => b.onclick = () => { audio.click(); this.tab = b.dataset.tab; this.render(); });
    side.querySelectorAll('[data-pattern]').forEach((b) => b.onclick = () => {
      audio.click();
      const p = b.dataset.pattern;
      const patch = { pattern: p };
      // Nudge colours toward something that reads well for the chosen pattern.
      if (p === 'calico') Object.assign(patch, { main: '#e8913a', accent: '#2a2a30' });
      if (p === 'tortie') Object.assign(patch, { main: '#d9772e', accent: '#2a2124' });
      if (p === 'siamese') Object.assign(patch, { main: '#f2e6d0', accent: '#4a3328', white: 0 });
      if (p === 'tuxedo') Object.assign(patch, { main: '#2a2a30', white: Math.max(state.look.white, 0.6) });
      if (p === 'van') Object.assign(patch, { main: '#e8913a' });
      setLook(patch);
      this.render();
    });
    side.querySelectorAll('[data-sw]').forEach((b) => b.onclick = () => { audio.click(); setLook({ [b.dataset.sw]: b.dataset.v }); this.render(); });
    side.querySelectorAll('[data-color]').forEach((inp) => inp.oninput = () => setLook({ [inp.dataset.color]: inp.value }));
    side.querySelectorAll('[data-range]').forEach((inp) => inp.oninput = () => {
      const v = parseFloat(inp.value);
      if (inp.dataset.obj === 'voice') { state.voice[inp.dataset.range] = v; cat.voice = { ...state.voice }; previewMeow(); }
      else setLook({ [inp.dataset.range]: v });
    });
    side.querySelectorAll('[data-check]').forEach((inp) => inp.onchange = () => { audio.click(); setLook({ [inp.dataset.check]: inp.checked }); if (inp.dataset.check === 'bell' && inp.checked) audio.jingle(); this.render(); });
    side.querySelectorAll('[data-style]').forEach((b) => b.onclick = () => {
      state.voice.style = b.dataset.style;
      cat.voice = { ...state.voice };
      cat.meow();
      this.render();
    });
    const name = side.querySelector('#cat-name');
    name.oninput = () => {
      state.name = name.value.trim() || 'Kitty';
      const btn = side.querySelector('[data-act=adopt]');
      if (!this.edit) btn.textContent = `💕 Adopt ${state.name}!`;
    };
    name.onkeydown = (e) => e.stopPropagation();
    side.querySelectorAll('[data-act]').forEach((b) => b.onclick = () => this.action(b.dataset.act));
  }

  action(act) {
    const cat = this.G.cat;
    if (act === 'meow') { cat.meow(); cat.setPose('sit'); }
    if (act === 'name') { audio.click(); state.name = pick(NAMES.filter((n) => n !== state.name)); this.render(); }
    if (act === 'seed') { audio.click(); state.look.seed = rand(0, 40); cat.setLook({ seed: state.look.seed }); }
    if (act === 'random') {
      audio.sparkle();
      Object.assign(state.look, randomLook());
      state.voice.style = pick(Object.keys(MEOW_STYLES).filter((k) => k !== 'silent'));
      state.voice.pitch = rand(0.75, 1.4);
      state.voice.length = rand(0.8, 1.3);
      state.voice.rasp = rand(0, 0.3);
      cat.voice = { ...state.voice };
      cat.setLook(state.look);
      this.G.fx.burst('sparkle', cat.headWorldPos(), 14, { speed: 0.6, up: 0.8, size: 0.05, gravity: -0.5, life: 1 });
      setTimeout(() => cat.meow(), 200);
      this.render();
    }
    if (act === 'adopt') this.adopt();
  }

  adopt() {
    const G = this.G;
    const cat = G.cat;
    const wasAdopted = state.adopted;
    state.adopted = true;
    state.voice = { ...cat.voice };
    save();
    document.getElementById('side').classList.add('hidden');
    this.frameCenter();
    if (!wasAdopted) {
      audio.chime();
      G.fx.confetti(new THREE.Vector3(SPOTS.studio.x, 1.4, 0.3), 120);
      ui.toast(`Welcome home, ${state.name}! 🎉`, 'good', 3);
      G.task.cancel();
      cat.setPose('sit');
      cat.setTail('happy');
      cat.setMood({ eyes: 'happy', blush: 1 });
      cat.lookAt(G.camera.position);
      setTimeout(() => cat.meow(), 400);
      G.fx.emote(cat, 'heart', 5);
      setTimeout(() => G.goto('hub'), 3200);
    } else {
      audio.sparkle();
      ui.toast(`Looking fabulous, ${state.name}! ✨`, 'good');
      setTimeout(() => G.goto('hub'), 700);
    }
  }

  frameCenter() {
    const base = SPOTS.studio;
    this.G.cam.fly(new THREE.Vector3(base.x, 0.7, 2.1), new THREE.Vector3(base.x, 0.33, 0), 1.0);
  }
}
