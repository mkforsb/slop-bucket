// Deal with the litter box: scoop clumps into the bin, top up or change the litter, and
// (if you like) watch kitty do their business — followed by the obligatory zoomies.

import * as THREE from 'three';
import { SPOTS } from '../world.js';
import { state, add, recomputeClean } from '../state.js';
import { audio } from '../audio.js';
import { ui } from '../ui.js';
import { rand, clamp, damp } from '../util.js';
import { walk, useLitter } from '../behaviors.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const WATCH = V(2.25, 0, -2.7);

export class LitterScene {
  constructor(G) { this.G = G; this.aim = V(); }

  enter() {
    const G = this.G, w = G.world, cat = G.cat;
    G.cam.set(V(3.25, 1.45, -1.25), V(3.3, 0.1, -3.0), 44);
    G.setShadowFocus(V(3.0, 0, -2.9), 1.8);
    const p = cat.root.position;
    if (p.x > 20 || Math.hypot(p.x - WATCH.x, p.z - WATCH.z) > 1.5) cat.place(WATCH.x, WATCH.z, 2.4);
    cat.root.position.y = 0;
    w.scoop.visible = true;
    this.aim.set(SPOTS.litter.x, w.sandTop, SPOTS.litter.z + 0.1);
    w.scoop.position.copy(this.aim);
    this.held = null; this.down = false; this.stinkT = 0; this.pourT = 0; this.catBusy = false;
    this.overTrash = false; this.siftT = 0;
    ui.setTools([
      { id: 'go', group: 'action', emoji: '🐾', label: 'Nature calls', title: 'Let kitty use the box', onClick: () => this.natureCalls() },
      { id: 'top', group: 'action', emoji: '➕', label: 'Top up litter', onClick: () => this.topUp() },
      { id: 'change', group: 'action', emoji: '♻️', label: 'Change all litter', onClick: () => this.changeAll() },
    ]);
    this.updateHint();
    G.canvas.style.cursor = 'none';
    G.task.run((tk) => this.brain(tk));
  }

  exit() {
    const w = this.G.world;
    if (this.held) this.returnClump();
    w.scoop.visible = false;
  }

  updateHint() {
    const n = state.clumps.length;
    ui.hint(n ? `Scoop the clumps (${n} left): press on one, then drag it to the bin` : 'All clean! The box is fresh ✨');
  }

  async brain(tk) {
    const G = this.G, cat = G.cat;
    while (true) {
      if (state.bladder >= 1 || this.wantGo) {
        this.wantGo = false;
        if (this.held) this.returnClump();
        this.catBusy = true;
        ui.setToolEnabled('go', false);
        try { await useLitter(G, tk); } finally { this.catBusy = false; ui.setToolEnabled('go', true); }
        this.updateHint();
        await walk(G, tk, WATCH.x, WATCH.z, 0.45);
        continue;
      }
      cat.setPose('sit');
      cat.faceToward(SPOTS.litter.x, SPOTS.litter.z);
      cat.lookAt(G.world.scoop.position);
      cat.setTail(state.needs.clean > 60 ? 'happy' : 'neutral');
      if (state.needs.clean < 40) cat.setMood({ ears: 0.5 }); else cat.setMood({ ears: 0 });
      await tk.sleep(0.4);
    }
  }

  natureCalls() {
    if (this.catBusy) return;
    this.wantGo = true;
    ui.toast(`${state.name} heads to the box…`, 'info', 1.6);
  }

  topUp() {
    const w = this.G.world;
    if (state.litter > 0.95) { ui.toast('The litter is already nice and deep', 'info', 1.6); return; }
    this.pourT = 1.2;
    this.pourTo = Math.min(1, state.litter + 0.45);
    audio.pour();
    ui.toast('Topping up with fresh litter', 'good', 1.6);
    void w;
  }

  changeAll() {
    const G = this.G, w = G.world;
    if (this.catBusy) { ui.toast('Wait until kitty is done! 🙈', 'info'); return; }
    if (this.held) { G.scene.remove(this.held.mesh); this.held = null; }
    const n = state.clumps.length;
    state.clumps = [];
    state.litter = 1;
    w.syncClumps(state.clumps);
    w.setLitterLevel(1);
    recomputeClean();
    audio.scoop(); setTimeout(() => audio.pour(), 150); setTimeout(() => audio.sparkle(), 400);
    G.fx.burst('sparkle', V(SPOTS.litter.x, w.sandTop + 0.05, SPOTS.litter.z), 16, { speed: 0.7, up: 1, size: 0.05, gravity: -1, life: 1 });
    ui.toast(n ? 'Fresh box! (A full change every 2–3 weeks keeps it nice)' : 'Fresh litter! ✨', 'good', 3);
    G.fx.emote(G.cat, 'heart', 2);
    this.updateHint();
  }

  // ------------------------------------------------------------------ input
  pointerMove() {
    const G = this.G, w = G.world;
    const p = G.rayPlane(w.sandTop);
    if (!p) return;
    const tr = SPOTS.trash;
    this.overTrash = Math.hypot(p.x - tr.x, p.z - tr.z) < 0.34;
    this.aim.set(clamp(p.x, 1.6, 4.2), w.sandTop, clamp(p.z, -3.6, -1.6));
  }

  pointerDown() {
    this.down = true;
    this.pointerMove();
    this.tryPick();
  }

  pointerUp() {
    this.down = false;
    if (this.held) {
      if (this.overTrash) this.dump();
      else this.returnClump(true);
    }
  }

  inBox(p) {
    const b = SPOTS.litter, d = this.G.world.litterDims;
    return Math.abs(p.x - b.x) < d.W / 2 - 0.05 && Math.abs(p.z - b.z) < d.D / 2 - 0.05;
  }

  tryPick() {
    const G = this.G, w = G.world;
    if (this.held || !this.inBox(this.aim)) return;
    const b = SPOTS.litter;
    let best = null, bd = 0.1;
    for (const c of state.clumps) {
      const d = Math.hypot(b.x + c.x - this.aim.x, b.z + c.z - this.aim.z);
      if (d < bd) { bd = d; best = c; }
    }
    audio.scoop();
    G.fx.burst('dot', this.aim.clone().setY(w.sandTop + 0.02), 6, { speed: 0.3, up: 0.5, size: 0.018, colors: [0xe9dcc0, 0xd9c7a0], life: 0.5, floor: w.sandTop });
    if (!best) return;
    const mesh = w.clumpMeshes.get(best.id);
    mesh.userData.held = true;
    G.scene.attach(mesh);
    this.held = { clump: best, mesh };
  }

  returnClump(atScoop = false) {
    const G = this.G, w = G.world;
    const { clump, mesh } = this.held;
    const b = SPOTS.litter;
    if (atScoop && this.inBox(this.aim)) { clump.x = this.aim.x - b.x; clump.z = this.aim.z - b.z; }
    w.litterBox.attach(mesh);
    mesh.position.set(clump.x, w.sandTop - 0.004, clump.z);
    mesh.rotation.set(0, clump.rot, 0);
    mesh.userData.held = false;
    this.held = null;
  }

  dump() {
    const G = this.G, w = G.world;
    const { clump, mesh } = this.held;
    this.held = null;
    w.trashLidOpen = 1;
    // fall into the bin
    const start = mesh.position.clone();
    const end = SPOTS.trash.clone().setY(0.35);
    let k = 0;
    const anim = () => {
      k += 0.06;
      mesh.position.lerpVectors(start, end, Math.min(1, k)).setY(lerp3(start.y, 0.75, end.y, Math.min(1, k)));
      if (k < 1) requestAnimationFrame(anim); else G.scene.remove(mesh);
    };
    anim();
    setTimeout(() => audio.trash(), 250);
    state.clumps = state.clumps.filter((c) => c !== clump);
    w.clumpMeshes.delete(clump.id);
    state.stats.scoops++;
    state.litter = Math.max(0, state.litter - 0.025);
    w.setLitterLevel(state.litter);
    recomputeClean();
    if (!state.clumps.length) {
      ui.toast('Squeaky clean! ✨', 'good');
      audio.sparkle();
      G.fx.burst('sparkle', V(SPOTS.litter.x, w.sandTop + 0.05, SPOTS.litter.z), 12, { speed: 0.6, up: 0.9, size: 0.045, gravity: -1, life: 0.9 });
      G.fx.emote(G.cat, 'heart', 2);
      add('love', 3);
    } else ui.toast(clump.type === 'poop' ? 'Scooped! 💩→🗑️' : 'Clump scooped! 🗑️', 'good', 1.2);
    this.updateHint();
    if (state.litter < 0.4) ui.toast('Litter is getting low — top it up!', 'info', 2);
  }

  // ------------------------------------------------------------------ per-frame
  update(dt) {
    const G = this.G, w = G.world, t = G.clock.time;
    // scoop follows the pointer; hovers higher over the bin
    const target = this.aim.clone();
    if (this.overTrash) target.set(SPOTS.trash.x, 0.62, SPOTS.trash.z + 0.05);
    else target.y = w.sandTop + (this.down && this.inBox(this.aim) && !this.held ? 0.0 : 0.06) + (this.inBox(this.aim) ? 0 : 0.05);
    w.scoop.position.lerp(target, 1 - Math.exp(-20 * dt));
    const tilt = this.held ? -0.35 : this.overTrash ? 0.8 : 0;
    w.scoop.rotation.x = damp(w.scoop.rotation.x, tilt, 10, dt);
    if (this.held) {
      this.held.mesh.position.copy(w.scoop.position).add(V(0, 0.02, 0));
      if (this.overTrash && !this.down) this.dump();
    }
    // sifting through sand
    if (this.down && !this.held && this.inBox(this.aim)) {
      this.siftT -= dt;
      if (this.siftT < 0) {
        this.siftT = 0.3;
        audio.sandDig();
        G.fx.burst('dot', this.aim.clone().setY(w.sandTop + 0.02), 3, { speed: 0.25, up: 0.4, size: 0.015, colors: [0xe9dcc0], life: 0.4, floor: w.sandTop });
        this.tryPick();
      }
    }
    // topping up
    if (this.pourT > 0) {
      this.pourT -= dt;
      state.litter = Math.min(this.pourTo, state.litter + dt * 0.45);
      w.setLitterLevel(state.litter);
      recomputeClean();
      const p = V(SPOTS.litter.x + rand(-0.25, 0.25), 0.8, SPOTS.litter.z + rand(-0.15, 0.15));
      G.fx.spawn('dot', p, { vel: V(0, -1.5, 0), gravity: -5, size: 0.02, life: 0.5, pop: false, grow: 0, wobble: 0, color: 0xe9dcc0, floor: w.sandTop });
      if (this.pourT <= 0) this.updateHint();
    }
    // stink lines
    const n = state.clumps.length;
    if (n) {
      this.stinkT -= dt;
      if (this.stinkT < 0) {
        this.stinkT = 1.6 / n;
        const c = state.clumps[Math.floor(Math.random() * n)];
        G.fx.spawn('stink', V(SPOTS.litter.x + c.x, w.sandTop + 0.08, SPOTS.litter.z + c.z), { vel: V(0, 0.12, 0), size: 0.13, life: 2.2, grow: 0.2, wobble: 1.5, pop: false });
      }
    }
    void t;
  }
}

function lerp3(a, b, c, t) {
  const u = 1 - t;
  return u * u * a + 2 * u * t * b + t * t * c;
}
