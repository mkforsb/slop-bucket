// Persistent game state (localStorage) and needs simulation.

import { DEFAULT_LOOK, DEFAULT_VOICE } from './cat.js';
import { clamp } from './util.js';

const KEY = 'purrfect-pals-v1';

export const NEEDS = [
  { id: 'hunger', icon: '🍗', label: 'Food' },
  { id: 'love', icon: '💗', label: 'Love' },
  { id: 'fun', icon: '🧶', label: 'Fun' },
  { id: 'clean', icon: '✨', label: 'Litter' },
];

// Points lost per second of play.
const DECAY = { hunger: 0.07, love: 0.05, fun: 0.06 };

function fresh() {
  return {
    adopted: false,
    name: 'Mochi',
    look: { ...DEFAULT_LOOK },
    voice: { ...DEFAULT_VOICE },
    needs: { hunger: 55, love: 50, fun: 45, clean: 100 },
    bowl: { food: 0, kind: 'kibble' },
    water: 0.6,
    litter: 1, // litter depth/freshness 0..1
    clumps: [],
    bladder: 0.5,
    treatsRecent: 0,
    stats: { meals: 0, pets: 0, plays: 0, scoops: 0, days: 1 },
    saved: Date.now(),
  };
}

export const state = fresh();

export function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return false;
    const s = JSON.parse(raw);
    Object.assign(state, fresh(), s);
    state.look = { ...DEFAULT_LOOK, ...s.look };
    state.voice = { ...DEFAULT_VOICE, ...s.voice };
    // offline catch-up (capped so returning players aren't punished too hard)
    const away = clamp((Date.now() - (s.saved || Date.now())) / 1000, 0, 600);
    tick(away, true);
    return state.adopted;
  } catch (e) {
    return false;
  }
}

export function save() {
  state.saved = Date.now();
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* private mode etc. */ }
}

export function reset() {
  Object.assign(state, fresh());
  try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
}

export function recomputeClean() {
  state.needs.clean = clamp(100 - state.clumps.length * 22 - (1 - state.litter) * 35, 0, 100);
}

export function tick(dt, offline = false) {
  const n = state.needs;
  for (const k in DECAY) n[k] = clamp(n[k] - DECAY[k] * dt * (offline ? 0.5 : 1), 0, 100);
  state.bladder = clamp(state.bladder + dt / 160, 0, 1.5);
  state.treatsRecent = Math.max(0, state.treatsRecent - dt / 60);
  recomputeClean();
}

export function add(need, amount) {
  state.needs[need] = clamp(state.needs[need] + amount, 0, 100);
}

export function mood() {
  const n = state.needs;
  const avg = (n.hunger + n.love + n.fun + n.clean) / 4;
  const min = Math.min(n.hunger, n.love, n.fun, n.clean);
  const score = avg * 0.6 + min * 0.4;
  if (score > 75) return { face: '😻', label: 'Blissful', score };
  if (score > 55) return { face: '😺', label: 'Happy', score };
  if (score > 35) return { face: '🐱', label: 'Okay', score };
  if (score > 18) return { face: '😿', label: 'Sad', score };
  return { face: '🙀', label: 'Miserable', score };
}

// Lowest need under a threshold, used for the thought bubble.
export function urgentNeed(th = 30) {
  let best = null;
  for (const nd of NEEDS) {
    const v = state.needs[nd.id];
    if (v < th && (!best || v < state.needs[best.id])) best = nd;
  }
  return best;
}
