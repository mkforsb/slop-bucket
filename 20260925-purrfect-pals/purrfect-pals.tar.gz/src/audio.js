// All sound is synthesised with WebAudio — no sample files, so the game stays a single HTML file.

import { rand, clamp } from './util.js';

// Formant frequencies (F1, F2, F3) for vowel-ish shapes, shifted up for a tiny cat vocal tract.
const VOWELS = {
  i: [420, 2500, 3400],
  e: [620, 2100, 3000],
  a: [980, 1550, 3000],
  o: [660, 1050, 2800],
  u: [420, 880, 2600],
  m: [300, 1200, 2600],
};

// Meow styles: f = pitch contour [t, multiplier], v = vowel path, dur in seconds.
export const MEOW_STYLES = {
  classic: { label: 'Classic', base: 560, dur: 0.72, f: [[0, 0.95], [0.3, 1.3], [0.7, 1.1], [1, 0.75]], v: [[0, 'm'], [0.12, 'i'], [0.35, 'e'], [0.6, 'a'], [1, 'u']], rasp: 0 },
  kitten: { label: 'Squeaky', base: 950, dur: 0.38, f: [[0, 0.9], [0.4, 1.25], [1, 1.0]], v: [[0, 'i'], [0.5, 'e'], [1, 'i']], rasp: 0 },
  chirp: { label: 'Chirpy', base: 620, dur: 0.3, f: [[0, 0.8], [0.6, 1.1], [1, 1.5]], v: [[0, 'm'], [0.4, 'u'], [1, 'a']], trill: 0.8, rasp: 0 },
  trill: { label: 'Trilly', base: 520, dur: 0.55, f: [[0, 0.9], [0.5, 1.2], [1, 1.1]], v: [[0, 'm'], [0.5, 'u'], [1, 'o']], trill: 1, rasp: 0 },
  grumpy: { label: 'Grumpy', base: 360, dur: 1.05, f: [[0, 1], [0.35, 1.18], [1, 0.72]], v: [[0, 'e'], [0.3, 'a'], [0.7, 'o'], [1, 'u']], rasp: 0.35 },
  yowl: { label: 'Yowly', base: 480, dur: 1.4, f: [[0, 0.9], [0.25, 1.35], [0.5, 1.05], [0.75, 1.3], [1, 0.8]], v: [[0, 'e'], [0.3, 'a'], [0.6, 'o'], [0.8, 'a'], [1, 'u']], vib: 3, rasp: 0.1 },
  silent: { label: 'Silent', base: 600, dur: 0.6, f: [[0, 1], [1, 1]], v: [[0, 'a'], [1, 'u']], silent: true, rasp: 0 },
};

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.purrTarget = 0;
    this.purrLevel = 0;
    this.purrT = 0;
  }

  // Must be called from a user gesture (browser autoplay policy).
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.8;
      const comp = this.ctx.createDynamicsCompressor();
      this.master.connect(comp).connect(this.ctx.destination);
      this.noiseBuf = this.makeNoise(2);
      this.initPurr();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.8, this.ctx.currentTime, 0.05);
  }

  makeNoise(sec) {
    const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * sec, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  noise(loop = false) {
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = loop;
    return s;
  }

  get ready() { return !!this.ctx && this.ctx.state === 'running'; }

  // ------------------------------------------------------------------ meow
  // Returns duration in seconds so the cat's mouth can be animated in sync.
  meow(voice = {}) {
    const S = MEOW_STYLES[voice.style] || MEOW_STYLES.classic;
    const pitch = voice.pitch ?? 1;
    const dur = S.dur * (voice.length ?? 1) * rand(0.9, 1.1);
    if (!this.ready) return dur;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + 0.02;
    const f0 = S.base * pitch * rand(0.95, 1.05);

    const out = ctx.createGain();
    out.gain.value = 0;
    out.connect(this.master);

    // Voiced source
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(f0 * S.f[0][1], t0);
    for (const [t, m] of S.f) osc.frequency.linearRampToValueAtTime(f0 * m, t0 + t * dur);
    const vib = ctx.createOscillator();
    vib.frequency.value = 5.5;
    const vibG = ctx.createGain();
    vibG.gain.value = f0 * 0.015 * (S.vib || 1);
    vib.connect(vibG).connect(osc.frequency);

    const src = ctx.createGain();
    const voiced = ctx.createGain();
    voiced.gain.value = S.silent ? 0 : 1; // the "silent meow": mouth opens, only a breath comes out
    osc.connect(voiced).connect(src);

    // Breath / rasp noise
    const rasp = clamp((voice.rasp ?? 0.15) + S.rasp);
    const nz = this.noise(true);
    const nzG = ctx.createGain();
    nzG.gain.value = S.silent ? 0.5 : rasp * 0.6;
    nz.connect(nzG).connect(src);

    // Trill: rolling amplitude modulation ("mrrrp")
    let trillOsc = null;
    const trillAmt = S.trill || 0;
    const shaped = ctx.createGain();
    src.connect(shaped);
    if (trillAmt > 0) {
      trillOsc = ctx.createOscillator();
      trillOsc.frequency.value = 28;
      const tg = ctx.createGain();
      tg.gain.value = 0.5 * trillAmt;
      shaped.gain.value = 1 - 0.5 * trillAmt;
      trillOsc.connect(tg).connect(shaped.gain);
    }

    // Formant filter bank
    const gains = [1, 0.7, 0.35];
    const qs = [5, 9, 12];
    for (let k = 0; k < 3; k++) {
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.value = qs[k];
      const shift = Math.pow(pitch, 0.35);
      bp.frequency.setValueAtTime(VOWELS[S.v[0][1]][k] * shift, t0);
      for (const [t, vw] of S.v) bp.frequency.linearRampToValueAtTime(VOWELS[vw][k] * shift, t0 + t * dur);
      const g = ctx.createGain();
      g.gain.value = gains[k] * 2.5;
      shaped.connect(bp).connect(g).connect(out);
    }

    // Amplitude envelope
    const peak = S.silent ? 0.25 : 0.55;
    out.gain.setValueAtTime(0, t0);
    out.gain.linearRampToValueAtTime(peak, t0 + Math.min(0.07, dur * 0.2));
    out.gain.setValueAtTime(peak * 0.9, t0 + dur * 0.65);
    out.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

    const nodes = [osc, vib, nz, trillOsc].filter(Boolean);
    for (const n of nodes) { n.start(t0); n.stop(t0 + dur + 0.05); }
    osc.onended = () => out.disconnect();
    return dur;
  }

  // ------------------------------------------------------------------ purr
  initPurr() {
    const ctx = this.ctx;
    const nz = this.noise(true);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 260;
    lp.Q.value = 3;
    this.purrAM = ctx.createGain();
    this.purrAM.gain.value = 0.5;
    this.purrLfo = ctx.createOscillator();
    this.purrLfo.type = 'triangle';
    this.purrLfo.frequency.value = 26;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 0.5;
    this.purrLfo.connect(lfoG).connect(this.purrAM.gain);
    this.purrOut = ctx.createGain();
    this.purrOut.gain.value = 0;
    nz.connect(lp).connect(this.purrAM).connect(this.purrOut).connect(this.master);
    nz.start();
    this.purrLfo.start();
  }

  setPurr(v) { this.purrTarget = clamp(v); }

  update(dt) {
    if (!this.ctx) return;
    this.purrLevel += (this.purrTarget - this.purrLevel) * Math.min(1, dt * 3);
    this.purrT += dt;
    // Breathing cycle: inhale/exhale alternate volume and rate a little.
    const breath = Math.sin(this.purrT * Math.PI * 2 / 2.4);
    const vol = this.purrLevel * (0.75 + 0.25 * breath) * 1.6;
    this.purrOut.gain.setTargetAtTime(vol, this.ctx.currentTime, 0.05);
    this.purrLfo.frequency.setTargetAtTime(breath > 0 ? 24 : 28, this.ctx.currentTime, 0.1);
  }

  // ------------------------------------------------------------------ sfx helpers
  env(node, t0, a, peak, d) {
    node.gain.setValueAtTime(0, t0);
    node.gain.linearRampToValueAtTime(peak, t0 + a);
    node.gain.exponentialRampToValueAtTime(0.0008, t0 + a + d);
  }

  noiseBurst({ type = 'bandpass', freq = 2000, q = 1, peak = 0.3, a = 0.003, d = 0.06, delay = 0, sweepTo = null }) {
    if (!this.ready) return;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + delay;
    const s = this.noise();
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t0);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t0 + a + d);
    f.Q.value = q;
    const g = ctx.createGain();
    this.env(g, t0, a, peak, d);
    s.connect(f).connect(g).connect(this.master);
    s.start(t0, rand(0, 1.5));
    s.stop(t0 + a + d + 0.05);
  }

  tone({ freq = 440, to = null, type = 'sine', peak = 0.2, a = 0.005, d = 0.2, delay = 0 }) {
    if (!this.ready) return;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + a + d);
    const g = ctx.createGain();
    this.env(g, t0, a, peak, d);
    o.connect(g).connect(this.master);
    o.start(t0);
    o.stop(t0 + a + d + 0.05);
  }

  click() { this.tone({ freq: 900, to: 1400, peak: 0.08, d: 0.05, type: 'triangle' }); }
  pop() { this.tone({ freq: 500, to: 1100, peak: 0.15, d: 0.09 }); }
  kibble() { this.noiseBurst({ freq: rand(2500, 4500), q: 4, peak: 0.12, d: 0.025 }); this.tone({ freq: rand(1800, 2600), peak: 0.03, d: 0.03, type: 'triangle' }); }
  crunch() { for (let i = 0; i < 3; i++) this.noiseBurst({ freq: rand(1200, 3000), q: 1.5, peak: 0.18, d: 0.04, delay: i * rand(0.04, 0.07) }); }
  slurp() { this.noiseBurst({ type: 'lowpass', freq: 900, peak: 0.2, a: 0.02, d: 0.15, sweepTo: 300 }); }
  lap() { this.tone({ freq: rand(700, 900), to: 300, peak: 0.1, d: 0.06 }); this.noiseBurst({ freq: 1800, q: 3, peak: 0.05, d: 0.04 }); }
  plop() { this.tone({ freq: 380, to: 110, peak: 0.28, d: 0.14 }); this.noiseBurst({ type: 'lowpass', freq: 700, peak: 0.15, d: 0.1 }); }
  pour() { this.noiseBurst({ type: 'bandpass', freq: 1400, q: 0.7, peak: 0.12, a: 0.03, d: 0.25 }); }
  splash() { this.noiseBurst({ type: 'bandpass', freq: 1200, q: 0.8, peak: 0.25, a: 0.02, d: 0.35, sweepTo: 500 }); }
  jingle() { [2093, 2637, 3136, 5200].forEach((f, i) => this.tone({ freq: f * rand(0.99, 1.01), peak: 0.05, d: 0.35, delay: i * 0.015 })); }
  scoop() { this.noiseBurst({ type: 'lowpass', freq: 2200, peak: 0.22, a: 0.04, d: 0.25, sweepTo: 500 }); }
  sandDig() { this.noiseBurst({ type: 'bandpass', freq: rand(1500, 2800), q: 1, peak: 0.14, a: 0.01, d: 0.12 }); }
  thud() { this.tone({ freq: 140, to: 55, peak: 0.35, d: 0.18 }); this.noiseBurst({ type: 'lowpass', freq: 400, peak: 0.2, d: 0.08 }); }
  swish() { this.noiseBurst({ type: 'bandpass', freq: 3000, q: 0.8, peak: 0.08, a: 0.03, d: 0.12, sweepTo: 1200 }); }
  boing() { this.tone({ freq: 220, to: 520, peak: 0.15, d: 0.18, type: 'triangle' }); }
  hiss() { this.noiseBurst({ type: 'highpass', freq: 3500, peak: 0.25, a: 0.05, d: 0.6 }); }
  chime() { [784, 988, 1175, 1568].forEach((f, i) => this.tone({ freq: f, peak: 0.1, d: 0.3, delay: i * 0.08, type: 'triangle' })); }
  sad() { [523, 440, 349].forEach((f, i) => this.tone({ freq: f, peak: 0.08, d: 0.3, delay: i * 0.14, type: 'triangle' })); }
  sparkle() { for (let i = 0; i < 5; i++) this.tone({ freq: rand(2000, 4200), peak: 0.04, d: 0.12, delay: i * 0.05 }); }
  brush() { this.noiseBurst({ type: 'highpass', freq: 2500, peak: 0.06, a: 0.02, d: 0.08 }); }
  trash() { this.tone({ freq: 300, to: 120, peak: 0.15, d: 0.12, type: 'square' }); this.noiseBurst({ type: 'lowpass', freq: 800, peak: 0.25, d: 0.12, delay: 0.02 }); }
  zap() { this.tone({ freq: 1400, to: 2200, peak: 0.03, d: 0.05, type: 'square' }); }
}

export const audio = new AudioEngine();
