// Procedural cute cat: built from primitives, coat pattern painted by a shader in "cat space"
// (so stripes/patches flow continuously across body parts), animated procedurally with
// pose blending, one-bone leg IK, a chain tail and facial expressions.

import * as THREE from 'three';
import { clamp, lerp, damp, dampAngle, wrapAngle, rand, chance, smoothstep } from './util.js';
import { audio } from './audio.js';

export const PATTERNS = [
  { id: 'solid', label: 'Solid' },
  { id: 'tabby', label: 'Tabby' },
  { id: 'tuxedo', label: 'Tuxedo' },
  { id: 'calico', label: 'Calico' },
  { id: 'tortie', label: 'Tortie' },
  { id: 'siamese', label: 'Pointed' },
  { id: 'spotted', label: 'Spotted' },
  { id: 'van', label: 'Van' },
];

export const DEFAULT_LOOK = {
  pattern: 'tabby', main: '#e8913a', accent: '#8a3f14', white: 0.35, seed: 3.7,
  eye: '#9ccc3c', oddEyes: false, eye2: '#5fb7ff', nose: '#f39aa8',
  chonk: 1, legs: 1, ears: 1, tail: 1, head: 1, fluff: 0.3, eyeSize: 1,
  collar: '#e8457b', bell: true,
};
export const DEFAULT_VOICE = { style: 'classic', pitch: 1, length: 1, rasp: 0.1 };

// Changing these requires rebuilding geometry; everything else is a uniform/material tweak.
const SHAPE_KEYS = ['chonk', 'legs', 'ears', 'tail', 'head', 'fluff', 'eyeSize', 'bell'];

const PART = { torso: 0, head: 1, leg: 2, tail: 3, ear: 4, face: 5 };

// --------------------------------------------------------------------------- shaders
const PATTERN_GLSL = /* glsl */ `
uniform int uPattern;
uniform vec3 uMain, uAccent, uWhiteCol;
uniform float uWhite, uSeed, uRim;
uniform vec3 uBodyC, uBodyR, uHeadC, uMuzzle;
varying vec4 vCatPos;

float h31(vec3 p){ p = fract(p*0.3183099 + 0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float vnoise(vec3 x){
  vec3 i = floor(x); vec3 f = fract(x); f = f*f*(3.0-2.0*f);
  return mix(mix(mix(h31(i),h31(i+vec3(1,0,0)),f.x), mix(h31(i+vec3(0,1,0)),h31(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(h31(i+vec3(0,0,1)),h31(i+vec3(1,0,1)),f.x), mix(h31(i+vec3(0,1,1)),h31(i+vec3(1,1,1)),f.x),f.y), f.z);
}
float fbm(vec3 p){ float a = 0.5, s = 0.0; for(int i=0;i<4;i++){ s += a*vnoise(p); p = p*2.03 + 1.7; a *= 0.5; } return s; }
float cells(vec3 p){
  vec3 i = floor(p), f = fract(p); float d = 8.0;
  for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){
    vec3 g = vec3(float(x),float(y),float(z));
    vec3 o = vec3(h31(i+g+uSeed), h31(i+g+11.3+uSeed), h31(i+g+27.1+uSeed));
    d = min(d, length(g + o*0.8 - f));
  }
  return d;
}

// White spotting: belly, chest, paws, muzzle, blaze — grows with amt.
float whiteMask(vec3 p, float part, float amt){
  if (amt < 0.02) return 0.0;
  float n = (fbm(p*11.0 + uSeed) - 0.5) * 0.35;
  vec3 q = (p - uBodyC) / uBodyR;
  float m = 0.0;
  // belly + chest (chest rises higher toward the front)
  float bellyLine = -1.0 + 1.5*amt + max(q.z, 0.0)*1.1*amt + n;
  if (part < 0.5 || part > 4.5 || (part > 0.5 && part < 1.5)) m = max(m, smoothstep(0.08, -0.08, q.y - bellyLine));
  // paws / socks
  if (part > 1.5 && part < 2.5) m = max(m, smoothstep(0.012, -0.012, p.y - (0.035 + 0.16*amt*amt + n*0.03)));
  // muzzle and chin
  float mz = length((p - uMuzzle) * vec3(1.0, 1.25, 1.0));
  m = max(m, smoothstep(0.012, -0.012, mz - (0.03 + 0.06*amt + n*0.02)));
  // blaze up the nose
  if (amt > 0.55 && (part > 0.5 && part < 1.5 || part > 4.5)) {
    float w = (amt - 0.55) * 0.12 + 0.004;
    float up = p.y - uMuzzle.y;
    m = max(m, smoothstep(0.004, -0.004, abs(p.x) - w * (1.2 - up*6.0)) * step(p.z, uHeadC.z + 1.0) * step(uHeadC.z, p.z) * step(up, 0.14));
  }
  // tail tip for big white amounts
  if (part > 2.5 && part < 3.5) m = max(m, step(0.95 - (amt-0.6)*0.6, fract(vCatPos.w)) * step(0.6, amt));
  return clamp(m, 0.0, 1.0);
}

vec3 coatColor(vec4 cp){
  vec3 p = cp.xyz;
  float part = floor(cp.w + 0.0001);
  float along = fract(cp.w);
  vec3 col = uMain;
  float white = uWhite;
  vec3 q = (p - uBodyC) / uBodyR;

  if (uPattern == 1) { // tabby
    float s;
    if (part < 0.5) s = sin(p.z*52.0 + fbm(p*7.0+uSeed)*5.0 + abs(p.x)*9.0);
    else if (part < 1.5) {
      float top = smoothstep(0.035, 0.08, p.y - uHeadC.y);
      float forehead = sin(abs(p.x)*95.0 + 1.2 + fbm(p*8.0)*2.0) * top;
      float side = sin((p.y - uHeadC.y)*70.0 + 0.8) * smoothstep(0.13, 0.16, abs(p.x)) * (1.0 - top) * step(p.z, uHeadC.z + 0.06);
      s = max(forehead, side);
    }
    else if (part < 2.5) s = sin(p.y*60.0 + fbm(p*9.0)*2.5) * smoothstep(0.02, 0.06, p.y);
    else if (part < 3.5) s = sin(along*6.2831*5.0);
    else if (part < 4.5) s = -1.0;
    else s = sin((p.y - uHeadC.y)*120.0) * smoothstep(0.06, 0.09, abs(p.x)) - 0.4;
    float stripe = smoothstep(0.15, 0.55, s);
    if (part > 2.5 && part < 3.5) stripe = max(stripe, step(0.9, along));
    float dorsal = part < 0.5 ? smoothstep(0.55, 0.95, q.y) * 0.6 : 0.0;
    col = mix(uMain, uAccent, max(stripe, dorsal));
    col = mix(col, uMain * 1.15 + 0.05, smoothstep(-0.2, -0.8, q.y) * 0.5); // lighter belly
  } else if (uPattern == 2) { // tuxedo
    white = max(uWhite, 0.6);
  } else if (uPattern == 3) { // calico: white base with orange + black patches
    float n1 = fbm(p*7.0 + uSeed);
    float n2 = fbm(p*6.0 + uSeed + 17.0);
    col = uWhiteCol;
    col = mix(col, uMain, smoothstep(0.52, 0.56, n1));
    col = mix(col, uAccent, smoothstep(0.55, 0.59, n2));
    white = max(uWhite, 0.45);
  } else if (uPattern == 4) { // tortie: mottled brindle
    float n = fbm(p*16.0 + uSeed) + fbm(p*5.0 + uSeed*2.0)*0.4;
    col = mix(uAccent, uMain, smoothstep(0.62, 0.72, n));
  } else if (uPattern == 5) { // pointed (siamese)
    float face = 1.0 - smoothstep(0.075, 0.11, length((p - uMuzzle - vec3(0.0, 0.02, -0.02)) * vec3(0.85, 1.0, 1.3)));
    float pts = face;
    if (part > 3.5 && part < 4.5) pts = 1.0;
    if (part > 1.5 && part < 2.5) pts = smoothstep(uBodyC.y - 0.02, 0.03, p.y);
    if (part > 2.5 && part < 3.5) pts = smoothstep(0.05, 0.4, along);
    if (part < 0.5) pts = smoothstep(0.7, 1.4, length(q)) * 0.5;
    col = mix(uMain, uAccent, clamp(pts, 0.0, 1.0));
    col = mix(col, uMain * 0.8 + uAccent * 0.2, smoothstep(0.2, 1.0, q.y) * 0.4 * float(part < 0.5));
  } else if (uPattern == 6) { // spotted
    float c = cells(p*20.0);
    float spot = smoothstep(0.42, 0.34, c);
    if (part > 3.5 && part < 4.5) spot = 0.0;
    if (part > 2.5 && part < 3.5) spot = step(0.5, fract(along*5.0));
    if (part > 0.5 && part < 1.5) spot *= smoothstep(0.03, 0.06, p.y - uHeadC.y) + smoothstep(0.09, 0.12, abs(p.x));
    col = mix(uMain, uAccent, spot);
    col = mix(col, uMain * 1.15 + 0.05, smoothstep(-0.2, -0.8, q.y) * 0.5);
  } else if (uPattern == 7) { // van: white with colour on the head cap and tail
    float n = fbm(p*8.0 + uSeed) * 0.05;
    float cap = (part > 0.5 && part < 1.5 || part > 3.5 && part < 4.5) ? smoothstep(0.0, 0.02, p.y - uHeadC.y - 0.015 + n - abs(p.x)*0.25) : 0.0;
    if (part > 3.5 && part < 4.5) cap = 1.0;
    float tail = (part > 2.5 && part < 3.5) ? 1.0 : 0.0;
    float spot = part < 0.5 ? smoothstep(0.55, 0.6, fbm(p*5.0 + uSeed)) : 0.0;
    col = mix(uWhiteCol, uMain, max(max(cap, tail), spot));
    white = 0.0;
  }

  float wm = whiteMask(p, part, white);
  if (uPattern == 7) wm = 0.0;
  col = mix(col, uWhiteCol, wm);
  // subtle fur grain
  col *= 0.94 + 0.12 * vnoise(p*140.0);
  return col;
}
`;

function makeCoatMaterial() {
  const uniforms = {
    uPattern: { value: 1 },
    uMain: { value: new THREE.Color() },
    uAccent: { value: new THREE.Color() },
    uWhiteCol: { value: new THREE.Color('#fbf7ef') },
    uWhite: { value: 0.3 },
    uSeed: { value: 0 },
    uRim: { value: 0.45 },
    uBodyC: { value: new THREE.Vector3() },
    uBodyR: { value: new THREE.Vector3(1, 1, 1) },
    uHeadC: { value: new THREE.Vector3() },
    uMuzzle: { value: new THREE.Vector3() },
  };
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0 });
  mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = 'attribute vec4 catPos;\nvarying vec4 vCatPos;\n' +
      shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvCatPos = catPos;');
    shader.fragmentShader = PATTERN_GLSL + shader.fragmentShader
      .replace('#include <color_fragment>', '#include <color_fragment>\ndiffuseColor.rgb *= coatColor(vCatPos);')
      .replace('#include <opaque_fragment>', `
        float rimF = pow(1.0 - clamp(dot(normalize(normal), normalize(vViewPosition)), 0.0, 1.0), 2.2);
        outgoingLight += (diffuseColor.rgb * 0.8 + 0.12) * rimF * uRim;
        #include <opaque_fragment>`);
  };
  mat.customProgramCacheKey = () => 'catcoat';
  mat.userData.uniforms = uniforms;
  return mat;
}

function makeOutlineMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uThick: { value: 0.0028 }, uColor: { value: new THREE.Color('#3b2a2a') } },
    vertexShader: /* glsl */ `
      uniform float uThick;
      void main(){
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        vec3 n = normalize(normalMatrix * normal);
        mv.xyz += n * uThick * clamp(-mv.z, 0.5, 6.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      void main(){ gl_FragColor = vec4(uColor, 1.0);
      #include <colorspace_fragment>
      }`,
    side: THREE.BackSide,
  });
}

// --------------------------------------------------------------------------- poses
// Every value here is a target that the live pose smoothly blends toward.
const POSES = {
  stand: { ground: 0, lower: 0, pitch: 0, roll: 0, freeLegs: 0, frontZ: 0, rearZ: 0, rearX: 1, headPitch: 0, headRoll: 0, tuck: 0 },
  sit: { ground: 1, lower: 0, pitch: -0.62, roll: 0, freeLegs: 0, frontZ: 0.035, rearZ: 0.1, rearX: 1.35, headPitch: 0.05, headRoll: 0, tuck: 0 },
  loaf: { ground: 1, lower: 0, pitch: 0.0, roll: 0, freeLegs: 0, frontZ: 0.1, rearZ: 0.06, rearX: 1.2, headPitch: 0.12, headRoll: 0, tuck: 0.6 },
  sleep: { ground: 1, lower: 0, pitch: 0.03, roll: 0, freeLegs: 0, frontZ: 0.1, rearZ: 0.06, rearX: 1.2, headPitch: 0.5, headRoll: 0.35, tuck: 0.8 },
  crouch: { ground: 0, lower: 0.075, pitch: 0.1, roll: 0, freeLegs: 0, frontZ: 0.05, rearZ: -0.01, rearX: 1.15, headPitch: -0.12, headRoll: 0, tuck: 0 },
  eat: { ground: 0, lower: 0.035, pitch: 0.2, roll: 0, freeLegs: 0, frontZ: -0.01, rearZ: 0.02, rearX: 1.1, headPitch: 0.78, headRoll: 0, tuck: 0 },
  squat: { ground: 0.55, lower: 0.02, pitch: -0.4, roll: 0, freeLegs: 0, frontZ: 0.0, rearZ: 0.05, rearX: 1.4, headPitch: -0.1, headRoll: 0, tuck: 0 },
  belly: { ground: 1, lower: 0, pitch: 0, roll: 1.95, freeLegs: 1, frontZ: 0, rearZ: 0, rearX: 1, headPitch: -0.15, headRoll: -1.0, tuck: 0 },
  reach: { ground: 0.6, lower: 0, pitch: -1.05, roll: 0, freeLegs: 0.55, frontZ: 0.05, rearZ: 0.12, rearX: 1.3, headPitch: -0.35, headRoll: 0, tuck: 0 },
};
const POSE_KEYS = Object.keys(POSES.stand);

const TAILS = {
  neutral: { base: -1.75, curl: 0.13, side: 0, tip: 0.1, sway: 0.18, speed: 1.6 },
  happy: { base: -0.35, curl: 0.02, side: 0, tip: 0.55, sway: 0.08, speed: 2.2 },
  low: { base: -2.45, curl: 0.09, side: 0, tip: 0.0, sway: 0.08, speed: 1 },
  wrap: { base: -2.05, curl: -0.02, side: 0.36, tip: 0.0, sway: 0.03, speed: 1 },
  flick: { base: -1.6, curl: 0.1, side: 0, tip: 0.2, sway: 0.45, speed: 7 },
  up: { base: -0.15, curl: 0.0, side: 0, tip: 0.1, sway: 0.03, speed: 1 },
  puff: { base: -0.6, curl: 0.18, side: 0, tip: 0.1, sway: 0.06, speed: 12 },
  belly: { base: -2.3, curl: -0.05, side: 0.18, tip: 0.0, sway: 0.25, speed: 2.5 },
};
const TAIL_KEYS = Object.keys(TAILS.neutral);

const DOWN = new THREE.Vector3(0, -1, 0);
const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _mInv = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();

// --------------------------------------------------------------------------- the cat
export class Cat {
  constructor(look = {}, voice = {}) {
    this.root = new THREE.Group();
    this.root.name = 'cat';
    this.look = { ...DEFAULT_LOOK, ...look };
    this.voice = { ...DEFAULT_VOICE, ...voice };
    this.coatMat = makeCoatMaterial();
    this.outlineMat = makeOutlineMaterial();
    this.mats = {
      iris: new THREE.MeshStandardMaterial({ roughness: 0.25, metalness: 0 }),
      iris2: new THREE.MeshStandardMaterial({ roughness: 0.25, metalness: 0 }),
      pupil: new THREE.MeshStandardMaterial({ color: 0x0b0a10, roughness: 0.15 }),
      shine: new THREE.MeshBasicMaterial({ color: 0xffffff }),
      nose: new THREE.MeshStandardMaterial({ roughness: 0.5 }),
      inner: new THREE.MeshStandardMaterial({ color: 0xf6b4bd, roughness: 0.8 }),
      dark: new THREE.MeshStandardMaterial({ color: 0x3a2327, roughness: 0.7 }),
      mouth: new THREE.MeshStandardMaterial({ color: 0x6b2530, roughness: 0.7 }),
      tongue: new THREE.MeshStandardMaterial({ color: 0xff8a9a, roughness: 0.6 }),
      pads: new THREE.MeshStandardMaterial({ color: 0xf7a0ae, roughness: 0.6 }),
      whisker: new THREE.MeshBasicMaterial({ color: 0xfaf6f0, transparent: true, opacity: 0.85 }),
      collar: new THREE.MeshStandardMaterial({ roughness: 0.5 }),
      bell: new THREE.MeshStandardMaterial({ color: 0xf5c542, roughness: 0.25, metalness: 0.6, emissive: 0x3a2800 }),
      blush: new THREE.MeshBasicMaterial({ color: 0xff7e9a, transparent: true, opacity: 0, depthWrite: false }),
    };

    // live animation state
    this.cur = {}; this.tgt = {};
    for (const k of POSE_KEYS) this.cur[k] = this.tgt[k] = POSES.stand[k];
    this.tailCur = { ...TAILS.neutral }; this.tailTgt = { ...TAILS.neutral };
    this.poseName = 'stand';
    this.tailName = 'neutral';
    this.face = { eyeOpen: 1, happy: 0, pupil: 1, earBack: 0, mouth: 0, blush: 0 };
    this.faceTgt = { eyeOpen: 1, happy: 0, pupil: 1, earBack: 0, blush: 0 };
    this.lookTarget = null;
    this.look2 = { yaw: 0, pitch: 0 };
    this.time = rand(0, 10);
    this.blinkT = rand(1, 4); this.blink = 0;
    this.earTwitch = [0, 0]; this.earTwitchT = rand(2, 6);
    this.heading = 0;
    this.move = null; this.jump = null; this.speedNow = 0; this.gait = 0;
    this.meowT = 0; this.meowDur = 0;
    this.knead = 0; this.wiggle = 0; this.purr = 0; this.shake = 0;
    this.pawSwipe = null;
    this.onMeow = null;

    this.build();
    this.applyColors();
  }

  // ------------------------------------------------------------------ appearance
  setLook(look) {
    const rebuild = SHAPE_KEYS.some((k) => k in look && look[k] !== this.look[k]);
    Object.assign(this.look, look);
    if (rebuild) this.build();
    this.applyColors();
  }

  applyColors() {
    const L = this.look;
    const u = this.coatMat.userData.uniforms;
    u.uPattern.value = Math.max(0, PATTERNS.findIndex((p) => p.id === L.pattern));
    u.uMain.value.set(L.main);
    u.uAccent.value.set(L.accent);
    u.uWhite.value = L.white;
    u.uSeed.value = L.seed;
    this.mats.iris.color.set(L.eye);
    this.mats.iris.emissive.set(L.eye).multiplyScalar(0.25);
    const e2 = L.oddEyes ? L.eye2 : L.eye;
    this.mats.iris2.color.set(e2);
    this.mats.iris2.emissive.set(e2).multiplyScalar(0.25);
    this.mats.nose.color.set(L.nose);
    if (L.collar !== 'none') this.mats.collar.color.set(L.collar);
    if (this.collar) this.collar.visible = L.collar !== 'none';
    // outline: a dark, slightly warm version of the main coat colour
    const c = new THREE.Color(L.pattern === 'calico' || L.pattern === 'van' ? '#b8a898' : L.main);
    const hsl = {}; c.getHSL(hsl);
    this.outlineMat.uniforms.uColor.value.setHSL(hsl.h, Math.min(0.5, hsl.s), Math.min(0.2, hsl.l * 0.35));
  }

  build() {
    if (this.rig) {
      this.root.remove(this.rig);
      this.rig.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    }
    const L = this.look;
    const s = L.head;
    const ch = L.chonk;
    this.coatMeshes = [];
    this.pickables = [];

    const rig = (this.rig = new THREE.Group());
    this.root.add(rig);

    // Dimensions
    const rx = 0.14 * ch, ry = 0.13 * ch, rz = 0.22 * (0.92 + 0.08 * ch);
    const pawR = 0.045 * (0.9 + 0.1 * ch);
    const pawH = pawR * 0.62;
    const L0 = 0.12 * L.legs;
    const hipDrop = ry * 0.35;
    const torsoY = pawH + L0 + hipDrop;
    Object.assign(this, { rx, ry, rz, pawR, pawH, L0, torsoY });

    const torso = (this.torso = new THREE.Group());
    torso.position.y = torsoY;
    rig.add(torso);

    const coat = (parent, geo, part, region, pos, scale, rot) => {
      const m = new THREE.Mesh(geo, this.coatMat);
      if (pos) m.position.copy(pos);
      if (scale) m.scale.copy(scale);
      if (rot) m.rotation.copy(rot);
      m.castShadow = true;
      m.userData.part = part;
      m.userData.region = region;
      parent.add(m);
      this.coatMeshes.push(m);
      this.pickables.push(m);
      return m;
    };
    const misc = (parent, geo, mat, region, pos, scale, rot, shadow = true) => {
      const m = new THREE.Mesh(geo, mat);
      if (pos) m.position.copy(pos);
      if (scale) m.scale.copy(scale);
      if (rot) m.rotation.copy(rot);
      m.castShadow = shadow;
      m.userData.region = region;
      parent.add(m);
      if (region) this.pickables.push(m);
      return m;
    };
    const V = (x, y, z) => new THREE.Vector3(x, y, z);
    const sph = (r, w = 28, h = 20) => new THREE.SphereGeometry(r, w, h);

    // ---- torso
    this.torsoMesh = coat(torso, sph(1, 36, 26), PART.torso, 'body', V(0, 0, 0), V(rx, ry, rz));
    coat(torso, sph(0.1 * ch), PART.torso, 'body', V(0, 0.02, rz * 0.5), V(1.05, 1.05, 1));
    for (const sx of [-1, 1]) coat(torso, sph(0.08 * ch), PART.torso, 'body', V(sx * 0.068 * ch, -0.015, -rz * 0.48), V(0.9, 1.05, 1.15));
    if (ch > 1.02) coat(torso, sph(1), PART.torso, 'body', V(0, -ry * 0.45, -0.01), V(rx * 0.85, ry * 0.7 * (ch - 0.5), rz * 0.75));
    const neckPos = V(0, ry * 0.62, rz * 0.76);
    coat(torso, sph(0.075 * (0.85 + 0.15 * ch)), PART.torso, 'body', neckPos.clone().add(V(0, -0.01, -0.01)));
    if (L.fluff > 0.12) {
      const f = L.fluff;
      coat(torso, sph(0.07 + 0.05 * f), PART.torso, 'body', V(0, ry * 0.25, rz * 0.82), V(1.2, 1.1, 0.8));
    }

    // ---- head
    const headPivot = (this.headPivot = new THREE.Group());
    headPivot.position.copy(neckPos);
    headPivot.rotation.order = 'YXZ';
    torso.add(headPivot);
    const head = (this.head = new THREE.Group());
    head.position.set(0, 0.1 * s, 0.05 * s);
    headPivot.add(head);
    const HS = (x, y, z) => V(x * s, y * s, z * s);

    this.skull = coat(head, sph(0.15 * s, 40, 30), PART.head, 'head', V(0, 0, 0), V(1.12, 0.95, 0.97));
    const cheekW = 1.2 + L.fluff * 0.45;
    for (const sx of [-1, 1]) {
      coat(head, sph(0.07 * s), PART.face, 'cheek', HS(sx * 0.068, -0.045, 0.05), V(cheekW, 0.85, 0.95));
      coat(head, sph(0.04 * s), PART.face, 'chin', HS(sx * 0.027, -0.05, 0.116), V(1, 0.85, 0.9));
      if (L.fluff > 0.35) {
        const tuft = new THREE.ConeGeometry(0.03 * s, 0.07 * s * L.fluff + 0.02, 10);
        coat(head, tuft, PART.face, 'cheek', HS(sx * (0.135 + 0.03 * L.fluff), -0.07, 0.03), V(1, 1, 0.6), new THREE.Euler(0, 0, sx * 2.1));
      }
    }
    coat(head, sph(0.03 * s), PART.face, 'chin', HS(0, -0.078, 0.1));

    // nose: soft rounded triangle
    const noseGeo = sph(0.016 * s, 16, 12);
    misc(head, noseGeo, this.mats.nose, 'face', HS(0, -0.024, 0.147), V(1.45, 0.85, 0.9), new THREE.Euler(0.4, 0, 0));
    // philtrum + "ω" mouth
    const mouthG = (this.mouthG = new THREE.Group());
    mouthG.position.copy(HS(0, -0.06, 0.148));
    head.add(mouthG);
    misc(mouthG, new THREE.CylinderGeometry(0.0028 * s, 0.0028 * s, 0.022 * s, 6), this.mats.dark, null, HS(0, 0.013, -0.002), null, null, false);
    for (const sx of [-1, 1]) {
      const arc = new THREE.TorusGeometry(0.0125 * s, 0.0032 * s, 6, 14, Math.PI);
      misc(mouthG, arc, this.mats.dark, null, HS(sx * 0.0125, 0.002, 0), null, new THREE.Euler(0.15, 0, Math.PI), false);
    }
    const mouthOpen = (this.mouthOpen = new THREE.Group());
    mouthOpen.position.copy(HS(0, -0.075, 0.138));
    head.add(mouthOpen);
    misc(mouthOpen, sph(0.022 * s, 16, 12), this.mats.mouth, null, V(0, 0, 0), V(1.1, 1, 0.5), null, false);
    misc(mouthOpen, sph(0.012 * s, 12, 10), this.mats.tongue, null, HS(0, -0.01, 0.006), V(1.2, 0.6, 0.6), null, false);
    mouthOpen.scale.set(1, 0.01, 1);
    mouthOpen.visible = false;

    // eyes
    this.eyes = [];
    const es = L.eyeSize;
    for (const sx of [-1, 1]) {
      const eg = new THREE.Group();
      eg.position.copy(HS(sx * 0.063, 0.006, 0.115));
      eg.rotation.set(-0.06, sx * 0.3, 0);
      head.add(eg);
      const open = new THREE.Group();
      eg.add(open);
      const irisMat = sx < 0 ? this.mats.iris : this.mats.iris2;
      misc(open, sph(0.043 * s * es, 24, 18), irisMat, 'face', V(0, 0, 0), V(1, 1.1, 0.55), null, false);
      const pupil = new THREE.Group();
      pupil.position.z = 0.009 * s;
      open.add(pupil);
      misc(pupil, sph(0.031 * s * es, 20, 16), this.mats.pupil, 'face', V(0, 0, 0), V(0.82, 1.05, 0.55), null, false);
      misc(open, sph(0.011 * s * es, 10, 8), this.mats.shine, null, HS(0.012 * es, 0.019 * es, 0.026), null, null, false);
      misc(open, sph(0.0055 * s * es, 8, 6), this.mats.shine, null, HS(-0.013 * es, -0.017 * es, 0.025), null, null, false);
      const happy = misc(eg, new THREE.TorusGeometry(0.026 * s * es, 0.0055 * s, 6, 16, Math.PI), this.mats.dark, null, HS(0, -0.008, 0.02), V(1, 0.9, 1), null, false);
      happy.visible = false;
      // blush
      misc(head, sph(0.026 * s, 16, 10), this.mats.blush, null, HS(sx * 0.098, -0.04, 0.1), V(1.3, 0.7, 0.4), new THREE.Euler(0, sx * 0.7, 0), false);
      this.eyes.push({ group: eg, open, pupil, happy });
    }

    // ears
    this.ears = [];
    const eh = 0.1 * L.ears * s, er = 0.056 * (0.8 + 0.2 * L.ears) * s;
    for (const sx of [-1, 1]) {
      const eg = new THREE.Group();
      eg.position.copy(HS(sx * 0.078, 0.092, -0.012));
      eg.rotation.order = 'ZXY';
      head.add(eg);
      const outerG = new THREE.ConeGeometry(er, eh, 20);
      outerG.translate(0, eh / 2, 0);
      coat(eg, outerG, PART.ear, 'ear', V(0, 0, 0), V(1, 1, 0.55));
      const innerG = new THREE.ConeGeometry(er * 0.62, eh * 0.75, 16);
      innerG.translate(0, eh * 0.75 / 2, 0);
      misc(eg, innerG, this.mats.inner, 'ear', V(0, 0.004, er * 0.26), V(1, 1, 0.35), null, false);
      this.ears.push({ group: eg, side: sx });
    }

    // whiskers
    const wg = new THREE.CylinderGeometry(0.0011, 0.0011, 0.13 * s, 4);
    wg.rotateZ(Math.PI / 2);
    wg.translate(0.065 * s, 0, 0);
    for (const sx of [-1, 1]) {
      for (let i = 0; i < 3; i++) {
        const w = misc(head, wg, this.mats.whisker, null, HS(sx * 0.055, -0.052 + i * 0.008, 0.112), null, null, false);
        w.rotation.set(0, sx > 0 ? -0.25 : Math.PI + 0.25, (i - 1) * -0.13 * sx);
      }
    }

    // collar + bell
    const collar = (this.collar = new THREE.Group());
    collar.position.copy(neckPos).add(V(0, 0.004, 0.006));
    collar.rotation.x = 0.62;
    torso.add(collar);
    const cr = 0.094 * (0.85 + 0.15 * ch) + L.fluff * 0.012;
    misc(collar, new THREE.TorusGeometry(cr, 0.014, 10, 36), this.mats.collar, 'body', V(0, 0, 0), V(1.08, 1, 1), new THREE.Euler(Math.PI / 2, 0, 0));
    if (L.bell) {
      this.bell = misc(collar, sph(0.021, 16, 12), this.mats.bell, 'body', V(0, -0.02, cr + 0.012));
      misc(this.bell, new THREE.BoxGeometry(0.02, 0.003, 0.01), this.mats.dark, null, V(0, -0.006, 0.014), null, null, false);
    } else this.bell = null;

    // ---- legs
    this.legs = [];
    const lr = 0.036 * (0.85 + 0.15 * ch);
    const legDefs = [
      { front: true, sx: -1 }, { front: true, sx: 1 }, { front: false, sx: -1 }, { front: false, sx: 1 },
    ];
    for (const d of legDefs) {
      const hip = V(d.sx * (d.front ? 0.07 : 0.075) * ch, -hipDrop, (d.front ? 0.55 : -0.52) * rz);
      const g = new THREE.Group();
      g.position.copy(hip);
      torso.add(g);
      const legGeo = new THREE.CapsuleGeometry(lr, L0, 4, 12);
      legGeo.translate(0, -L0 / 2, 0);
      const upper = coat(g, legGeo, PART.leg, 'paw');
      const paw = new THREE.Group();
      paw.position.y = -L0;
      g.add(paw);
      coat(paw, sph(pawR, 20, 14), PART.leg, 'paw', V(0, 0, 0.012), V(1, 0.62, 1.25));
      // toe beans
      for (let t = -1; t <= 1; t++) misc(paw, sph(0.0105, 10, 8), this.mats.pads, 'paw', V(t * 0.019, -pawH * 0.78, 0.034 - Math.abs(t) * 0.006), V(1, 0.45, 1), null, false);
      misc(paw, sph(0.018, 12, 8), this.mats.pads, 'paw', V(0, -pawH * 0.8, 0.0), V(1.15, 0.4, 0.9), null, false);
      this.legs.push({ ...d, hip, group: g, upper, paw, lift: 0 });
    }

    // ---- tail
    this.tail = [];
    const N = 10;
    const segLen = 0.043 * L.tail;
    const r0 = (0.026 + 0.022 * L.fluff) * (0.9 + 0.1 * ch);
    let parent = torso;
    for (let i = 0; i < N; i++) {
      const g = new THREE.Group();
      if (i === 0) g.position.set(0, ry * 0.3, -rz * 0.9);
      else g.position.set(0, segLen, 0);
      parent.add(g);
      const r = r0 * (1 - 0.22 * (i / N)) * (L.fluff > 0.5 && i > N - 4 ? 1.12 : 1);
      const geo = new THREE.CapsuleGeometry(r, segLen, 4, 12);
      geo.translate(0, segLen / 2, 0);
      const m = coat(g, geo, PART.tail, 'tail');
      m.userData.tailIndex = i;
      m.userData.segLen = segLen;
      this.tail.push(g);
      parent = g;
    }

    // Rest pose: bake cat-space positions for the coat shader.
    this.bakeCatSpace(N);

    // Anchor uniforms for pattern placement.
    const u = this.coatMat.userData.uniforms;
    u.uBodyC.value.set(0, torsoY, 0);
    u.uBodyR.value.set(rx, ry, rz);
    this.head.updateWorldMatrix(true, false);
    const inv = _m.copy(this.root.matrixWorld).invert();
    u.uHeadC.value.setFromMatrixPosition(this.head.matrixWorld).applyMatrix4(inv);
    u.uMuzzle.value.copy(HS(0, -0.055, 0.12)).applyMatrix4(this.head.matrixWorld).applyMatrix4(inv);

    // Inverted-hull outlines.
    for (const m of this.coatMeshes) {
      const o = new THREE.Mesh(m.geometry, this.outlineMat);
      o.raycast = () => {};
      m.add(o);
    }
    for (const e of this.eyes) {
      e.open.traverse((m) => {
        if (m.isMesh && m.material === this.mats.iris || m.material === this.mats.iris2) {
          const o = new THREE.Mesh(m.geometry, this.outlineMat);
          o.raycast = () => {};
          m.add(o);
        }
      });
    }
    this.applyPose(0, true);
  }

  bakeCatSpace(N) {
    this.root.updateMatrixWorld(true);
    const inv = new THREE.Matrix4().copy(this.root.matrixWorld).invert();
    const M = new THREE.Matrix4();
    for (const m of this.coatMeshes) {
      M.multiplyMatrices(inv, m.matrixWorld);
      const pos = m.geometry.attributes.position;
      const arr = new Float32Array(pos.count * 4);
      const tail = m.userData.tailIndex;
      for (let i = 0; i < pos.count; i++) {
        _v.fromBufferAttribute(pos, i);
        let w = m.userData.part;
        if (tail !== undefined) w += clamp((tail + _v.y / m.userData.segLen) / N, 0, 0.999);
        _v.applyMatrix4(M);
        arr[i * 4] = _v.x; arr[i * 4 + 1] = _v.y; arr[i * 4 + 2] = _v.z; arr[i * 4 + 3] = w;
      }
      m.geometry.setAttribute('catPos', new THREE.BufferAttribute(arr, 4));
    }
  }

  // ------------------------------------------------------------------ behaviour API
  setPose(name) { this.poseName = name; Object.assign(this.tgt, POSES[name]); }
  setTail(name) { this.tailName = name; Object.assign(this.tailTgt, TAILS[name]); }
  setMood({ eyes, pupil, ears, blush } = {}) {
    if (eyes !== undefined) {
      if (eyes === 'happy') { this.faceTgt.happy = 1; this.faceTgt.eyeOpen = 1; }
      else { this.faceTgt.happy = 0; this.faceTgt.eyeOpen = eyes === 'closed' ? 0.05 : eyes === 'sleepy' ? 0.35 : eyes === 'squint' ? 0.55 : 1; }
    }
    if (pupil !== undefined) this.faceTgt.pupil = pupil;
    if (ears !== undefined) this.faceTgt.earBack = ears;
    if (blush !== undefined) this.faceTgt.blush = blush;
  }
  resetMood() { this.setMood({ eyes: 'open', pupil: 1, ears: 0, blush: 0 }); }

  lookAt(v) { this.lookTarget = v ? (this.lookTarget || new THREE.Vector3()).copy(v) : null; }

  get position() { return this.root.position; }

  place(x, z, heading = this.heading) {
    this.root.position.set(x, 0, z);
    this.heading = heading;
    this.root.rotation.y = heading;
    this.move = null; this.jump = null;
  }

  // Walk/run to a point. Resolves on arrival.
  walkTo(x, z, speed = 0.45) {
    if (this.move) this.move.resolve(false);
    return new Promise((resolve) => { this.move = { x, z, speed, resolve }; });
  }
  stop() { if (this.move) { this.move.resolve(false); this.move = null; } }

  turnTo(angle) { this.turnTarget = angle; }
  faceToward(x, z) { this.turnTarget = Math.atan2(x - this.root.position.x, z - this.root.position.z); }

  jumpTo(x, z, height = 0.25, dur = 0.55, toY = this.root.position.y) {
    this.stop();
    if (this.jump) this.jump.resolve();
    return new Promise((resolve) => {
      this.jump = { fx: this.root.position.x, fz: this.root.position.z, fy: this.root.position.y, tx: x, tz: z, ty: toY, height, dur, t: 0, resolve };
      this.faceToward(x, z);
      audio.swish();
    });
  }

  meow(opts) {
    const dur = audio.meow({ ...this.voice, ...opts });
    this.meowDur = dur; this.meowT = dur;
    if (this.onMeow) this.onMeow(dur);
    return dur;
  }

  swipe(side = 1) { this.pawSwipe = { t: 0, side }; audio.swish(); }

  // ------------------------------------------------------------------ per-frame update
  update(dt) {
    this.time += dt;
    const t = this.time;

    // locomotion
    let targetSpeed = 0;
    if (this.move) {
      const p = this.root.position;
      const dx = this.move.x - p.x, dz = this.move.z - p.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 0.03) {
        const m = this.move; this.move = null; m.resolve(true);
      } else {
        const want = Math.atan2(dx, dz);
        this.heading = dampAngle(this.heading, want, 7, dt);
        const facing = Math.cos(wrapAngle(want - this.heading));
        targetSpeed = this.move.speed * clamp(facing, 0.2, 1) * clamp(dist / 0.2 + 0.25, 0, 1);
        const step = Math.min(dist, Math.max(this.speedNow, 0.05) * dt);
        p.x += (dx / dist) * step; p.z += (dz / dist) * step;
      }
      this.turnTarget = undefined;
    } else if (this.turnTarget !== undefined) {
      this.heading = dampAngle(this.heading, this.turnTarget, 6, dt);
      if (Math.abs(wrapAngle(this.turnTarget - this.heading)) < 0.02) this.turnTarget = undefined;
      else targetSpeed = 0.06; // shuffle feet while turning
    }
    this.speedNow = damp(this.speedNow, targetSpeed, 8, dt);

    // jump
    let jumpY = 0, jumpPitch = 0, airborne = 0;
    if (this.jump) {
      const j = this.jump;
      j.t += dt / j.dur;
      const k = clamp(j.t);
      this.root.position.x = lerp(j.fx, j.tx, k);
      this.root.position.z = lerp(j.fz, j.tz, k);
      this.root.position.y = lerp(j.fy, j.ty, k);
      this.heading = dampAngle(this.heading, Math.atan2(j.tx - j.fx, j.tz - j.fz) || this.heading, 12, dt);
      jumpY = 4 * j.height * k * (1 - k);
      jumpPitch = lerp(-0.45, 0.35, k);
      airborne = Math.sin(k * Math.PI);
      if (j.t >= 1) { this.jump = null; j.resolve(); }
    }
    this.root.rotation.y = this.heading;

    // blend pose params
    for (const k of POSE_KEYS) this.cur[k] = damp(this.cur[k], this.tgt[k], 5, dt);
    for (const k of TAIL_KEYS) this.tailCur[k] = damp(this.tailCur[k], this.tailTgt[k], 4, dt);
    for (const k in this.faceTgt) this.face[k] = damp(this.face[k], this.faceTgt[k], 8, dt);

    // blinking / ear twitches
    this.blinkT -= dt;
    if (this.blinkT < 0) { this.blinkT = rand(2, 6); this.blink = 1; }
    this.blink = Math.max(0, this.blink - dt * 7);
    this.earTwitchT -= dt;
    if (this.earTwitchT < 0) { this.earTwitchT = rand(2, 8); this.earTwitch[chance(0.5) ? 0 : 1] = 1; }
    this.earTwitch = this.earTwitch.map((e) => Math.max(0, e - dt * 4));

    // meow mouth
    if (this.meowT > 0) this.meowT -= dt;
    const mprog = this.meowT > 0 ? 1 - this.meowT / this.meowDur : 1;
    this.face.mouth = this.meowT > 0 ? Math.sin(mprog * Math.PI) ** 0.6 : damp(this.face.mouth, 0, 10, dt);

    this.applyPose(dt, false, jumpY, jumpPitch, airborne);
  }

  applyPose(dt, snap = false, jumpY = 0, jumpPitch = 0, airborne = 0) {
    const c = this.cur, t = this.time;
    const speed = this.speedNow;
    if (snap) {
      for (const k of POSE_KEYS) this.cur[k] = this.tgt[k];
      for (const k of TAIL_KEYS) this.tailCur[k] = this.tailTgt[k];
    }

    // gait
    const stride = clamp(0.035 + speed * 0.09, 0.035, 0.11);
    const run = smoothstep(0.55, 0.9, speed);
    this.gait += (speed * Math.PI / (2 * stride)) * dt;
    const moving = clamp(speed / 0.08);
    const bob = Math.abs(Math.sin(this.gait)) * 0.012 * moving * (1 + run * 1.5);

    // torso orientation
    const wig = this.wiggle * Math.sin(t * 15) * 0.14;
    const gallopPitch = run * Math.sin(this.gait) * 0.1;
    const breathe = Math.sin(t * 2.2) * 0.012;
    this.torso.rotation.set(c.pitch + jumpPitch + gallopPitch, wig, c.roll + Math.sin(t * 43) * 0.006 * this.purr, 'XYZ');
    this.torso.scale.set(1 + breathe * 0.6, 1 + breathe, 1);
    this.torso.updateMatrix();
    // lowest point of the torso ellipsoid after rotation -> used to rest body on floor
    const e = this.torso.matrix.elements;
    const h = Math.sqrt((e[1] * this.rx) ** 2 + (e[5] * this.ry) ** 2 + (e[9] * this.rz) ** 2);
    const groundY = h - this.torsoY + 0.004;
    this.rig.position.y = lerp(-c.lower, groundY, c.ground) + jumpY + bob;
    this.rig.position.z = c.ground * c.roll * 0.0;
    this.rig.updateMatrix();

    // head
    let ly = 0, lp = 0;
    if (this.lookTarget) {
      _v.copy(this.lookTarget);
      this.root.worldToLocal(_v);
      const hx = 0, hy = this.torsoY + this.rig.position.y + 0.14, hz = 0.2;
      ly = clamp(Math.atan2(_v.x - hx, _v.z - hz), -1.15, 1.15);
      lp = clamp(Math.atan2(hy - _v.y, Math.hypot(_v.x - hx, _v.z - hz)), -0.7, 0.85) - c.pitch * 0.8;
      const facingAway = Math.abs(Math.atan2(_v.x - hx, _v.z - hz)) > 1.9;
      if (facingAway) { ly *= 0.3; lp *= 0.3; }
      const w = 1 - c.roll / 2;
      ly *= w; lp *= w;
    }
    const lam = snap ? 100 : 6;
    this.look2.yaw = damp(this.look2.yaw, ly, lam, dt || 1);
    this.look2.pitch = damp(this.look2.pitch, lp, lam, dt || 1);
    const nod = moving * Math.sin(this.gait * 2) * 0.03;
    this.headPivot.rotation.set(c.headPitch + this.look2.pitch + nod - c.pitch * 0.55 - jumpPitch * 0.5,
      this.look2.yaw, c.headRoll * (1 + 0.1 * Math.sin(t * 0.7)) + Math.sin(t * 0.9) * 0.03);
    this.head.position.y = 0.1 * this.look.head - c.tuck * 0.035;

    // face
    const f = this.face;
    const eyeOpen = Math.max(0.05, f.eyeOpen * (1 - this.blink));
    for (const eye of this.eyes) {
      eye.open.visible = f.happy < 0.5;
      eye.happy.visible = f.happy >= 0.5;
      eye.open.scale.set(1, eyeOpen, 1);
      eye.pupil.scale.setScalar(f.pupil);
    }
    this.mats.blush.opacity = 0.55 * f.blush;
    this.mouthOpen.visible = f.mouth > 0.03;
    this.mouthOpen.scale.set(1, Math.max(0.01, f.mouth), 1);
    this.mouthG.position.y = (-0.06 + f.mouth * 0.004) * this.look.head;

    for (const ear of this.ears) {
      const i = ear.side < 0 ? 0 : 1;
      const tw = this.earTwitch[i];
      const back = f.earBack;
      ear.group.rotation.set(-0.12 - back * 0.7 - tw * 0.4, ear.side * back * -0.4, ear.side * (-0.28 - back * 0.9 - tw * 0.25));
    }

    // tail
    const T = this.tailCur;
    const N = this.tail.length;
    const excite = moving * 0.1;
    for (let i = 0; i < N; i++) {
      const g = this.tail[i];
      const k = i / (N - 1);
      const wave = Math.sin(t * T.speed - i * 0.55) * T.sway * (0.25 + k);
      if (i === 0) g.rotation.set(T.base + excite, 0, wave * 0.5 + T.side * 0.5);
      else g.rotation.set(T.curl + (i >= N - 3 ? T.tip : 0) + Math.sin(t * 1.3 + i) * 0.015, 0, T.side + wave);
    }

    // legs (one-bone IK with stretch)
    _m.multiplyMatrices(this.rig.matrix, this.torso.matrix);
    const torsoQ = _q.setFromRotationMatrix(_m);
    const Minv = _mInv.copy(_m).invert();
    const offsets = [0, 0.5, 0.75, 0.25]; // FL FR RL RR phase (lateral walk)
    const gallopOff = [0, 0.12, 0.5, 0.62];
    for (let i = 0; i < 4; i++) {
      const leg = this.legs[i];
      const ph = this.gait + Math.PI * 2 * lerp(offsets[i], gallopOff[i], run);
      const sw = Math.sin(ph) * stride * moving;
      let lift = Math.max(0, Math.cos(ph)) * (0.035 + run * 0.03) * moving;

      // grounded target in rig-root space
      const z0 = leg.front ? c.frontZ : c.rearZ;
      const xs = leg.front ? 1 : c.rearX;
      _v.set(leg.hip.x * xs, this.pawH, leg.hip.z + z0 + sw);
      // kneading ("making biscuits")
      if (leg.front && this.knead > 0) lift += Math.max(0, Math.sin(t * 5 + (leg.sx > 0 ? Math.PI : 0))) * 0.035 * this.knead;
      // paw swipe
      if (leg.front && this.pawSwipe && this.pawSwipe.side === leg.sx) {
        const k = this.pawSwipe.t;
        const s = Math.sin(clamp(k) * Math.PI);
        lift += s * 0.12;
        _v.z += s * 0.1;
      }
      _v.y += lift;
      _v.applyMatrix4(Minv); // -> torso local
      // free-leg target (belly up / airborne), torso local
      const fw = Math.max(c.freeLegs, airborne);
      if (fw > 0.001) {
        const air = airborne > c.freeLegs;
        const fx = leg.hip.x * 1.2;
        const fy = leg.hip.y - this.L0 * (air ? 0.85 : 0.55);
        const fz = leg.hip.z + (air ? (leg.front ? 0.07 : -0.07) : (leg.front ? 0.06 : 0.02)) + (c.freeLegs > 0.5 ? Math.sin(t * 2 + i) * 0.01 : 0);
        _v2.set(fx, fy, fz);
        if (leg.front && c.freeLegs > 0.5 && this.knead > 0) _v2.y -= Math.max(0, Math.sin(t * 5 + (leg.sx > 0 ? Math.PI : 0))) * 0.03 * this.knead;
        if (!leg.front && c.freeLegs > 0.5 && this.knead > 0) _v2.z += Math.sin(t * 16 + (leg.sx > 0 ? 1.5 : 0)) * 0.045 * this.knead; // bunny kicks
        _v.lerp(_v2, fw);
      }
      _v2.copy(_v).sub(leg.hip);
      const len = _v2.length();
      const sc = clamp(len / this.L0, 0.22, 1.5);
      _v2.normalize();
      leg.group.quaternion.setFromUnitVectors(DOWN, _v2);
      leg.upper.scale.y = sc;
      leg.paw.position.y = -this.L0 * sc;
      // keep paw level with the floor (unless belly-up)
      _q2.copy(torsoQ).multiply(leg.group.quaternion).invert();
      leg.paw.quaternion.identity().slerp(_q2, 1 - fw * 0.8);
    }
    if (this.pawSwipe) {
      this.pawSwipe.t += (dt || 0) * 3.5;
      if (this.pawSwipe.t >= 1) this.pawSwipe = null;
    }
    if (this.bell) this.bell.rotation.z = Math.sin(t * 9) * 0.3 * moving;
  }

  // region hit test helper for petting: refine 'body' into back / belly
  regionAt(hit) {
    const obj = hit.object;
    let region = obj.userData.region;
    if (region === 'body') {
      _v.copy(hit.point);
      this.torsoMesh.worldToLocal(_v);
      region = _v.y < -0.3 ? 'belly' : _v.z < -0.55 ? 'rump' : 'back';
    }
    return region || 'body';
  }

  headWorldPos(out = new THREE.Vector3()) {
    this.head.updateWorldMatrix(true, false);
    return out.setFromMatrixPosition(this.head.matrixWorld);
  }
}

export function randomLook() {
  const coats = [
    { main: '#e8913a', accent: '#8a3f14' }, { main: '#2a2a30', accent: '#111114' }, { main: '#8a8f99', accent: '#4c515c' },
    { main: '#f3ece0', accent: '#d7c7b0' }, { main: '#c8a27a', accent: '#5b3a22' }, { main: '#f2dcb8', accent: '#5a3a2c' },
    { main: '#a9a3b8', accent: '#6b6378' }, { main: '#6b4a36', accent: '#2c1d14' }, { main: '#d9d4cc', accent: '#6b6f78' },
    { main: '#f7c888', accent: '#c46a2c' },
  ];
  const c = coats[Math.floor(Math.random() * coats.length)];
  const pat = PATTERNS[Math.floor(Math.random() * PATTERNS.length)].id;
  const eyes = ['#9ccc3c', '#f0b23a', '#5fb7ff', '#c8781e', '#7fc9a8', '#e2d04a'];
  let main = c.main, accent = c.accent;
  if (pat === 'calico') { main = '#e8913a'; accent = '#2a2a30'; }
  if (pat === 'tortie') { main = '#d9772e'; accent = '#2a2124'; }
  if (pat === 'siamese') { main = '#f2e6d0'; accent = pick2(['#4a3328', '#6b7280', '#8a6a5a']); }
  return {
    pattern: pat, main, accent,
    white: Math.random() < 0.4 ? 0 : Math.random() * 0.8,
    seed: Math.random() * 20,
    eye: pat === 'siamese' ? '#5fb7ff' : eyes[Math.floor(Math.random() * eyes.length)],
    oddEyes: Math.random() < 0.12, eye2: '#5fb7ff',
    nose: pick2(['#f39aa8', '#e57f8f', '#6b4a4a', '#3a2a2a', '#d98a7a']),
    chonk: 0.85 + Math.random() * 0.45, legs: 0.7 + Math.random() * 0.5, ears: 0.8 + Math.random() * 0.5,
    tail: 0.7 + Math.random() * 0.6, head: 0.92 + Math.random() * 0.22, fluff: Math.random(), eyeSize: 0.9 + Math.random() * 0.3,
    collar: pick2(['#e8457b', '#3d8bfd', '#35b56a', '#f2b632', '#8e5bd6', '#e5533d']), bell: Math.random() < 0.7,
  };
}
function pick2(a) { return a[Math.floor(Math.random() * a.length)]; }
