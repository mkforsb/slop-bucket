// DOM helpers for the HUD, tool buttons, hints, toasts and thought bubble.

import { NEEDS, state, mood } from './state.js';
import { audio } from './audio.js';

const $ = (id) => document.getElementById(id);

export const ui = {
  init() {
    const bars = $('bars');
    bars.innerHTML = NEEDS.map((n) => `
      <div class="bar" id="bar-${n.id}" title="${n.label}">
        <span class="ico">${n.icon}</span><div class="track"><div class="fill"></div></div>
      </div>`).join('');
    this.lastMood = '';
  },

  showHUD(on) { $('hud').classList.toggle('hidden', !on); },

  setActiveNav(name) {
    document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.scene === name));
  },

  updateHUD() {
    $('catname').textContent = state.name;
    for (const n of NEEDS) {
      const v = state.needs[n.id];
      const el = $(`bar-${n.id}`);
      const fill = el.querySelector('.fill');
      fill.style.width = `${v}%`;
      const hue = Math.round(v * 1.2); // red -> green
      fill.style.background = `linear-gradient(90deg, hsl(${hue}, 85%, 62%), hsl(${hue + 10}, 85%, 70%))`;
      el.classList.toggle('low', v < 25);
    }
    const m = mood();
    const moodEl = $('mood');
    if (m.face !== this.lastMood) {
      moodEl.textContent = m.face;
      moodEl.title = `Mood: ${m.label}`;
      moodEl.classList.add('bump');
      setTimeout(() => moodEl.classList.remove('bump'), 300);
      this.lastMood = m.face;
    }
    const alerts = { feed: state.needs.hunger < 25, pet: state.needs.love < 25, play: state.needs.fun < 25, litter: state.needs.clean < 40 };
    document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('alert', !!alerts[b.dataset.scene]));
  },

  hint(text) { $('hint').textContent = text || ''; },

  toast(text, kind = 'info', life = 2.2) {
    const t = document.createElement('div');
    t.className = `toast ${kind}`;
    t.textContent = text;
    t.style.setProperty('--life', `${life}s`);
    $('toasts').appendChild(t);
    const all = $('toasts').children;
    if (all.length > 4) all[0].remove();
    setTimeout(() => t.remove(), (life + 0.5) * 1000);
  },

  // tools: [{id, emoji, label, onClick, active}]
  setTools(tools, activeId = null) {
    const el = $('tools');
    el.innerHTML = '';
    this.toolButtons = {};
    for (const t of tools) {
      const b = document.createElement('button');
      b.className = 'tool' + (t.id === activeId ? ' active' : '');
      b.innerHTML = `<span class="e">${t.emoji}</span>${t.label}`;
      if (t.title) b.title = t.title;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        audio.click();
        if (t.toggle !== false && t.group !== 'action') {
          for (const k in this.toolButtons) if (tools.find((x) => x.id === k)?.group !== 'action') this.toolButtons[k].classList.remove('active');
          b.classList.add('active');
        }
        t.onClick?.();
      });
      el.appendChild(b);
      this.toolButtons[t.id] = b;
    }
  },

  setToolEnabled(id, on) { if (this.toolButtons?.[id]) this.toolButtons[id].disabled = !on; },

  bubble(icon, screenPos) {
    const b = $('bubble');
    if (!icon || !screenPos) { b.classList.add('hidden'); return; }
    b.classList.remove('hidden');
    if (b.textContent !== icon) b.textContent = icon;
    b.style.left = `${screenPos.x + 26}px`;
    b.style.top = `${screenPos.y - 8}px`;
  },

  wipe(on) { $('wipe').classList.toggle('on', on); },
};
