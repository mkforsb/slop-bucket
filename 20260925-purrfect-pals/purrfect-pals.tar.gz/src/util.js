// Small math / timing helpers shared across the game.

export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const invLerp = (a, b, v) => clamp((v - a) / (b - a));
export const smoothstep = (a, b, v) => { const t = invLerp(a, b, v); return t * t * (3 - 2 * t); };
export const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const chance = (p) => Math.random() < p;

// Frame-rate independent exponential smoothing.
export const damp = (a, b, lambda, dt) => lerp(a, b, 1 - Math.exp(-lambda * dt));

export function wrapAngle(a) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}
export const dampAngle = (a, b, lambda, dt) => a + wrapAngle(b - a) * (1 - Math.exp(-lambda * dt));

export const easeInOut = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
export const easeOutBack = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };

// ---------------------------------------------------------------------------
// Cancellable async "scripts" driven by the game clock. Each scene owns a Task;
// cancelling it rejects every pending wait so long-running behaviour loops unwind.
export class Cancelled extends Error { constructor() { super('cancelled'); } }

export class Clock {
  constructor() { this.time = 0; this.waiters = []; }
  tick(dt) {
    this.time += dt;
    if (!this.waiters.length) return;
    const due = this.waiters.filter((w) => w.at <= this.time);
    if (!due.length) return;
    this.waiters = this.waiters.filter((w) => w.at > this.time);
    for (const w of due) w.resolve();
  }
  wait(sec) { return new Promise((resolve) => this.waiters.push({ at: this.time + sec, resolve })); }
}

export class Task {
  constructor(clock) { this.clock = clock; this.cancelled = false; this.rejecters = new Set(); }
  cancel() {
    this.cancelled = true;
    for (const r of this.rejecters) r(new Cancelled());
    this.rejecters.clear();
  }
  // Wrap any promise so it rejects when the task is cancelled.
  guard(promise) {
    if (this.cancelled) return Promise.reject(new Cancelled());
    return new Promise((resolve, reject) => {
      this.rejecters.add(reject);
      promise.then((v) => { this.rejecters.delete(reject); if (!this.cancelled) resolve(v); },
        (e) => { this.rejecters.delete(reject); reject(e); });
    });
  }
  sleep(sec) { return this.guard(this.clock.wait(sec)); }
  // Resolve once predicate() is true (polled each frame-ish).
  async until(pred, timeout = Infinity) {
    let t = 0;
    while (!pred()) {
      await this.sleep(0.05);
      t += 0.05;
      if (t > timeout) return false;
    }
    return true;
  }
  run(fn) {
    fn(this).catch((e) => { if (!(e instanceof Cancelled)) console.error(e); });
    return this;
  }
}
