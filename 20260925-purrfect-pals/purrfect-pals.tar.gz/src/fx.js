// Sprite particles for emotes (hearts, zzz, notes...) and small physical bits (sand, fur, confetti).
// All sprite art is drawn procedurally on canvases.

import * as THREE from 'three';
import { rand, clamp } from './util.js';

function canvasTex(size, draw) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  draw(g, size);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function heartPath(g, x, y, s) {
  g.beginPath();
  g.moveTo(x, y + s * 0.3);
  g.bezierCurveTo(x, y, x - s * 0.5, y - s * 0.05, x - s * 0.5, y + s * 0.3);
  g.bezierCurveTo(x - s * 0.5, y + s * 0.6, x, y + s * 0.75, x, y + s * 0.95);
  g.bezierCurveTo(x, y + s * 0.75, x + s * 0.5, y + s * 0.6, x + s * 0.5, y + s * 0.3);
  g.bezierCurveTo(x + s * 0.5, y - s * 0.05, x, y, x, y + s * 0.3);
  g.closePath();
}

function starPath(g, cx, cy, r1, r2, n = 5) {
  g.beginPath();
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 ? r2 : r1;
    const a = (i / (n * 2)) * Math.PI * 2 - Math.PI / 2;
    g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
  }
  g.closePath();
}

const outline = (g, w = 6, col = '#ffffff') => { g.lineJoin = 'round'; g.lineWidth = w; g.strokeStyle = col; g.stroke(); };

const ART = {
  heart: (g, s) => { heartPath(g, s / 2, s * 0.08, s * 0.84); outline(g, s * 0.07); g.fillStyle = '#ff5c8a'; g.fill(); g.fillStyle = 'rgba(255,255,255,0.7)'; g.beginPath(); g.ellipse(s * 0.34, s * 0.34, s * 0.07, s * 0.1, -0.6, 0, 7); g.fill(); },
  note: (g, s) => {
    g.fillStyle = '#8a5cf6'; g.strokeStyle = '#fff'; g.lineWidth = s * 0.06;
    g.beginPath(); g.ellipse(s * 0.35, s * 0.72, s * 0.17, s * 0.13, -0.4, 0, 7); g.stroke(); g.fill();
    g.fillRect(s * 0.47, s * 0.15, s * 0.07, s * 0.57);
    g.beginPath(); g.moveTo(s * 0.5, s * 0.15); g.quadraticCurveTo(s * 0.8, s * 0.25, s * 0.78, s * 0.45); g.lineWidth = s * 0.07; g.strokeStyle = '#8a5cf6'; g.stroke();
  },
  anger: (g, s) => {
    g.strokeStyle = '#ff3b3b'; g.lineWidth = s * 0.11; g.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      g.save(); g.translate(s / 2, s / 2); g.rotate(i * Math.PI / 2);
      g.beginPath(); g.moveTo(s * 0.08, -s * 0.34); g.quadraticCurveTo(s * 0.1, -s * 0.1, s * 0.34, -s * 0.08); g.stroke();
      g.restore();
    }
  },
  zzz: (g, s) => { g.font = `900 ${s * 0.8}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = s * 0.1; g.strokeStyle = '#fff'; g.strokeText('Z', s / 2, s / 2); g.fillStyle = '#5b8def'; g.fillText('Z', s / 2, s / 2); },
  question: (g, s) => { g.font = `900 ${s * 0.85}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = s * 0.1; g.strokeStyle = '#fff'; g.strokeText('?', s / 2, s / 2); g.fillStyle = '#f59e0b'; g.fillText('?', s / 2, s / 2); },
  exclaim: (g, s) => { g.font = `900 ${s * 0.85}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = s * 0.1; g.strokeStyle = '#fff'; g.strokeText('!', s / 2, s / 2); g.fillStyle = '#ef4444'; g.fillText('!', s / 2, s / 2); },
  sparkle: (g, s) => { starPath(g, s / 2, s / 2, s * 0.46, s * 0.12, 4); g.fillStyle = '#ffe066'; g.fill(); starPath(g, s / 2, s / 2, s * 0.25, s * 0.07, 4); g.fillStyle = '#fffbe6'; g.fill(); },
  star: (g, s) => { starPath(g, s / 2, s / 2, s * 0.45, s * 0.2); outline(g, s * 0.06); g.fillStyle = '#ffd43b'; g.fill(); },
  drop: (g, s) => { g.beginPath(); g.moveTo(s / 2, s * 0.1); g.quadraticCurveTo(s * 0.85, s * 0.6, s / 2, s * 0.88); g.quadraticCurveTo(s * 0.15, s * 0.6, s / 2, s * 0.1); outline(g, s * 0.06); g.fillStyle = '#74c0fc'; g.fill(); },
  stink: (g, s) => {
    g.strokeStyle = 'rgba(120,170,60,0.9)'; g.lineWidth = s * 0.09; g.lineCap = 'round'; g.beginPath();
    for (let y = 0; y <= 1; y += 0.02) { const x = 0.5 + Math.sin(y * Math.PI * 3) * 0.18; y === 0 ? g.moveTo(x * s, (0.95 - y * 0.9) * s) : g.lineTo(x * s, (0.95 - y * 0.9) * s); }
    g.stroke();
  },
  puff: (g, s) => { const gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.6)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, s, s); },
  dot: (g, s) => { g.beginPath(); g.arc(s / 2, s / 2, s * 0.42, 0, 7); g.fillStyle = '#fff'; g.fill(); },
  square: (g, s) => { g.fillStyle = '#fff'; g.fillRect(s * 0.15, s * 0.3, s * 0.7, s * 0.4); },
  fur: (g, s) => { g.strokeStyle = '#fff'; g.lineCap = 'round'; for (let i = 0; i < 9; i++) { g.lineWidth = s * 0.03; g.beginPath(); const a = rand(0, 7); g.moveTo(s / 2, s / 2); g.quadraticCurveTo(s / 2 + Math.cos(a + 0.5) * s * 0.2, s / 2 + Math.sin(a + 0.5) * s * 0.2, s / 2 + Math.cos(a) * s * 0.4, s / 2 + Math.sin(a) * s * 0.4); g.stroke(); } },
  paw: (g, s) => {
    g.fillStyle = '#ff8fab';
    g.beginPath(); g.ellipse(s * 0.5, s * 0.64, s * 0.2, s * 0.16, 0, 0, 7); g.fill();
    for (const [x, y] of [[0.28, 0.4], [0.42, 0.28], [0.58, 0.28], [0.72, 0.4]]) { g.beginPath(); g.ellipse(x * s, y * s, s * 0.075, s * 0.095, 0, 0, 7); g.fill(); }
  },
};

export class FX {
  constructor(scene) {
    this.scene = scene;
    this.tex = {};
    for (const k in ART) this.tex[k] = canvasTex(128, ART[k]);
    this.items = [];
  }

  // type: art key. opts: {vel, color, size, life, gravity, drag, spin, fade, grow, wobble}
  spawn(type, pos, opts = {}) {
    const mat = new THREE.SpriteMaterial({ map: this.tex[type], transparent: true, depthWrite: false, color: opts.color || 0xffffff, rotation: opts.rot || 0 });
    const sp = new THREE.Sprite(mat);
    sp.position.copy(pos);
    const size = opts.size ?? 0.09;
    sp.scale.setScalar(size);
    sp.renderOrder = 10;
    this.scene.add(sp);
    this.items.push({
      sp, size, age: 0,
      life: opts.life ?? 1.4,
      vel: opts.vel ? opts.vel.clone() : new THREE.Vector3(rand(-0.05, 0.05), 0.25, rand(-0.05, 0.05)),
      gravity: opts.gravity ?? 0,
      drag: opts.drag ?? 0.6,
      spin: opts.spin ?? 0,
      grow: opts.grow ?? 0.3,
      wobble: opts.wobble ?? 0.8,
      pop: opts.pop ?? true,
      floor: opts.floor ?? -Infinity,
    });
    return sp;
  }

  // Emote above the cat's head.
  emote(cat, type, n = 1, opts = {}) {
    const p = cat.headWorldPos(new THREE.Vector3());
    p.y += 0.15;
    for (let i = 0; i < n; i++) {
      const q = p.clone().add(new THREE.Vector3(rand(-0.08, 0.08), rand(0, 0.05), rand(-0.08, 0.08)));
      this.spawn(type, q, { vel: new THREE.Vector3(rand(-0.08, 0.08), rand(0.18, 0.3), rand(-0.05, 0.05)), size: opts.size ?? 0.085, life: opts.life ?? 1.5, ...opts });
    }
  }

  burst(type, pos, n, { speed = 0.6, up = 0.6, size = 0.03, life = 0.8, gravity = -2.5, colors = null, floor = 0.005, spread = 1 } = {}) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const v = new THREE.Vector3(Math.cos(a) * speed * rand(0.3, 1) * spread, up * rand(0.5, 1.2), Math.sin(a) * speed * rand(0.3, 1) * spread);
      this.spawn(type, pos, { vel: v, size: size * rand(0.7, 1.3), life: life * rand(0.7, 1.2), gravity, drag: 0.4, grow: 0, wobble: 0, pop: false, floor, color: colors ? colors[Math.floor(Math.random() * colors.length)] : 0xffffff, rot: rand(0, 6) });
    }
  }

  confetti(pos, n = 80) {
    const colors = [0xff6b9a, 0xffd43b, 0x69db7c, 0x4dabf7, 0xb197fc, 0xff922b];
    for (let i = 0; i < n; i++) {
      const v = new THREE.Vector3(rand(-1, 1), rand(1.5, 3.2), rand(-1, 1));
      this.spawn(i % 3 ? 'square' : 'dot', pos, { vel: v, size: rand(0.03, 0.06), life: rand(2, 3.5), gravity: -3, drag: 1.2, spin: rand(-8, 8), grow: 0, wobble: 0, pop: false, floor: 0.01, color: colors[i % colors.length], rot: rand(0, 6) });
    }
  }

  update(dt) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      it.age += dt;
      const k = it.age / it.life;
      if (k >= 1) {
        this.scene.remove(it.sp);
        it.sp.material.dispose();
        this.items.splice(i, 1);
        continue;
      }
      it.vel.y += it.gravity * dt;
      it.vel.multiplyScalar(Math.exp(-it.drag * dt));
      it.sp.position.addScaledVector(it.vel, dt);
      if (it.sp.position.y < it.floor) { it.sp.position.y = it.floor; it.vel.set(0, 0, 0); it.gravity = 0; }
      it.sp.position.x += Math.sin(it.age * 6 + i) * it.wobble * 0.002;
      it.sp.material.rotation += it.spin * dt;
      const pop = it.pop ? Math.min(1, it.age / 0.15) : 1;
      const s = it.size * (pop * (it.pop ? 1 + 0.25 * Math.sin(Math.min(1, it.age / 0.25) * Math.PI) : 1)) * (1 + it.grow * k);
      it.sp.scale.setScalar(s);
      it.sp.material.opacity = clamp((1 - k) * 3);
    }
  }
}
