#!/usr/bin/env python3
"""Bundle src/ with esbuild and inline everything into one self-contained HTML file."""
import subprocess, sys, pathlib

ROOT = pathlib.Path(__file__).parent
ESBUILD = ROOT / 'tools/package/bin/esbuild'


def build(entry='src/main.js', template='src/index.html', out='dist/purrfect-pals.html', minify=True):
    args = [str(ESBUILD), entry, '--bundle', '--format=iife', '--target=es2020', '--legal-comments=eof']
    if minify:
        args.append('--minify')
    js = subprocess.run(args, cwd=ROOT, check=True, capture_output=True, text=True).stdout
    js = js.replace('</script', '<\\/script')
    html = (ROOT / template).read_text()
    css = (ROOT / 'src/style.css').read_text() if (ROOT / 'src/style.css').exists() else ''
    html = html.replace('/*__CSS__*/', css).replace('/*__JS__*/', js)
    (ROOT / out).parent.mkdir(exist_ok=True)
    (ROOT / out).write_text(html)
    print(f'{out}: {len(html) / 1024:.0f} KB')


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        # dev-only lineup of cats in various patterns/poses (see dev/)
        build('dev/test_cat.js', 'dev/test.html', 'dist/test.html', minify=False)
    else:
        build()
